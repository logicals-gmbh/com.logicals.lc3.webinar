#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST__C

#include <lcfu___com.logicals.basic.timer.fb_lc_monoflop_st.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_NOT__BOOL lFunction_R_TRIG__CLK_OR__IN1_AND__IN2_NOT;
    LC_TD_Function_AND__BOOL lFunction_R_TRIG__CLK_OR__IN1_AND;
    LC_TD_Function_OR__BOOL lFunction_R_TRIG__CLK_OR;
    LC_INIT_Function_NOT__BOOL(&lFunction_R_TRIG__CLK_OR__IN1_AND__IN2_NOT);
    LC_INIT_Function_AND__BOOL(&lFunction_R_TRIG__CLK_OR__IN1_AND);
    LC_INIT_Function_OR__BOOL(&lFunction_R_TRIG__CLK_OR);
    lFunction_R_TRIG__CLK_OR__IN1_AND__IN2_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_R_TRIG__CLK_OR__IN1_AND__IN2_NOT, LC_this->LC_VD_VIX_TESTMODE, pEPDB);
    lFunction_R_TRIG__CLK_OR__IN1_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__2(&lFunction_R_TRIG__CLK_OR__IN1_AND, LC_this->LC_VD_VIX_SETOUT, lFunction_R_TRIG__CLK_OR__IN1_AND__IN2_NOT.LC_VD_NOT, pEPDB);
    lFunction_R_TRIG__CLK_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_R_TRIG__CLK_OR, lFunction_R_TRIG__CLK_OR__IN1_AND.LC_VD_AND, LC_this->LC_VD_LX_TEST, pEPDB);
    LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG.LC_VD_CLK = lFunction_R_TRIG__CLK_OR.LC_VD_OR;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS.LC_VD_S = LC_this->LC_VD_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_RS.LC_VD_R1 = LC_this->LC_VD_TON.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT = LC_this->LC_VD_RS.LC_VD_Q1;
  {
    LC_this->LC_VD_TON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON.LC_VD_IN = LC_this->LC_VD_RS.LC_VD_Q1;
    LC_this->LC_VD_TON.LC_VD_PT = LC_this->LC_VD_VIT_PULSETIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON), pEPDB);
  }
}

#endif
