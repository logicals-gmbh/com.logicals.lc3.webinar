#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST__C

#include <lcfu___com.logicals.basic.stringfind.fb_lc_findvalbycharinstring_st.h>
#include <LC3CGStmtFor.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST* p = LC_this; \
  LC_INIT_SIZED_STRING(&((p)->LC_VD_VISTR_IN)); \
  LC_INIT_SIZED_STRING_VAL((p)->LC_VD_VISTR_FINDCHAR,1,";"); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_NOELEM)); \
  LC_INIT_ARRAY_SIZED_STRING(&((p)->LC_VD_VOSTRARR_FIND),31,8); \
  LC_INIT_ARRAY(&((p)->LC_VD_VORARR_FIND),REAL,8); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD_LSTR_FINDCHAR)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_CHARIDX)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_LEN)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_POSSTART)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_POSEND)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_ARRIDX)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_UBOUND)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST* p = LC_this; \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD_VISTR_IN),RF); \
  if (RF==0) LC_INIT_SIZED_STRING_VAL((p)->LC_VD_VISTR_FINDCHAR,1,";"); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_NOELEM),RF); \
  LC_WINIT_ARRAY_SIZED_STRING(&((p)->LC_VD_VOSTRARR_FIND),31,8,RF); \
  LC_WINIT_ARRAY(&((p)->LC_VD_VORARR_FIND),REAL,8,RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD_LSTR_FINDCHAR),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_CHARIDX),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_LEN),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_POSSTART),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_POSEND),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_ARRIDX),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_UBOUND),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDVALBYCHARINSTRING_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_STRING_STACK_OFFSET offset = LC_STRING_STATEMENT_BUFFER(pEPDB);
  {
    LC_TD_Function_LEN__UINT lFunction_LEN;
    LC_INIT_Function_LEN__UINT(&lFunction_LEN);
    lFunction_LEN.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LEN__UINT(&lFunction_LEN, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), pEPDB);
    LC_this->LC_VD_LUI_LEN = lFunction_LEN.LC_VD_LEN;
    LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
  }
  LC_this->LC_VD_LUI_POSSTART = (LC_TD_UINT)1;
  LC_this->LC_VD_LUI_ARRIDX = (LC_TD_UINT)0;
  LC_this->LC_VD_VOUI_NOELEM = (LC_TD_UINT)0;
  LC_this->LC_VD_LUI_UBOUND = (LC_TD_UINT)8;
  {
    LC3_MST_FOR(LC_this->LC_VD_LUI_CHARIDX, (LC_TD_USINT)1, LC_this->LC_VD_LUI_LEN, (LC_TD_USINT)1,UINT, UINT);
    {
      {
        LC_TD_BOOL conditionResult = LC_EL_false;
        {
          LC_TD_Function_MID lFunction__leftOp_MID;
          LC_INIT_Function_MID(&lFunction__leftOp_MID);
          lFunction__leftOp_MID.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__MID__UINT(&lFunction__leftOp_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), (LC_TD_UINT)1, LC_this->LC_VD_LUI_CHARIDX, pEPDB);
          conditionResult = (LC_STRING_EQ(LC_GET_STRING_PTR(lFunction__leftOp_MID.LC_VD_MID),LC_this->LC_VD_VISTR_FINDCHAR,LC_STR_CMP_MODE_STRING));
        }
        LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
        if (conditionResult)
        {
          LC_this->LC_VD_VOUI_NOELEM = (LC_TD_UINT)(LC_this->LC_VD_VOUI_NOELEM + (LC_TD_UINT)1);
          LC_this->LC_VD_LUI_POSEND = (LC_TD_UINT)(LC_this->LC_VD_LUI_CHARIDX - (LC_TD_UINT)1);
          if ((LC_TD_BOOL)(LC_this->LC_VD_LUI_CHARIDX < LC_this->LC_VD_LUI_LEN))
          {
            {
              LC_TD_Function_MID lFunction_MID;
              LC_INIT_Function_MID(&lFunction_MID);
              lFunction_MID.LC_VD_ENO = LC_EL_true;
              LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOSTRARR_FIND,LC_this->LC_VD_LUI_ARRIDX,(LC_TD_DINT)0,(LC_TD_DINT)7),30);
              lcfu_iec61131__MID__UINT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), (LC_TD_UINT)(LC_this->LC_VD_LUI_POSEND - LC_this->LC_VD_LUI_POSSTART), LC_this->LC_VD_LUI_POSSTART, pEPDB);
              LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
            }
          }
          if ((LC_TD_BOOL)(LC_this->LC_VD_LUI_CHARIDX == LC_this->LC_VD_LUI_LEN))
          {
            {
              LC_TD_Function_MID lFunction_MID;
              LC_INIT_Function_MID(&lFunction_MID);
              lFunction_MID.LC_VD_ENO = LC_EL_true;
              LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOSTRARR_FIND,LC_this->LC_VD_LUI_ARRIDX,(LC_TD_DINT)0,(LC_TD_DINT)7),30);
              lcfu_iec61131__MID__UINT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), (LC_TD_UINT)(LC_this->LC_VD_LUI_LEN - LC_this->LC_VD_LUI_POSSTART), LC_this->LC_VD_LUI_POSSTART, pEPDB);
              LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
            }
          }
          LC_this->LC_VD_LUI_ARRIDX = (LC_TD_UINT)(LC_this->LC_VD_LUI_ARRIDX + (LC_TD_UINT)1);
          LC_this->LC_VD_LUI_POSSTART = (LC_TD_UINT)(LC_this->LC_VD_LUI_POSEND + (LC_TD_UINT)2);
        }
      }
    }
    LC3_MST_FOR_END(LC_this->LC_VD_LUI_CHARIDX, (LC_TD_USINT)1,LC_this->LC_VD_LUI_LEN, (LC_TD_USINT)1, UINT, UINT);
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOUI_NOELEM == (LC_TD_UINT)0))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOI_ERRNO = (LC_TD_INT)1;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOUI_NOELEM > LC_this->LC_VD_LUI_UBOUND))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOI_ERRNO = (LC_TD_INT)2;
  }
}

#endif
