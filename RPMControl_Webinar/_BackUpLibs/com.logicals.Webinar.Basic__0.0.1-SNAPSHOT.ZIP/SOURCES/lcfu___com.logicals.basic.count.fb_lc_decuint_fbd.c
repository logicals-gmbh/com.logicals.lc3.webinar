#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUINT_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUINT_FBD__C

#include <lcfu___com.logicals.basic.count.fb_lc_decuint_fbd.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUINT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUINT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SUB__UINT lFunction_SUB;
      LC_INIT_Function_SUB__UINT(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_CNT, (LC_TD_UINT)1, pEPDB);
      LC_this->LC_VD_CNT = lFunction_SUB.LC_VD_SUB;
      LC_this->LC_VD___2_SUB = lFunction_SUB.LC_VD_SUB;
    }
  }
}

#endif
