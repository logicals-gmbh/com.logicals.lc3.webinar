#ifndef LC_PROT_LCPU___PRG_LC_TESTFLASH1_FBD__C
#define LC_PROT_LCPU___PRG_LC_TESTFLASH1_FBD__C

#include <lcpu___prg_lc_testflash1_fbd.h>



/*                            Programs                         */
void  lcpu___PRG_LC_TESTFLASH1_FBD(LC_TD_Program_PRG_LC_TESTFLASH1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_FB_LC_FLASH_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_LC_FLASH_FBD.LC_VD_START = LC_this->LC_VD_LX_FLASHSTART;
      lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD(&(LC_this->LC_VD_FB_LC_FLASH_FBD), pEPDB);
      LC_this->LC_VD_LX_FLASHOUT = LC_this->LC_VD_FB_LC_FLASH_FBD.LC_VD_OUT;
    }
  }
  /* Network 2 */
  {
    {
      LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VIX_START = LC_this->LC_VD_LX_FLASH2_START;
      LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VIT_ONTIME = LC_this->LC_VD_LT_FLASH2_ONTIMEPAR;
      LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VIT_OFFTIME = LC_this->LC_VD_LT_FLASH2_OFFTIMEPAR;
      LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VIX_SELPAR = LC_this->LC_VD_LX_FLASH2_SELPAR;
      lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(&(LC_this->LC_VD_FB_LC_FLASH2_FBD), pEPDB);
      LC_this->LC_VD_LX_FLASH2_OUT = LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VOX_OUT;
      LC_this->LC_VD_LT_FLASH2_ONTIME = LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VOT_ONTIME;
      LC_this->LC_VD_LT_FLASH2_OFFTIME = LC_this->LC_VD_FB_LC_FLASH2_FBD.LC_VD_VOT_OFFTIME;
    }
  }
  /* Network 3 */
  {
    {
      LC_this->LC_VD_FB_LC_FLASH3_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_LC_FLASH3_FBD.LC_VD_VIX_START = LC_this->LC_VD_LX_FLASH3_START;
      lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH3_FBD(&(LC_this->LC_VD_FB_LC_FLASH3_FBD), pEPDB);
      LC_this->LC_VD_LX_FLASH3_OUT = LC_this->LC_VD_FB_LC_FLASH3_FBD.LC_VD_VOX_OUT;
      LC_this->LC_VD_LT_FLASH3_ONTIME = LC_this->LC_VD_FB_LC_FLASH3_FBD.LC_VD_VOT_ONTIME;
      LC_this->LC_VD_LT_FLASH3_OFFTIME = LC_this->LC_VD_FB_LC_FLASH3_FBD.LC_VD_VOT_OFFTIME;
    }
  }
  /* Network 4 */
  {
    {
      LC_this->LC_VD_FB_LC_FLASH_2HZ_FBD.LC_VD_ENO = LC_EL_true;
      lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD(&(LC_this->LC_VD_FB_LC_FLASH_2HZ_FBD), pEPDB);
      LC_this->LC_VD_LX_FLASH2HZ_OUT = LC_this->LC_VD_FB_LC_FLASH_2HZ_FBD.LC_VD_VOX_OUT;
    }
  }
  /* Network 5 */
  {
    {
      LC_this->LC_VD_FB_LC_FLASH_4HZ_FBD.LC_VD_ENO = LC_EL_true;
      lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_4HZ_FBD(&(LC_this->LC_VD_FB_LC_FLASH_4HZ_FBD), pEPDB);
      LC_this->LC_VD_LX_FLASH4HZ_OUT = LC_this->LC_VD_FB_LC_FLASH_4HZ_FBD.LC_VD_VOX_OUT;
    }
  }
}

#endif
