#ifndef LC_PROT_LCPU___PRG_LC_TESTSELECT1_FBD__C
#define LC_PROT_LCPU___PRG_LC_TESTSELECT1_FBD__C

#include <lcpu___prg_lc_testselect1_fbd.h>



/*                            Programs                         */
void  lcpu___PRG_LC_TESTSELECT1_FBD(LC_TD_Program_PRG_LC_TESTSELECT1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_COM_LOGICALS_BASIC_SELECT_FB_LC_SELECT_FBD1.LC_VD_ENO = LC_EL_true;
      lcfu___COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(&(LC_this->LC_VD_COM_LOGICALS_BASIC_SELECT_FB_LC_SELECT_FBD1), pEPDB);
    }
  }
}

#endif
