#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST__C

#include <lcfu___com.logicals.basic.control.fb_lc_cntrl_scale_st.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MAXINVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MININVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MAXPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MINPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_OFFSETPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUTPHYSVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_INVALERROR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_PHYSVALERROR)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DIFFINVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_LR_DIFFINVAL_NOTZERO)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DIFFPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_A)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_A_MUL_X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_A_MUL_X_PLUS_B)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_INVALERROR)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MAXINVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MININVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MAXPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MINPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_OFFSETPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUTPHYSVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_INVALERROR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_PHYSVALERROR),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DIFFINVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LR_DIFFINVAL_NOTZERO),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DIFFPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_A),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_A_MUL_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_A_MUL_X_PLUS_B),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_INVALERROR),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_SCALE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_SUB__REAL lFunction_SUB;
    LC_INIT_Function_SUB__REAL(&lFunction_SUB);
    lFunction_SUB.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_MAXINVAL, LC_this->LC_VD_VIR_MININVAL, pEPDB);
    LC_this->LC_VD_LR_DIFFINVAL = lFunction_SUB.LC_VD_SUB;
  }
  {
    LC_TD_Function_SUB__REAL lFunction_NE__IN1_SUB;
    LC_TD_Function_NE lFunction_NE;
    LC_INIT_Function_SUB__REAL(&lFunction_NE__IN1_SUB);
    LC_INIT_Function_NE(&lFunction_NE);
    lFunction_NE__IN1_SUB.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SUB__ANY(&lFunction_NE__IN1_SUB, LC_this->LC_VD_VIR_MAXINVAL, LC_this->LC_VD_VIR_MININVAL, pEPDB);
    lFunction_NE.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NE__ANY(&lFunction_NE, lFunction_NE__IN1_SUB.LC_VD_SUB, (LC_TD_REAL)0.0, pEPDB);
    LC_this->LC_VD_LR_DIFFINVAL_NOTZERO = lFunction_NE.LC_VD_NE;
  }
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_SUB__REAL lFunction_NE__IN1_SUB;
      LC_TD_Function_NE lFunction_NE;
      LC_INIT_Function_SUB__REAL(&lFunction_NE__IN1_SUB);
      LC_INIT_Function_NE(&lFunction_NE);
      lFunction_NE__IN1_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_NE__IN1_SUB, LC_this->LC_VD_VIR_MAXINVAL, LC_this->LC_VD_VIR_MININVAL, pEPDB);
      lFunction_NE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NE__ANY(&lFunction_NE, lFunction_NE__IN1_SUB.LC_VD_SUB, (LC_TD_REAL)0.0, pEPDB);
      conditionResult = lFunction_NE.LC_VD_NE;
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)1;
      LC_this->LC_VD_VOX_ERR = LC_EL_true;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_ERR == LC_EL_false))
  {
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_MAXPHYSVAL, LC_this->LC_VD_VIR_MINPHYSVAL, pEPDB);
      LC_this->LC_VD_LR_DIFFPHYSVAL = lFunction_SUB.LC_VD_SUB;
    }
    if (LC_this->LC_VD_LR_DIFFINVAL_NOTZERO)
    {
      {
        LC_TD_Function_DIV__REAL lFunction_DIV;
        LC_INIT_Function_DIV__REAL(&lFunction_DIV);
        if ((lFunction_DIV.LC_VD_ENO = LC_this->LC_VD_LR_DIFFINVAL_NOTZERO) != LC_EL_false)
        {
          lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD_LR_DIFFPHYSVAL, LC_this->LC_VD_LR_DIFFINVAL, pEPDB);
          LC_this->LC_VD_LR_A = lFunction_DIV.LC_VD_DIV;
        }
      }
      LC_this->LC_VD_LX_INVALERROR = LC_EL_false;
    }
    else
    {
      LC_this->LC_VD_LR_A = (LC_TD_REAL)0;
      LC_this->LC_VD_LX_INVALERROR = LC_EL_true;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_LR_A, pEPDB);
      LC_this->LC_VD_LR_A_MUL_X = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_GT lFunction_OR__IN1_GT;
      LC_TD_Function_LT lFunction_OR__IN2_LT;
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_GT(&lFunction_OR__IN1_GT);
      LC_INIT_Function_LT(&lFunction_OR__IN2_LT);
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR__IN1_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_OR__IN1_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MAXINVAL, pEPDB);
      lFunction_OR__IN2_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_OR__IN2_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MININVAL, pEPDB);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, lFunction_OR__IN1_GT.LC_VD_GT, lFunction_OR__IN2_LT.LC_VD_LT, LC_this->LC_VD_LX_INVALERROR, pEPDB);
      LC_this->LC_VD_VOX_INVALERROR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LR_DIFFINVAL_NOTZERO, pEPDB);
      LC_this->LC_VD_VOX_PHYSVALERROR = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LR_A_MUL_X, LC_this->LC_VD_VIR_OFFSETPHYSVAL, pEPDB);
      LC_this->LC_VD_LR_A_MUL_X_PLUS_B = lFunction_ADD.LC_VD_ADD;
    }
    LC_this->LC_VD_VOR_OUTPHYSVAL = LC_this->LC_VD_LR_A_MUL_X_PLUS_B;
  }
}

#endif
