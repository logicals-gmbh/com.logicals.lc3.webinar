#ifndef LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_FBD__C
#define LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_FBD__C

#include <lcpu___prg_lc_testactuator1_fbd.h>
#include <LC3Globals.h>



/*                            Programs                         */
void  lcpu___PRG_LC_TESTACTUATOR1_FBD(LC_TD_Program_PRG_LC_TESTACTUATOR1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_RTSCYCLEINFO lFunction_RTSCYCLEINFO;
      LC_INIT_Function_RTSCYCLEINFO(&lFunction_RTSCYCLEINFO);
      lFunction_RTSCYCLEINFO.LC_VD_ENO = LC_EL_true;
      lcfu_logilibrary__RTSCYCLEINFO(&lFunction_RTSCYCLEINFO, pEPDB);
      LC_this->LC_VD_LX_INIT = lFunction_RTSCYCLEINFO.LC_VD_INIT;
      LC_this->LC_VD___58_INIT = lFunction_RTSCYCLEINFO.LC_VD_INIT;
      LC_this->LC_VD_LX_RUN = lFunction_RTSCYCLEINFO.LC_VD_RUN;
      LC_this->LC_VD___58_RUN = lFunction_RTSCYCLEINFO.LC_VD_RUN;
      LC_this->LC_VD_LX_SHUTDOWN = lFunction_RTSCYCLEINFO.LC_VD_SHUTDOWN;
      LC_this->LC_VD___58_SHUTDOWN = lFunction_RTSCYCLEINFO.LC_VD_SHUTDOWN;
      LC_this->LC_VD_LX_TERM = lFunction_RTSCYCLEINFO.LC_VD_TERM;
      LC_this->LC_VD___58_TERM = lFunction_RTSCYCLEINFO.LC_VD_TERM;
    }
  }
  /* Network 2 */
  {
    {
      LC_this->LC_VD_FORCEMRK1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK1.LC_VD_IN = LC_GV_READ_ELEM(pEPDB,LC_VD_GX_STARTLEFT,LC_TD_BOOL);
      lcfu_iec61131__FORCEMRK__BOOL(&(LC_this->LC_VD_FORCEMRK1), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_FORCEMRK1.LC_VD_OUT, LC_this->LC_VD_LX_STARTLEFT, pEPDB);
      LC_this->LC_VD___27_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_FORCEMRK2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK2.LC_VD_IN = LC_GV_READ_ELEM(pEPDB,LC_VD_GX_STARTRIGHT,LC_TD_BOOL);
      lcfu_iec61131__FORCEMRK__BOOL(&(LC_this->LC_VD_FORCEMRK2), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_FORCEMRK2.LC_VD_OUT, LC_this->LC_VD_LX_STARTRIGHT, pEPDB);
      LC_this->LC_VD___30_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_FORCEMRK3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK3.LC_VD_IN = LC_GV_READ_ELEM(pEPDB,LC_VD_GX_MOTORSTOP,LC_TD_BOOL);
      lcfu_iec61131__FORCEMRK__BOOL(&(LC_this->LC_VD_FORCEMRK3), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_FORCEMRK3.LC_VD_OUT, LC_this->LC_VD_LX_MOTORSTOP, pEPDB);
      LC_this->LC_VD___33_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_VIX_STARTLEFT = LC_this->LC_VD___27_OR;
      LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_VIX_STARTRIGHT = LC_this->LC_VD___30_OR;
      LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_VIX_STOP = LC_this->LC_VD___33_OR;
      lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_FBD(&(LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD), pEPDB);
    }
    {
      LC_this->LC_VD_FORCEMRK4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK4.LC_VD_IN = LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_VOX_MOTORLEFT;
      lcfu_iec61131__FORCEMRK__BOOL(&(LC_this->LC_VD_FORCEMRK4), pEPDB);
      LC_GV_WRITE_ELEM(pEPDB,LC_VD_GX_MOTORLEFT,LC_TD_BOOL) = LC_this->LC_VD_FORCEMRK4.LC_VD_OUT;
    }
    {
      LC_this->LC_VD_FORCEMRK5.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK5.LC_VD_IN = LC_this->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD.LC_VD_VOX_MOTORRIGHT;
      lcfu_iec61131__FORCEMRK__BOOL(&(LC_this->LC_VD_FORCEMRK5), pEPDB);
      LC_GV_WRITE_ELEM(pEPDB,LC_VD_GX_MOTORRIGHT,LC_TD_BOOL) = LC_this->LC_VD_FORCEMRK5.LC_VD_OUT;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_GV_READ_ELEM(pEPDB,LC_VD_GX_MOTORLEFT,LC_TD_BOOL), LC_GV_READ_ELEM(pEPDB,LC_VD_GX_LIGHTBARRIER1,LC_TD_BOOL), pEPDB);
      LC_this->LC_VD___45_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_GV_READ_ELEM(pEPDB,LC_VD_GX_MOTORRIGHT,LC_TD_BOOL), LC_GV_READ_ELEM(pEPDB,LC_VD_GX_LIGHTBARRIER1,LC_TD_BOOL), pEPDB);
      LC_this->LC_VD___48_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_LX_RESET, LC_this->LC_VD_LX_INIT, pEPDB);
      LC_this->LC_VD___68_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_CTUD_DINT1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_CTUD_DINT1.LC_VD_CU = LC_this->LC_VD___45_AND;
      LC_this->LC_VD_CTUD_DINT1.LC_VD_CD = LC_this->LC_VD___48_AND;
      LC_this->LC_VD_CTUD_DINT1.LC_VD_R = LC_this->LC_VD___68_OR;
      lcfu_iec61131__CTUD_DINT(&(LC_this->LC_VD_CTUD_DINT1), pEPDB);
    }
    {
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT;
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT);
      lFunction_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__DINT(&lFunction_TO_UDINT, LC_this->LC_VD_CTUD_DINT1.LC_VD_CV, pEPDB);
      LC_this->LC_VD_LUDI_COUNTVAL = lFunction_TO_UDINT.LC_VD_TO_UDINT;
      LC_this->LC_VD___55_TO_UDINT = lFunction_TO_UDINT.LC_VD_TO_UDINT;
    }
  }
}

#endif
