#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_convrealto2int_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__DIV.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_HVAL)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_LVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_SIGN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MILL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_00THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_0THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_HUN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_TEN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_DSINGLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_DSING)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_DTEN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_DHUN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_DOT)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_TEMPVAL1)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_TEMPVAL2)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_HVAL)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_LVAL)); \
  (p)->LC_VD_LR_MILL = (LC_TD_REAL)1000000000.0; \
  (p)->LC_VD_LR_00THOUS = (LC_TD_REAL)100000000.0; \
  (p)->LC_VD_LR_0THOUS = (LC_TD_REAL)10000000.0; \
  (p)->LC_VD_LR_THOUS = (LC_TD_REAL)1000000.0; \
  (p)->LC_VD_LR_HUN = (LC_TD_REAL)100000.0; \
  (p)->LC_VD_LR_TEN = (LC_TD_REAL)10000.0; \
  (p)->LC_VD_LR_DSINGLE = (LC_TD_REAL)1000.0; \
  (p)->LC_VD_LR_DSING = (LC_TD_REAL)100.0; \
  (p)->LC_VD_LR_DTEN = (LC_TD_REAL)10.0; \
  (p)->LC_VD_LR_DHUN = (LC_TD_REAL)1.0; \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_HVAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_LVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_SIGN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MILL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_00THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_0THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_HUN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_TEN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_DSINGLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_DSING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_DTEN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_DHUN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_DOT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_TEMPVAL1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_TEMPVAL2),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_HVAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_LVAL),RF); \
  if (RF==0) (p)->LC_VD_LR_MILL = (LC_TD_REAL)1000000000.0; \
  if (RF==0) (p)->LC_VD_LR_00THOUS = (LC_TD_REAL)100000000.0; \
  if (RF==0) (p)->LC_VD_LR_0THOUS = (LC_TD_REAL)10000000.0; \
  if (RF==0) (p)->LC_VD_LR_THOUS = (LC_TD_REAL)1000000.0; \
  if (RF==0) (p)->LC_VD_LR_HUN = (LC_TD_REAL)100000.0; \
  if (RF==0) (p)->LC_VD_LR_TEN = (LC_TD_REAL)10000.0; \
  if (RF==0) (p)->LC_VD_LR_DSINGLE = (LC_TD_REAL)1000.0; \
  if (RF==0) (p)->LC_VD_LR_DSING = (LC_TD_REAL)100.0; \
  if (RF==0) (p)->LC_VD_LR_DTEN = (LC_TD_REAL)10.0; \
  if (RF==0) (p)->LC_VD_LR_DHUN = (LC_TD_REAL)1.0; \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_LI_CYCLECOUNT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNT + (LC_TD_INT)1);
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LX_CYCLEINIT = LC_EL_true;
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_CYCLEINIT == LC_EL_true))
  {
    LC_this->LC_VD_LI_CYCLECOUNTINIT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNTINIT + (LC_TD_INT)1);
    LC_this->LC_VD_LR_MILL = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)1000000000.0));
    LC_this->LC_VD_LR_00THOUS = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)100000000.0));
    LC_this->LC_VD_LR_0THOUS = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)10000000.0));
    LC_this->LC_VD_LR_THOUS = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)1000000.0));
    LC_this->LC_VD_LR_HUN = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)100000.0));
    LC_this->LC_VD_LR_TEN = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)10000.0));
    LC_this->LC_VD_LR_DSINGLE = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)1000.0));
    LC_this->LC_VD_LR_DSING = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)100.0));
    LC_this->LC_VD_LR_DTEN = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)10.0));
    LC_this->LC_VD_LR_DHUN = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,(LC_TD_REAL)1.0));
  }
  LC_this->LC_VD_VOX_SIGN = LC_EL_false;
  LC_this->LC_VD_VOX_MILL = LC_EL_false;
  LC_this->LC_VD_VOX_00THOUS = LC_EL_false;
  LC_this->LC_VD_VOX_0THOUS = LC_EL_false;
  LC_this->LC_VD_VOX_THOUS = LC_EL_false;
  LC_this->LC_VD_VOX_HUN = LC_EL_false;
  LC_this->LC_VD_VOX_TEN = LC_EL_false;
  LC_this->LC_VD_VOX_DSINGLE = LC_EL_false;
  LC_this->LC_VD_VOX_DSING = LC_EL_false;
  LC_this->LC_VD_VOX_DTEN = LC_EL_false;
  LC_this->LC_VD_VOX_DHUN = LC_EL_false;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIR_VAL >= (LC_TD_REAL)0.0))
  {
    LC_this->LC_VD_VOX_SIGN = LC_EL_true;
  }
  else
  {
    LC_this->LC_VD_VOX_SIGN = LC_EL_false;
  }
  {
    LC_TD_Function_TO_DINT lFunction_TO_DINT;
    LC_INIT_Function_TO_DINT(&lFunction_TO_DINT);
    lFunction_TO_DINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DINT__REAL(&lFunction_TO_DINT, LC_this->LC_VD_VIR_VAL, pEPDB);
    LC_this->LC_VD_LDI_HVAL = lFunction_TO_DINT.LC_VD_TO_DINT;
  }
  {
    LC_TD_Function_TO_REAL lFunction_TO_REAL;
    LC_INIT_Function_TO_REAL(&lFunction_TO_REAL);
    lFunction_TO_REAL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_REAL__DINT(&lFunction_TO_REAL, LC_this->LC_VD_LDI_HVAL, pEPDB);
    LC_this->LC_VD_LR_TEMPVAL1 = lFunction_TO_REAL.LC_VD_TO_REAL;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_SIGN == LC_EL_true))
  {
    {
      LC_TD_Function_ABS__REAL lFunction__rightOp_ABS;
      LC_INIT_Function_ABS__REAL(&lFunction__rightOp_ABS);
      lFunction__rightOp_ABS.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ABS__REAL(&lFunction__rightOp_ABS, LC_this->LC_VD_LR_TEMPVAL1, pEPDB);
      LC_this->LC_VD_LR_TEMPVAL2 = (LC_TD_REAL)(LC_this->LC_VD_VIR_VAL - lFunction__rightOp_ABS.LC_VD_ABS);
    }
  }
  else
  {
    {
      LC_TD_Function_ABS__REAL lFunction__rightOp_ABS;
      LC_INIT_Function_ABS__REAL(&lFunction__rightOp_ABS);
      lFunction__rightOp_ABS.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ABS__REAL(&lFunction__rightOp_ABS, LC_this->LC_VD_LR_TEMPVAL1, pEPDB);
      LC_this->LC_VD_LR_TEMPVAL2 = (LC_TD_REAL)(LC_this->LC_VD_VIR_VAL + lFunction__rightOp_ABS.LC_VD_ABS);
    }
  }
  {
    LC_TD_Function_TO_DINT lFunction_TO_DINT;
    LC_INIT_Function_TO_DINT(&lFunction_TO_DINT);
    lFunction_TO_DINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DINT__REAL(&lFunction_TO_DINT, LC_this->LC_VD_LR_TEMPVAL2, pEPDB);
    LC_this->LC_VD_LDI_LVAL = lFunction_TO_DINT.LC_VD_TO_DINT;
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_MILL),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_00THOUS)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_MILL = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_00THOUS),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_0THOUS)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_00THOUS = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_0THOUS),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_THOUS)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_0THOUS = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_THOUS),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_HUN)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_THOUS = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_HUN),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_TEN)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_HUN = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_TEN),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_DSINGLE)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_TEN = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_DSINGLE),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_DSING)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_DSINGLE = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_DSING),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_DTEN)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_DSING = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_DSING),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_DTEN)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_DTEN = LC_EL_true;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 >= LC_this->LC_VD_LR_DTEN),(LC_TD_BOOL)(LC_this->LC_VD_LR_TEMPVAL2 < LC_this->LC_VD_LR_DHUN)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_DHUN = LC_EL_true;
    }
  }
  LC_this->LC_VD_VODI_HVAL = LC_this->LC_VD_LDI_HVAL;
  LC_this->LC_VD_VODI_LVAL = LC_this->LC_VD_LDI_LVAL;
  LC_this->LC_VD_LX_CYCLEINIT = LC_EL_false;
}

#endif
