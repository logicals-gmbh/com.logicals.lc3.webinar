#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFUN_LC_CONVBYTE2STR_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFUN_LC_CONVBYTE2STR_ST__C

#include <lcfu___com.logicals.basic.convert.fun_lc_convbyte2str_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFUN_LC_CONVBYTE2STR_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFUN_LC_CONVBYTE2STR_ST* LC_this, LC_TD_BYTE LC_VD_VB_IN, LC_TD_BOOL LC_VD_VIX_SET2UPPERCASE, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_BYTE LC_VD_LB_IN;
  LC_INIT_BYTE(&(LC_VD_LB_IN));
  LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"",0,&LC_this->LC_VD_ENO);
  if ((LC_TD_BOOL)(LC_VD_VIX_SET2UPPERCASE == LC_EL_true))
  {
    LC_VD_LB_IN = LC_VD_VB_IN;
  }
  else
  {
    LC_VD_LB_IN = LC_VD_VB_IN;
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)48))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"0",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)49))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"1",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)50))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"2",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)51))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"3",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)52))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"4",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)53))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"5",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)54))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"6",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)55))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"7",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)56))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"8",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)57))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"9",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)65))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"A",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)66))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"B",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)67))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"C",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)68))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"D",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)69))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"E",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)70))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"F",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)71))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"G",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)72))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"H",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)73))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"I",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)74))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"J",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)75))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"K",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)76))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"L",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)77))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"M",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)78))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"N",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)79))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"O",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)80))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"P",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)81))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"Q",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)82))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"R",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)83))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"S",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)84))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"T",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)85))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"U",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)86))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"V",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)87))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"W",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)88))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"X",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)89))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"Y",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)90))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"Z",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)97))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"a",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)98))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"b",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)99))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"c",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)100))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"d",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)101))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"e",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)102))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"f",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)103))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"g",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)104))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"h",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)105))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"i",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)106))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"j",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)107))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"k",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)108))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"l",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)109))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"m",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)110))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"n",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)111))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"o",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)112))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"p",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)113))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"q",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)114))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"r",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)115))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"s",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)116))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"t",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)117))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"u",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)118))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"v",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)119))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"w",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)120))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"x",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)121))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"y",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)122))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"z",1,&LC_this->LC_VD_ENO);
  }
  if ((LC_TD_BOOL)(LC_VD_VB_IN == (LC_TD_BYTE)47))
  {
    LC_MOV_STRING(LC_this->LC_VD_FUN_LC_CONVBYTE2STR_ST,1,"/",1,&LC_this->LC_VD_ENO);
  }
}

#endif
