#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVINT2BYTE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVINT2BYTE_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_convint2byte_st.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVINT2BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVINT2BYTE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_TO_WORD lFunction_TO_WORD;
    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_WORD__INT(&lFunction_TO_WORD, LC_this->LC_VD_VII_IN, pEPDB);
    LC_this->LC_VD_LW_OUTWRD = lFunction_TO_WORD.LC_VD_TO_WORD;
  }
  {
    LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
    LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
    lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_BYTE__WORD(&lFunction_TO_BYTE, LC_this->LC_VD_LW_OUTWRD, pEPDB);
    LC_this->LC_VD_LW_OUTLOWBYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
  }
  {
    LC_TD_Function_ROR__WORD lFunction_TO_BYTE__IN_ROR;
    LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
    LC_INIT_Function_ROR__WORD(&lFunction_TO_BYTE__IN_ROR);
    LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
    lFunction_TO_BYTE__IN_ROR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__ROR__WORD(&lFunction_TO_BYTE__IN_ROR, LC_this->LC_VD_LW_OUTWRD, (LC_TD_INT)8, pEPDB);
    lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_BYTE__WORD(&lFunction_TO_BYTE, lFunction_TO_BYTE__IN_ROR.LC_VD_ROR, pEPDB);
    LC_this->LC_VD_LW_OUTHIGHBYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
  }
  LC_this->LC_VD_VOB_LBYTE = LC_this->LC_VD_LW_OUTLOWBYTE;
  LC_this->LC_VD_VOB_HBYTE = LC_this->LC_VD_LW_OUTHIGHBYTE;
}

#endif
