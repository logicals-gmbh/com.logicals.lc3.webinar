#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST__C

#include <lcfu___com.logicals.basic.flash.fb_lc_flash_st.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_NOT__BOOL lFunction_FB_TON__IN_AND__IN2_NOT;
    LC_TD_Function_AND__BOOL lFunction_FB_TON__IN_AND;
    LC_INIT_Function_NOT__BOOL(&lFunction_FB_TON__IN_AND__IN2_NOT);
    LC_INIT_Function_AND__BOOL(&lFunction_FB_TON__IN_AND);
    lFunction_FB_TON__IN_AND__IN2_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_FB_TON__IN_AND__IN2_NOT, LC_this->LC_VD_FB_TON1.LC_VD_Q, pEPDB);
    lFunction_FB_TON__IN_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__2(&lFunction_FB_TON__IN_AND, LC_this->LC_VD_VIX_START, lFunction_FB_TON__IN_AND__IN2_NOT.LC_VD_NOT, pEPDB);
    LC_this->LC_VD_FB_TON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_TON.LC_VD_IN = lFunction_FB_TON__IN_AND.LC_VD_AND;
    LC_this->LC_VD_FB_TON.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_TON), pEPDB);
  }
  {
    LC_this->LC_VD_FB_TON1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_TON1.LC_VD_IN = LC_this->LC_VD_FB_TON.LC_VD_Q;
    LC_this->LC_VD_FB_TON1.LC_VD_PT = LC_this->LC_VD_VIT_OFFTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_TON1), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT = LC_this->LC_VD_FB_TON.LC_VD_Q;
}

#endif
