#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEINT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEINT_ST__C

#include <lcfu___com.logicals.basic.change.fb_lc_changeint_st.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEINT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEINT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_NE lFunction_NE;
      LC_INIT_Function_NE(&lFunction_NE);
      lFunction_NE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NE__ANY(&lFunction_NE, LC_this->LC_VD_LI_OLDVAL, LC_this->LC_VD_VII_IN, pEPDB);
      conditionResult = lFunction_NE.LC_VD_NE;
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT = LC_EL_false;
    }
  }
  LC_this->LC_VD_LI_OLDVAL = LC_this->LC_VD_VII_IN;
}

#endif
