#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD__C

#include <lcfu___com.logicals.basic.convert.fb_lc_strto10byte_fbd.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD* p = LC_this; \
  LC_INIT_SIZED_STRING(&((p)->LC_VD_VISTR_IN_127)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE0)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE1)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE2)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE3)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE4)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE5)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE6)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE7)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE8)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_BYTE9)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE1)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE2)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE3)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE4)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE5)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE6)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE7)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE8)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE9)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___141_MID)); \
  LC_INIT_INT(&((p)->LC_VD___142_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___143_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___144_MID)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___145_MID)); \
  LC_INIT_INT(&((p)->LC_VD___146_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___147_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___148_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___149_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___150_MID)); \
  LC_INIT_INT(&((p)->LC_VD___151_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___152_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___153_MID)); \
  LC_INIT_INT(&((p)->LC_VD___154_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___155_MID)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___156_MID)); \
  LC_INIT_INT(&((p)->LC_VD___157_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___158_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___159_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___160_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___161_MID)); \
  LC_INIT_INT(&((p)->LC_VD___162_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___163_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___164_MID)); \
  LC_INIT_INT(&((p)->LC_VD___165_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___166_TO_INT)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD___167_MID)); \
  LC_INIT_INT(&((p)->LC_VD___168_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___169_TO_INT)); \
  LC_INIT_INT(&((p)->LC_VD___170_TO_INT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD* p = LC_this; \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD_VISTR_IN_127),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE0),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE1),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE2),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE3),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE4),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE5),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE6),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE7),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE8),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_BYTE9),RF); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE1),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE2),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE3),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE4),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE5),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE6),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE7),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE8),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&((p)->LC_VD_FB_LC_CHRTOBYTE9),0); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___141_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___142_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___143_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___144_MID),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___145_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___146_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___147_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___148_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___149_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___150_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___151_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___152_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___153_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___154_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___155_MID),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___156_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___157_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___158_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___159_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___160_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___161_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___162_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___163_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___164_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___165_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___166_TO_INT),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD___167_MID),RF); \
  LC_WINIT_INT(&((p)->LC_VD___168_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___169_TO_INT),RF); \
  LC_WINIT_INT(&((p)->LC_VD___170_TO_INT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_STRTO10BYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_STRING_STACK_OFFSET offset = LC_STRING_STATEMENT_BUFFER(pEPDB);
  /* Network 1 */
  {
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___148_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___160_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___153_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___148_TO_INT, LC_this->LC_VD___160_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE2.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE2.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___153_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE2), pEPDB);
      LC_this->LC_VD_VOB_BYTE0 = LC_this->LC_VD_FB_LC_CHRTOBYTE2.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___142_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)2, pEPDB);
      LC_this->LC_VD___143_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___141_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___142_TO_INT, LC_this->LC_VD___143_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE1.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE1.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___141_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE1), pEPDB);
      LC_this->LC_VD_VOB_BYTE1 = LC_this->LC_VD_FB_LC_CHRTOBYTE1.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___169_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)3, pEPDB);
      LC_this->LC_VD___159_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___144_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___169_TO_INT, LC_this->LC_VD___159_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___144_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE), pEPDB);
      LC_this->LC_VD_VOB_BYTE2 = LC_this->LC_VD_FB_LC_CHRTOBYTE.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___168_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)4, pEPDB);
      LC_this->LC_VD___170_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___167_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___168_TO_INT, LC_this->LC_VD___170_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE3.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE3.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___167_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE3), pEPDB);
      LC_this->LC_VD_VOB_BYTE3 = LC_this->LC_VD_FB_LC_CHRTOBYTE3.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___149_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)5, pEPDB);
      LC_this->LC_VD___157_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___156_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___149_TO_INT, LC_this->LC_VD___157_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE4.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE4.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___156_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE4), pEPDB);
      LC_this->LC_VD_VOB_BYTE4 = LC_this->LC_VD_FB_LC_CHRTOBYTE4.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___154_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)6, pEPDB);
      LC_this->LC_VD___158_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___155_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___154_TO_INT, LC_this->LC_VD___158_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE5.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE5.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___155_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE5), pEPDB);
      LC_this->LC_VD_VOB_BYTE5 = LC_this->LC_VD_FB_LC_CHRTOBYTE5.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___151_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)7, pEPDB);
      LC_this->LC_VD___152_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___150_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___151_TO_INT, LC_this->LC_VD___152_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE6.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE6.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___150_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE6), pEPDB);
      LC_this->LC_VD_VOB_BYTE6 = LC_this->LC_VD_FB_LC_CHRTOBYTE6.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___165_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)8, pEPDB);
      LC_this->LC_VD___166_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___164_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___165_TO_INT, LC_this->LC_VD___166_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE7.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE7.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___164_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE7), pEPDB);
      LC_this->LC_VD_VOB_BYTE7 = LC_this->LC_VD_FB_LC_CHRTOBYTE7.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___146_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)9, pEPDB);
      LC_this->LC_VD___147_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___145_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___146_TO_INT, LC_this->LC_VD___147_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE8.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE8.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___145_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE8), pEPDB);
      LC_this->LC_VD_VOB_BYTE8 = LC_this->LC_VD_FB_LC_CHRTOBYTE8.LC_VD_VOB_OUT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BOOL(&lFunction_TO_INT, LC_EL_true, pEPDB);
      LC_this->LC_VD___162_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_TO_INT lFunction_TO_INT;
      LC_INIT_Function_TO_INT(&lFunction_TO_INT);
      lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_INT__BYTE(&lFunction_TO_INT, (LC_TD_BYTE)10, pEPDB);
      LC_this->LC_VD___163_TO_INT = lFunction_TO_INT.LC_VD_TO_INT;
    }
    {
      LC_TD_Function_MID lFunction_MID;
      LC_INIT_Function_MID(&lFunction_MID);
      lFunction_MID.LC_VD_ENO = LC_EL_true;
      LCCG_InitStringStruct(lFunction_MID.LC_VD_MID,LC_this->LC_VD___161_MID,255);
      lcfu_iec61131__MID__INT(&lFunction_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN_127,127), LC_this->LC_VD___162_TO_INT, LC_this->LC_VD___163_TO_INT, pEPDB);
    }
    {
      LC_this->LC_VD_FB_LC_CHRTOBYTE9.LC_VD_ENO = LC_EL_true;
      LC_MOV_STRING(LC_this->LC_VD_FB_LC_CHRTOBYTE9.LC_VD_VISTR_CHR_127,127,LC_this->LC_VD___161_MID,255,&LC_this->LC_VD_ENO);
      lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(&(LC_this->LC_VD_FB_LC_CHRTOBYTE9), pEPDB);
      LC_this->LC_VD_VOB_BYTE9 = LC_this->LC_VD_FB_LC_CHRTOBYTE9.LC_VD_VOB_OUT;
    }
    LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
  }
}

#endif
