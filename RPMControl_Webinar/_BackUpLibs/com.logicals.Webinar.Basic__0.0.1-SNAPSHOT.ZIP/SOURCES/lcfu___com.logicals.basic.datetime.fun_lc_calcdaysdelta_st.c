#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSDELTA_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSDELTA_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_calcdaysdelta_st.h>
#include <lcfu_iec61131__DIV.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSDELTA_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSDELTA_ST* LC_this, LC_TD_DATE LC_VD_VIDATE_DATE1, LC_TD_DATE LC_VD_VIDATE_DATE2, struct _lcoplck_epdb_1_impl* pEPDB)
{
  if ((LC_TD_BOOL)(LC_VD_VIDATE_DATE1 > LC_VD_VIDATE_DATE2))
  {
    {
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT;
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT;
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT;
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT);
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT);
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT);
      lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__DATE(&lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT, LC_VD_VIDATE_DATE1, pEPDB);
      lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__DATE(&lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT, LC_VD_VIDATE_DATE2, pEPDB);
      lFunction_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__UDINT(&lFunction_TO_UDINT, (lcfu_iec61131__DIV__UDINT__INL((LC_TD_UDINT)(lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT - lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT.LC_VD_TO_UDINT),(LC_TD_UDINT)86400UL)), pEPDB);
      LC_this->LC_VD_FUN_LC_CALCDAYSDELTA_ST = (-(lFunction_TO_UDINT.LC_VD_TO_UDINT));
    }
  }
  else
  {
    {
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT;
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT;
      LC_TD_Function_TO_UDINT lFunction_TO_UDINT;
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT);
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT);
      LC_INIT_Function_TO_UDINT(&lFunction_TO_UDINT);
      lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__DATE(&lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT, LC_VD_VIDATE_DATE2, pEPDB);
      lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__DATE(&lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT, LC_VD_VIDATE_DATE1, pEPDB);
      lFunction_TO_UDINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UDINT__UDINT(&lFunction_TO_UDINT, (lcfu_iec61131__DIV__UDINT__INL((LC_TD_UDINT)(lFunction_TO_UDINT__IN__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT - lFunction_TO_UDINT__IN__leftOp__rightOp_TO_UDINT.LC_VD_TO_UDINT),(LC_TD_UDINT)86400UL)), pEPDB);
      LC_this->LC_VD_FUN_LC_CALCDAYSDELTA_ST = lFunction_TO_UDINT.LC_VD_TO_UDINT;
    }
  }
}

#endif
