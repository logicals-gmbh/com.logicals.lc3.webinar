#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_convtod2hour_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST* LC_this, LC_TD_TOD LC_VD_VITOD_VAL, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_DT LC_VD_LDT_DATETIME;
  LC_TD_USINT LC_VD_LUSI_HOUR;
  LC_INIT_DT(&(LC_VD_LDT_DATETIME));
  LC_INIT_USINT(&(LC_VD_LUSI_HOUR));
  {
    LC_TD_Function_TO_DT lFunction_TO_DT;
    LC_INIT_Function_TO_DT(&lFunction_TO_DT);
    lFunction_TO_DT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DT__TOD(&lFunction_TO_DT, LC_VD_VITOD_VAL, pEPDB);
    LC_VD_LDT_DATETIME = lFunction_TO_DT.LC_VD_TO_DT;
  }
  {
    LC_TD_Function_SPLIT_DT lFunction_SPLIT_DT;
    LC_INIT_Function_SPLIT_DT(&lFunction_SPLIT_DT);
    lFunction_SPLIT_DT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SPLIT_DT(&lFunction_SPLIT_DT, LC_VD_LDT_DATETIME, pEPDB);
    LC_VD_LUSI_HOUR = lFunction_SPLIT_DT.LC_VD_HOUR;
  }
  {
    LC_TD_Function_TO_INT lFunction_TO_INT;
    LC_INIT_Function_TO_INT(&lFunction_TO_INT);
    lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_INT__USINT(&lFunction_TO_INT, LC_VD_LUSI_HOUR, pEPDB);
    LC_this->LC_VD_FUN_LC_CONVTOD2HOUR_ST = lFunction_TO_INT.LC_VD_TO_INT;
  }
}

#endif
