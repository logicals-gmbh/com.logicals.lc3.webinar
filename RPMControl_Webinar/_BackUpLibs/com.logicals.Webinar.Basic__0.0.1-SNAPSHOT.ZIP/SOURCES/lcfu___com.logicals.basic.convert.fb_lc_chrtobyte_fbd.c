#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD__C

#include <lcfu___com.logicals.basic.convert.fb_lc_chrtobyte_fbd.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_STRING_STACK_OFFSET offset = LC_STRING_STATEMENT_BUFFER(pEPDB);
  /* Network 1 */
  {
    {
      LC_TD_Function_FIND__USINT lFunction_FIND;
      LC_INIT_Function_FIND__USINT(&lFunction_FIND);
      lFunction_FIND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__FIND__USINT(&lFunction_FIND, LCCG_CreateStringStruct("!##%%&\x5c""()*+,-./0123456789:;<=>\x3f""@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\x5c""]^_`abcdefghijklmnopqrstuvwxyz",90), LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_CHR_127,127), pEPDB);
      LC_this->LC_VD___110_FIND = lFunction_FIND.LC_VD_FIND;
    }
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD___110_FIND, (LC_TD_USINT)1, pEPDB);
      LC_this->LC_VD___108_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_ADD__USINT lFunction_ADD;
      LC_INIT_Function_ADD__USINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___110_FIND, (LC_TD_USINT)32, pEPDB);
      LC_this->LC_VD___109_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SEL__USINT lFunction_SEL;
      LC_INIT_Function_SEL__USINT(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__USINT(&lFunction_SEL, LC_this->LC_VD___108_EQ, LC_this->LC_VD___109_ADD, (LC_TD_USINT)95, pEPDB);
      LC_this->LC_VD___107_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__USINT(&lFunction_TO_BYTE, LC_this->LC_VD___107_SEL, pEPDB);
      LC_this->LC_VD_VOB_OUT = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___106_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
  }
}

#endif
