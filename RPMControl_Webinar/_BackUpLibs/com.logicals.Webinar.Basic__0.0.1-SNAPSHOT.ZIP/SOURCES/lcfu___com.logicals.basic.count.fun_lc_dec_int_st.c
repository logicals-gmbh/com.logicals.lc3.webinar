#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFUN_LC_DEC_INT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFUN_LC_DEC_INT_ST__C

#include <lcfu___com.logicals.basic.count.fun_lc_dec_int_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFUN_LC_DEC_INT_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFUN_LC_DEC_INT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_FUN_LC_DEC_INT_ST = (LC_TD_INT)(LC_this->LC_VD_FUN_LC_DEC_INT_ST - (LC_TD_INT)1);
}

#endif
