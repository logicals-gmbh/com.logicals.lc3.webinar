#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST__C

#include <lcfu___com.logicals.basic.shiftsteps.fb_lc_shift8steps_st.h>
#include <lcfu_iec61131__OR.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESET)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_MUXSETTIME)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT6)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT7)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT8)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_INIT)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_START)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP1)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP2)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP3)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP4)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP5)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP6)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP7)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP8)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_INIT)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP2)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP3)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP4)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP5)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP6)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP7)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP8)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP9)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUINIT)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTART)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTURESET)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP1)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP2)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP3)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP4)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP5)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP6)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP7)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP8)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_ONTIME)); \
  LC_INIT_BOOL(&((p)->LC_VD_STARTVAR)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL1)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL2)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL3)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL4)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL5)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL6)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL7)); \
  LC_INIT_TIME(&((p)->LC_VD_TIMEACTVAL8)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_INIT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_START)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_RESET)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP1)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP2)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP3)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP4)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP5)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP6)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP7)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP8)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALINIT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTART)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALRESET)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP1)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP2)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP3)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP4)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP5)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP6)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP7)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP8)); \
  (p)->LC_VD_LX_EVERTRUE = LC_EL_true; \
  (p)->LC_VD_LX_EVERFALSE = LC_EL_false; \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_CYCLECOUNT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESET),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_MUXSETTIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT6),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT7),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT8),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_INIT),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_START),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG_RESET),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP1),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP2),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP3),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP4),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP5),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP6),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP7),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP8),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_INIT),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP2),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP3),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP4),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP5),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP6),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP7),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP8),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP9),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUINIT),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTART),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTURESET),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP1),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP2),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP3),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP4),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP5),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP6),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP7),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP8),0); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_ONTIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_STARTVAR),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL1),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL2),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL3),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL4),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL5),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL6),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL7),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_TIMEACTVAL8),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_INIT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_START),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_RESET),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP1),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP2),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP3),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP4),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP5),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP6),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP7),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP8),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALINIT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTART),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALRESET),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP1),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP2),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP3),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP4),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP5),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP6),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP7),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP8),RF); \
  if (RF==0) (p)->LC_VD_LX_EVERTRUE = LC_EL_true; \
  if (RF==0) (p)->LC_VD_LX_EVERFALSE = LC_EL_false; \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_CYCLECOUNT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT8STEPS_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LUI_CYCLECOUNT = (LC_TD_UINT)(LC_this->LC_VD_LUI_CYCLECOUNT + (LC_TD_UINT)1);
  LC_this->LC_VD_LT_ONTIME = LC_this->LC_VD_VIT_MUXSETTIME;
  {
    LC_this->LC_VD_R_TRIG_INIT.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_INIT.LC_VD_CLK = LC_this->LC_VD_LX_EVERTRUE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_INIT), pEPDB);
    LC_this->LC_VD_LX_CYCLEINIT = LC_this->LC_VD_R_TRIG_INIT.LC_VD_Q;
  }
  {
    LC_this->LC_VD_RS_INIT.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_INIT.LC_VD_S = LC_this->LC_VD_R_TRIG_INIT.LC_VD_Q;
    LC_this->LC_VD_RS_INIT.LC_VD_R1 = LC_this->LC_VD_VIX_RESET;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_INIT), pEPDB);
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CTUINIT__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CTUINIT__R_OR);
    lFunction_CTUINIT__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CTUINIT__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CTUINIT.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CTUINIT.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUINIT.LC_VD_CU = LC_this->LC_VD_R_TRIG_INIT.LC_VD_Q;
    LC_this->LC_VD_CTUINIT.LC_VD_R = lFunction_CTUINIT__R_OR.LC_VD_OR;
    LC_this->LC_VD_CTUINIT.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALINIT;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUINIT), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_INIT = LC_this->LC_VD_CTUINIT.LC_VD_CV;
  LC_this->LC_VD_LX_EVERTRUE = LC_EL_true;
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_CYCLEINIT == LC_EL_true))
  {
    LC_this->LC_VD_LT_ONTIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000));
    LC_this->LC_VD_LI_CNTSETVALINIT = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTART = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALRESET = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP1 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP2 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP3 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP4 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP5 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP6 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP7 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP8 = (LC_TD_INT)100;
  }
  {
    LC_this->LC_VD_R_TRIG_START.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_START.LC_VD_CLK = LC_this->LC_VD_VIX_START;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_START), pEPDB);
    LC_this->LC_VD_STARTVAR = LC_this->LC_VD_R_TRIG_START.LC_VD_Q;
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CTUSTART__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CTUSTART__R_OR);
    lFunction_CTUSTART__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CTUSTART__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CTUSTART.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CTUSTART.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTART.LC_VD_CU = LC_this->LC_VD_R_TRIG_START.LC_VD_Q;
    LC_this->LC_VD_CTUSTART.LC_VD_R = lFunction_CTUSTART__R_OR.LC_VD_OR;
    LC_this->LC_VD_CTUSTART.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTART;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTART), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_START = LC_this->LC_VD_CTUSTART.LC_VD_CV;
  {
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG_RESET.LC_VD_CLK = LC_this->LC_VD_VIX_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG_RESET), pEPDB);
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CTURESET__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CTURESET__R_OR);
    lFunction_CTURESET__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CTURESET__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CTURESET.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CTURESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTURESET.LC_VD_CU = LC_this->LC_VD_R_TRIG_RESET.LC_VD_Q;
    LC_this->LC_VD_CTURESET.LC_VD_R = lFunction_CTURESET__R_OR.LC_VD_OR;
    LC_this->LC_VD_CTURESET.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALRESET;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTURESET), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_RESET = LC_this->LC_VD_CTURESET.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP8.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP8.LC_VD_S = LC_this->LC_VD_TON_STEP7.LC_VD_Q;
    LC_this->LC_VD_RS_STEP8.LC_VD_R1 = LC_this->LC_VD_RS_STEP1.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP8), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT8 = LC_this->LC_VD_RS_STEP8.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP8.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP8.LC_VD_IN = LC_this->LC_VD_RS_STEP8.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP8.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP8), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP8.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP8.LC_VD_CU = LC_this->LC_VD_RS_STEP8.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP8.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP8.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP8;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP8), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP8 = LC_this->LC_VD_CTUSTEP8.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP7.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP7.LC_VD_S = LC_this->LC_VD_TON_STEP6.LC_VD_Q;
    LC_this->LC_VD_RS_STEP7.LC_VD_R1 = LC_this->LC_VD_RS_STEP8.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP7), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT7 = LC_this->LC_VD_RS_STEP7.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP7.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP7.LC_VD_IN = LC_this->LC_VD_RS_STEP7.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP7.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP7), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP7.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP7.LC_VD_CU = LC_this->LC_VD_RS_STEP7.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP7.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP7.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP7;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP7), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP7 = LC_this->LC_VD_CTUSTEP7.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP6.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP6.LC_VD_S = LC_this->LC_VD_TON_STEP5.LC_VD_Q;
    LC_this->LC_VD_RS_STEP6.LC_VD_R1 = LC_this->LC_VD_RS_STEP7.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP6), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT6 = LC_this->LC_VD_RS_STEP6.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP6.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP6.LC_VD_IN = LC_this->LC_VD_RS_STEP6.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP6.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP6), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP6.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP6.LC_VD_CU = LC_this->LC_VD_RS_STEP6.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP6.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP6.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP6;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP6), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP6 = LC_this->LC_VD_CTUSTEP6.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP5.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP5.LC_VD_S = LC_this->LC_VD_TON_STEP4.LC_VD_Q;
    LC_this->LC_VD_RS_STEP5.LC_VD_R1 = LC_this->LC_VD_RS_STEP6.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP5), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT5 = LC_this->LC_VD_RS_STEP5.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP5.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP5.LC_VD_IN = LC_this->LC_VD_RS_STEP5.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP5.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP5), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP5.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP5.LC_VD_CU = LC_this->LC_VD_RS_STEP5.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP5.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP5.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP5;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP5), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP5 = LC_this->LC_VD_CTUSTEP5.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP4.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP4.LC_VD_S = LC_this->LC_VD_TON_STEP3.LC_VD_Q;
    LC_this->LC_VD_RS_STEP4.LC_VD_R1 = LC_this->LC_VD_RS_STEP5.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP4), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT4 = LC_this->LC_VD_RS_STEP4.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP4.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP4.LC_VD_IN = LC_this->LC_VD_RS_STEP4.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP4.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP4), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP4.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP4.LC_VD_CU = LC_this->LC_VD_RS_STEP4.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP4.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP4.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP4;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP4), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP4 = LC_this->LC_VD_CTUSTEP4.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP3.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP3.LC_VD_S = LC_this->LC_VD_TON_STEP2.LC_VD_Q;
    LC_this->LC_VD_RS_STEP3.LC_VD_R1 = LC_this->LC_VD_RS_STEP4.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP3), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT3 = LC_this->LC_VD_RS_STEP3.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP3.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP3.LC_VD_IN = LC_this->LC_VD_RS_STEP3.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP3.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP3), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP3.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP3.LC_VD_CU = LC_this->LC_VD_RS_STEP3.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP3.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP3.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP3;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP3), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP3 = LC_this->LC_VD_CTUSTEP3.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP2.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP2.LC_VD_S = LC_this->LC_VD_TON_STEP1.LC_VD_Q;
    LC_this->LC_VD_RS_STEP2.LC_VD_R1 = LC_this->LC_VD_RS_STEP3.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP2), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT2 = LC_this->LC_VD_RS_STEP2.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP2.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP2.LC_VD_IN = LC_this->LC_VD_RS_STEP2.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP2.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP2), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP2.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP2.LC_VD_CU = LC_this->LC_VD_RS_STEP2.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP2.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP2.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP2;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP2), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP2 = LC_this->LC_VD_CTUSTEP2.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP1.LC_VD_S = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_STARTVAR,LC_this->LC_VD_TON_STEP8.LC_VD_Q));
    LC_this->LC_VD_RS_STEP1.LC_VD_R1 = LC_this->LC_VD_RS_STEP2.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP1), pEPDB);
  }
  LC_this->LC_VD_VOX_OUT1 = LC_this->LC_VD_RS_STEP1.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP1.LC_VD_IN = LC_this->LC_VD_RS_STEP1.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP1.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP1), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP1.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP1.LC_VD_CU = LC_this->LC_VD_RS_STEP1.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP1.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP1.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP1;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP1), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP1 = LC_this->LC_VD_CTUSTEP1.LC_VD_CV;
  LC_this->LC_VD_TIMEACTVAL = LC_this->LC_VD_TON_STEP1.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL1 = LC_this->LC_VD_TON_STEP2.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL2 = LC_this->LC_VD_TON_STEP3.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL3 = LC_this->LC_VD_TON_STEP4.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL4 = LC_this->LC_VD_TON_STEP5.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL5 = LC_this->LC_VD_TON_STEP6.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL6 = LC_this->LC_VD_TON_STEP7.LC_VD_ET;
  LC_this->LC_VD_TIMEACTVAL7 = LC_this->LC_VD_TON_STEP8.LC_VD_ET;
}

#endif
