#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFUN_LC_QUAD_C__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFUN_LC_QUAD_C__C

#include <lcfu___COM.LOGICALS.BASIC.CALC.FUN_LC_QUAD_C.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFUN_LC_QUAD_C(LC_TD_Function_COMx2ELOGICALSx2EBASICx2ECALCx2EFUN_LC_QUAD_C* LC_this, LC_TD_INT LC_VD_VI_IN1, struct _lcoplck_epdb_1_impl* pEPDB)
{
	LC_this->LC_VD_FUN_LC_QUAD_C = LC_VD_VI_IN1 * LC_VD_VI_IN1;
}

#endif
