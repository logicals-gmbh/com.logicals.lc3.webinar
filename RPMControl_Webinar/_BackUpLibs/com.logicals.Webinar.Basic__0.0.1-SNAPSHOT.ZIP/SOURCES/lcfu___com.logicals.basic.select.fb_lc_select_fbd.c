#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD__C

#include <lcfu___com.logicals.basic.select.fb_lc_select_fbd.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DEFAULT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX1)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX2)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX3)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX4)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX5)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX6)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X6)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX7)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X7)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX8)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X8)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SELECTX9)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X9)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD___144_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___145_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___146_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___147_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___148_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___149_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___141_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___142_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___143_SEL)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DEFAULT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX2),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX3),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX4),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX5),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX6),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X6),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX7),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X7),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX8),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X8),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SELECTX9),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X9),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___144_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___145_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___146_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___147_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___148_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___149_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___141_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___142_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___143_SEL),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX1, LC_this->LC_VD_VIR_DEFAULT, LC_this->LC_VD_VIR_X1, pEPDB);
      LC_this->LC_VD___144_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX2, LC_this->LC_VD___144_SEL, LC_this->LC_VD_VIR_X2, pEPDB);
      LC_this->LC_VD___146_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX3, LC_this->LC_VD___146_SEL, LC_this->LC_VD_VIR_X3, pEPDB);
      LC_this->LC_VD___145_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX4, LC_this->LC_VD___145_SEL, LC_this->LC_VD_VIR_X4, pEPDB);
      LC_this->LC_VD___148_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX5, LC_this->LC_VD___148_SEL, LC_this->LC_VD_VIR_X5, pEPDB);
      LC_this->LC_VD___143_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX6, LC_this->LC_VD___143_SEL, LC_this->LC_VD_VIR_X6, pEPDB);
      LC_this->LC_VD___142_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX7, LC_this->LC_VD___142_SEL, LC_this->LC_VD_VIR_X7, pEPDB);
      LC_this->LC_VD___149_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX8, LC_this->LC_VD___149_SEL, LC_this->LC_VD_VIR_X8, pEPDB);
      LC_this->LC_VD___147_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_VIX_SELECTX9, LC_this->LC_VD___147_SEL, LC_this->LC_VD_VIR_X9, pEPDB);
      LC_this->LC_VD_VOR_OUT = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___141_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
}

#endif
