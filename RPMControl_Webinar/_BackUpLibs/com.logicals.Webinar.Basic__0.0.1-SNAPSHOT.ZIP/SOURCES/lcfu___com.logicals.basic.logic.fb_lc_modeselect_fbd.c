#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD__C

#include <lcfu___com.logicals.basic.logic.fb_lc_modeselect_fbd.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SETHAND)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SETAUTOMATIK)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SETTEST)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SETSIM)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_HANDBETRIEB)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_AUTOMATIKBETRIEB)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_TESTBETRIEB)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_SIMBETRIEB)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_INITPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LOCAL_TRUE)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG2)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG3)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG4)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_ALIVE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR1)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR2)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR3)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR4)); \
  LC_INIT_BOOL(&((p)->LC_VD___14_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___18_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___35_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___48_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___63_OR)); \
  LC_INIT_INT(&((p)->LC_VD___79_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___80_NOT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SETHAND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SETAUTOMATIK),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SETTEST),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SETSIM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_HANDBETRIEB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_AUTOMATIKBETRIEB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_TESTBETRIEB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_SIMBETRIEB),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_INITPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LOCAL_TRUE),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG2),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG3),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG4),0); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_ALIVE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR1),0); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR2),0); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR3),0); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR4),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___14_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___18_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___35_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___48_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___63_OR),RF); \
  LC_WINIT_INT(&((p)->LC_VD___79_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___80_NOT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG.LC_VD_CLK = LC_this->LC_VD_LOCAL_TRUE;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
      LC_this->LC_VD_LX_INITPULSE = LC_this->LC_VD_R_TRIG.LC_VD_Q;
    }
  }
  /* Network 2 */
  {
    LC_this->LC_VD_LI_ALIVE = LC_this->LC_VD_LI_CYCLECOUNT;
    {
      LC_TD_Function_ADD__INT lFunction_ADD;
      LC_INIT_Function_ADD__INT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LI_CYCLECOUNT, (LC_TD_INT)1, pEPDB);
      LC_this->LC_VD_LI_CYCLECOUNT = lFunction_ADD.LC_VD_ADD;
      LC_this->LC_VD___79_ADD = lFunction_ADD.LC_VD_ADD;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
      LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___80_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
  /* Network 4 */
  {
    {
      LC_this->LC_VD_R_TRIG1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG1.LC_VD_CLK = LC_this->LC_VD_VIX_SETHAND;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG1), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_R_TRIG1.LC_VD_Q, LC_this->LC_VD_LOCAL_TRUE, pEPDB);
      LC_this->LC_VD___14_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD_VOX_AUTOMATIKBETRIEB, LC_this->LC_VD_VOX_TESTBETRIEB, LC_this->LC_VD_VOX_SIMBETRIEB, pEPDB);
      LC_this->LC_VD___18_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_SR1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR1.LC_VD_S1 = LC_this->LC_VD___14_OR;
      LC_this->LC_VD_SR1.LC_VD_R = LC_this->LC_VD___18_OR;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR1), pEPDB);
      LC_this->LC_VD_VOX_HANDBETRIEB = LC_this->LC_VD_SR1.LC_VD_Q1;
    }
  }
  /* Network 5 */
  {
    {
      LC_this->LC_VD_R_TRIG2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG2.LC_VD_CLK = LC_this->LC_VD_VIX_SETAUTOMATIK;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG2), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD_VOX_HANDBETRIEB, LC_this->LC_VD_VOX_TESTBETRIEB, LC_this->LC_VD_VOX_SIMBETRIEB, pEPDB);
      LC_this->LC_VD___35_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_SR2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR2.LC_VD_S1 = LC_this->LC_VD_R_TRIG2.LC_VD_Q;
      LC_this->LC_VD_SR2.LC_VD_R = LC_this->LC_VD___35_OR;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR2), pEPDB);
      LC_this->LC_VD_VOX_AUTOMATIKBETRIEB = LC_this->LC_VD_SR2.LC_VD_Q1;
    }
  }
  /* Network 6 */
  {
    {
      LC_this->LC_VD_R_TRIG3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG3.LC_VD_CLK = LC_this->LC_VD_VIX_SETTEST;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG3), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD_VOX_HANDBETRIEB, LC_this->LC_VD_VOX_AUTOMATIKBETRIEB, LC_this->LC_VD_VOX_SIMBETRIEB, pEPDB);
      LC_this->LC_VD___48_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_SR3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR3.LC_VD_S1 = LC_this->LC_VD_R_TRIG3.LC_VD_Q;
      LC_this->LC_VD_SR3.LC_VD_R = LC_this->LC_VD___48_OR;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR3), pEPDB);
      LC_this->LC_VD_VOX_TESTBETRIEB = LC_this->LC_VD_SR3.LC_VD_Q1;
    }
  }
  /* Network 7 */
  {
    {
      LC_this->LC_VD_R_TRIG4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG4.LC_VD_CLK = LC_this->LC_VD_VIX_SETSIM;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG4), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD_VOX_HANDBETRIEB, LC_this->LC_VD_VOX_TESTBETRIEB, LC_this->LC_VD_VOX_AUTOMATIKBETRIEB, pEPDB);
      LC_this->LC_VD___63_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_SR4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR4.LC_VD_S1 = LC_this->LC_VD_R_TRIG4.LC_VD_Q;
      LC_this->LC_VD_SR4.LC_VD_R = LC_this->LC_VD___63_OR;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR4), pEPDB);
      LC_this->LC_VD_VOX_SIMBETRIEB = LC_this->LC_VD_SR4.LC_VD_Q1;
    }
  }
}

#endif
