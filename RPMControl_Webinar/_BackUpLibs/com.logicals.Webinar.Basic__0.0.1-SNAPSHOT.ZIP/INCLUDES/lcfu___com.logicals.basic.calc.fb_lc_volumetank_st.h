#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.calc.fb_lc_surface_st.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST
{
  LC_TD_REAL LC_VD_VIR_DIAMETER;
  LC_TD_REAL LC_VD_VIR_LEVELHEIGHT;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_VOR_VOLTANK;
  LC_TD_REAL LC_VD_LR_SURFACE;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST LC_VD_FB_LC_SURFACE;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(p) \
{ \
  LC_INIT_REAL(&((p)->LC_VD_VIR_LEVELHEIGHT)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DIAMETER)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_VOLTANK)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&((p)->LC_VD_FB_LC_SURFACE)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_SURFACE)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(p,RF) \
{ \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_LEVELHEIGHT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DIAMETER),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_VOLTANK),RF); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&((p)->LC_VD_FB_LC_SURFACE),0); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_SURFACE),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
