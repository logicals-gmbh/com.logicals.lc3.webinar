#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__SPLIT_DT.h>
#include <lcfu_iec61131__TO_DT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_INT LC_VD_FUN_LC_CONVTOD2HOUR_ST;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST(p) \
{ \
  LC_INIT_INT(&((p)->LC_VD_FUN_LC_CONVTOD2HOUR_ST)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVTOD2HOUR_ST* LC_this, LC_TD_TOD LC_VD_VITOD_VAL, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
