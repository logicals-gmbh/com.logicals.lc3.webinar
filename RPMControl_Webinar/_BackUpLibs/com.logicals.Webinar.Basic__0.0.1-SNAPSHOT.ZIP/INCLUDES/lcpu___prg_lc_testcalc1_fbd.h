#ifndef LC_PROT_LCPU___PRG_LC_TESTCALC1_FBD__H
#define LC_PROT_LCPU___PRG_LC_TESTCALC1_FBD__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.calc.fb_lc_polygon_fbd.h>
#include <lcfu___com.logicals.basic.siggen.fb_lc_gensincossig_st.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTCALC1_FBD
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_LR_SIGGEN_ENDVAL;
  LC_TD_REAL LC_VD_LR_SIGGEN_STEPVAL;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD LC_VD_COM_LOGICALS_BASIC_CALC_FB_LC_POLYGON_FBD2;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST LC_VD_COM_LOGICALS_BASIC_SIGGEN_FB_LC_GENSINCOSSIG_ST1;
  LC_TD_REAL LC_VD_LRARR_POLYGON_PAR[6][6];
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTCALC1_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTCALC1_FBD(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD(&((p)->LC_VD_COM_LOGICALS_BASIC_CALC_FB_LC_POLYGON_FBD2)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST(&((p)->LC_VD_COM_LOGICALS_BASIC_SIGGEN_FB_LC_GENSINCOSSIG_ST1)); \
  (p)->LC_VD_LR_SIGGEN_STEPVAL = (LC_TD_REAL)0.1; \
  (p)->LC_VD_LR_SIGGEN_ENDVAL = (LC_TD_REAL)1000.0; \
  LC_INIT_ARRAY(&((p)->LC_VD_LRARR_POLYGON_PAR),REAL,36); \

#define LC_INIT_Program_PRG_LC_TESTCALC1_FBD(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTCALC1_FBD(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC1_FBD(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD(&((p)->LC_VD_COM_LOGICALS_BASIC_CALC_FB_LC_POLYGON_FBD2),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST(&((p)->LC_VD_COM_LOGICALS_BASIC_SIGGEN_FB_LC_GENSINCOSSIG_ST1),0); \
  if (RF==0) (p)->LC_VD_LR_SIGGEN_STEPVAL = (LC_TD_REAL)0.1; \
  if (RF==0) (p)->LC_VD_LR_SIGGEN_ENDVAL = (LC_TD_REAL)1000.0; \
  LC_WINIT_ARRAY(&((p)->LC_VD_LRARR_POLYGON_PAR),REAL,36,RF); \

#define LC_WINIT_Program_PRG_LC_TESTCALC1_FBD(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC1_FBD(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTCALC1_FBD(LC_TD_Program_PRG_LC_TESTCALC1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
