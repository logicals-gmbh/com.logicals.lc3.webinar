#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__EQ.h>
#include <lcfu_iec61131__FIND.h>
#include <lcfu_iec61131__SEL_ANY.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD
{
  LcCgChar LC_VD_VISTR_CHR_127[128];
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BYTE LC_VD_VOB_OUT;
  LC_TD_BOOL LC_VD___108_EQ;
  LC_TD_USINT LC_VD___107_SEL;
  LC_TD_USINT LC_VD___109_ADD;
  LC_TD_USINT LC_VD___110_FIND;
  LC_TD_BYTE LC_VD___106_TO_BYTE;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(p) \
{ \
  LC_INIT_SIZED_STRING_VAL((p)->LC_VD_VISTR_CHR_127,127,"0"); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_OUT)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(p,RF) \
{ \
  if (RF==0) LC_INIT_SIZED_STRING_VAL((p)->LC_VD_VISTR_CHR_127,127,"0"); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_OUT),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CHRTOBYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
