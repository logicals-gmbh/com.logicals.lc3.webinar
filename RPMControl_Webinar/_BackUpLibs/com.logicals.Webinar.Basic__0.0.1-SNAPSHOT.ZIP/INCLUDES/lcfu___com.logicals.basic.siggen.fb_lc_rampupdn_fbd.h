#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__GT.h>
#include <lcfu_iec61131__LT.h>
#include <lcfu_iec61131__MUL.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__SEL_ANY.h>
#include <lcfu_iec61131__SQRT.h>
#include <lcfu_iec61131__SUB.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD
{
  LC_TD_REAL LC_VD_VIR_DXDNMAX;
  LC_TD_REAL LC_VD_VIR_DXUPMAX;
  LC_TD_REAL LC_VD_VIR_IN;
  LC_TD_TIME LC_VD_VIT_TIMEBASE;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_VOR_OUT;
  LC_TD_BOOL LC_VD___174_AND;
  LC_TD_BOOL LC_VD___175_GT;
  LC_TD_BOOL LC_VD___176_LT;
  LC_TD_BOOL LC_VD___178_AND;
  LC_TD_BOOL LC_VD___184_AND;
  LC_TD_BOOL LC_VD___186_AND;
  LC_TD_BOOL LC_VD___187_LT;
  LC_TD_BOOL LC_VD___188_LT;
  LC_TD_BOOL LC_VD___189_GT;
  LC_TD_BOOL LC_VD___190_GT;
  LC_TD_BOOL LC_VD___191_GT;
  LC_TD_BOOL LC_VD___195_NOT;
  LC_TD_BOOL LC_VD___197_AND;
  LC_TD_REAL LC_VD_DELTAXABS;
  LC_TD_REAL LC_VD_XDAMPEDINTERNAL;
  LC_TD_REAL LC_VD___163_SEL;
  LC_TD_REAL LC_VD___165_SEL;
  LC_TD_REAL LC_VD___166_SQRT;
  LC_TD_REAL LC_VD___167_SEL;
  LC_TD_REAL LC_VD___168_SEL;
  LC_TD_REAL LC_VD___172_SEL;
  LC_TD_REAL LC_VD___177_ADD;
  LC_TD_REAL LC_VD___179_SUB;
  LC_TD_REAL LC_VD___180_MUL;
  LC_TD_REAL LC_VD___181_SUB;
  LC_TD_REAL LC_VD___182_SUB;
  LC_TD_REAL LC_VD___183_SQRT;
  LC_TD_REAL LC_VD___185_MUL;
  LC_TD_REAL LC_VD___192_MUL;
  LC_TD_REAL LC_VD___193_SUB;
  LC_TD_REAL LC_VD___196_SQRT;
  LC_TD_FunctionBlock_TON LC_VD_TON0;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(p) \
{ \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DXUPMAX)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DXDNMAX)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_TIMEBASE)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD_DELTAXABS)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON0)); \
  LC_INIT_REAL(&((p)->LC_VD_XDAMPEDINTERNAL)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(p,RF) \
{ \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DXUPMAX),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DXDNMAX),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_TIMEBASE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_DELTAXABS),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON0),0); \
  LC_WINIT_REAL(&((p)->LC_VD_XDAMPEDINTERNAL),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
