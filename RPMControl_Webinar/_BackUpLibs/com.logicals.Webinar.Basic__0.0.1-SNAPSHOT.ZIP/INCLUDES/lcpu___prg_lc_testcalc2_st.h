#ifndef LC_PROT_LCPU___PRG_LC_TESTCALC2_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTCALC2_ST__H

#include <LC3CGBase.h>
#include <lcfu___COM.LOGICALS.BASIC.CALC.FUN_LC_QUAD_C.h>
#include <lcpu___prg_lc_testcalc2_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTCALC2_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_INT LC_VD_LI_TEST1;
  LC_TD_INT LC_VD_LI_TEST2;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTCALC2_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTCALC2_ST(p) \
  LC_INIT_INT(&((p)->LC_VD_LI_TEST1)); \
  LC_INIT_INT(&((p)->LC_VD_LI_TEST2)); \

#define LC_INIT_Program_PRG_LC_TESTCALC2_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTCALC2_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC2_ST(p,RF) \
  LC_WINIT_INT(&((p)->LC_VD_LI_TEST1),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_TEST2),RF); \

#define LC_WINIT_Program_PRG_LC_TESTCALC2_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC2_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTCALC2_ST(LC_TD_Program_PRG_LC_TESTCALC2_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
