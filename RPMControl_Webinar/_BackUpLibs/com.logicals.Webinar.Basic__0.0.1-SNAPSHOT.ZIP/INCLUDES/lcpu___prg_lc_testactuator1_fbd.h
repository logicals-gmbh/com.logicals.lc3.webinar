#ifndef LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_FBD__H
#define LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_FBD__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.actuator.fb_lc_motor2r_stop_fbd.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__CTUD_DINT.h>
#include <lcfu_iec61131__FORCEMRK.h>
#include <lcfu_iec61131__OR.h>
#include <lcfu_logilibrary__RTSCYCLEINFO.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTACTUATOR1_FBD
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LX_INIT;
  LC_TD_BOOL LC_VD_LX_MOTORLEFT;
  LC_TD_BOOL LC_VD_LX_MOTORRIGHT;
  LC_TD_BOOL LC_VD_LX_MOTORSTOP;
  LC_TD_BOOL LC_VD_LX_RESET;
  LC_TD_BOOL LC_VD_LX_RUN;
  LC_TD_BOOL LC_VD_LX_SHUTDOWN;
  LC_TD_BOOL LC_VD_LX_STARTLEFT;
  LC_TD_BOOL LC_VD_LX_STARTRIGHT;
  LC_TD_BOOL LC_VD_LX_TERM;
  LC_TD_BOOL LC_VD___27_OR;
  LC_TD_BOOL LC_VD___30_OR;
  LC_TD_BOOL LC_VD___33_OR;
  LC_TD_BOOL LC_VD___45_AND;
  LC_TD_BOOL LC_VD___48_AND;
  LC_TD_BOOL LC_VD___58_INIT;
  LC_TD_BOOL LC_VD___58_RUN;
  LC_TD_BOOL LC_VD___58_SHUTDOWN;
  LC_TD_BOOL LC_VD___58_TERM;
  LC_TD_BOOL LC_VD___68_OR;
  LC_TD_UDINT LC_VD_LUDI_COUNTVAL;
  LC_TD_UDINT LC_VD___55_TO_UDINT;
  LC_TD_FunctionBlock_CTUD_DINT LC_VD_CTUD_DINT1;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_FBD LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD;
  LC_TD_FunctionBlock_FORCEMRK__BOOL LC_VD_FORCEMRK1;
  LC_TD_FunctionBlock_FORCEMRK__BOOL LC_VD_FORCEMRK2;
  LC_TD_FunctionBlock_FORCEMRK__BOOL LC_VD_FORCEMRK3;
  LC_TD_FunctionBlock_FORCEMRK__BOOL LC_VD_FORCEMRK4;
  LC_TD_FunctionBlock_FORCEMRK__BOOL LC_VD_FORCEMRK5;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTACTUATOR1_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_FBD(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_FBD(&((p)->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD)); \
  LC_INIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK1)); \
  LC_INIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK2)); \
  LC_INIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK3)); \
  LC_INIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK4)); \
  LC_INIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK5)); \
  LC_INIT_FunctionBlock_CTUD_DINT(&((p)->LC_VD_CTUD_DINT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_RESET)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_COUNTVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_INIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_RUN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_TERM)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_SHUTDOWN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTORLEFT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_STARTLEFT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTORRIGHT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTORSTOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_STARTRIGHT)); \

#define LC_INIT_Program_PRG_LC_TESTACTUATOR1_FBD(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_FBD(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_FBD(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_FBD(&((p)->LC_VD_FB_MOTORLEFTRIGHTSTOP_FBD),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK1),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK2),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK3),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK4),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__BOOL(&((p)->LC_VD_FORCEMRK5),0); \
  LC_WINIT_FunctionBlock_CTUD_DINT(&((p)->LC_VD_CTUD_DINT1),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_RESET),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_COUNTVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_INIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_RUN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_TERM),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_SHUTDOWN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTORLEFT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_STARTLEFT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTORRIGHT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTORSTOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_STARTRIGHT),RF); \

#define LC_WINIT_Program_PRG_LC_TESTACTUATOR1_FBD(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_FBD(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTACTUATOR1_FBD(LC_TD_Program_PRG_LC_TESTACTUATOR1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
