#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>
#include <lcfu_iec61131__RS.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST
{
  LC_TD_BOOL LC_VD_VIX_SETOUT;
  LC_TD_BOOL LC_VD_VIX_TESTMODE;
  LC_TD_TIME LC_VD_VIT_PULSETIME;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_BOOL LC_VD_LX_TEST;
  LC_TD_FunctionBlock_RS LC_VD_RS;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG;
  LC_TD_FunctionBlock_TON LC_VD_TON;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SETOUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_TESTMODE)); \
  (p)->LC_VD_VIT_PULSETIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_TEST)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SETOUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_TESTMODE),RF); \
  if (RF==0) (p)->LC_VD_VIT_PULSETIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_TEST),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETIMERx2EFB_LC_MONOFLOP_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
