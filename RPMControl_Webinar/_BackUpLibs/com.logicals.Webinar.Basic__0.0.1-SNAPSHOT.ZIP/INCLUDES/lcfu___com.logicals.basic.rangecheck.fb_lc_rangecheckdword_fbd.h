#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__GT.h>
#include <lcfu_iec61131__LT.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD
{
  LC_TD_DWORD LC_VD_VIDW_IN;
  LC_TD_DWORD LC_VD_VIDW_LL;
  LC_TD_DWORD LC_VD_VIDW_UL;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_INRNG;
  LC_TD_BOOL LC_VD_VOX_LLRCD;
  LC_TD_BOOL LC_VD_VOX_OUTOFRNG;
  LC_TD_BOOL LC_VD_VOX_ULRCD;
  LC_TD_BOOL LC_VD___103_NOT;
  LC_TD_BOOL LC_VD___105_LT;
  LC_TD_BOOL LC_VD___107_GT;
  LC_TD_BOOL LC_VD___109_OR;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD(p) \
{ \
  LC_INIT_DWORD(&((p)->LC_VD_VIDW_LL)); \
  LC_INIT_DWORD(&((p)->LC_VD_VIDW_IN)); \
  LC_INIT_DWORD(&((p)->LC_VD_VIDW_UL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LLRCD)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_INRNG)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUTOFRNG)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ULRCD)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD(p,RF) \
{ \
  LC_WINIT_DWORD(&((p)->LC_VD_VIDW_LL),RF); \
  LC_WINIT_DWORD(&((p)->LC_VD_VIDW_IN),RF); \
  LC_WINIT_DWORD(&((p)->LC_VD_VIDW_UL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LLRCD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_INRNG),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUTOFRNG),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ULRCD),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECKDWORD_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
