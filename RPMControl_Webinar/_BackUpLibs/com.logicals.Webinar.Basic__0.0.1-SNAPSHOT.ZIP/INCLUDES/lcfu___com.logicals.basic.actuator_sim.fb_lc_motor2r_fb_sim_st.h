#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST
{
  LC_TD_BOOL LC_VD_VIX_LEFT;
  LC_TD_BOOL LC_VD_VIX_RIGHT;
  LC_TD_TIME LC_VD_VIT_LEFTDELAY;
  LC_TD_TIME LC_VD_VIT_RIGHTDELAY;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_LEFTFB;
  LC_TD_BOOL LC_VD_VOX_RIGHTFB;
  LC_TD_FunctionBlock_TON LC_VD_FB_LEFTTON;
  LC_TD_FunctionBlock_TON LC_VD_FB_RIGHTTON;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_LEFT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RIGHT)); \
  (p)->LC_VD_VIT_LEFTDELAY = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_VIT_RIGHTDELAY = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LEFTFB)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_RIGHTFB)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_LEFTTON)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_RIGHTTON)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_LEFT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RIGHT),RF); \
  if (RF==0) (p)->LC_VD_VIT_LEFTDELAY = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_VIT_RIGHTDELAY = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LEFTFB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_RIGHTFB),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_LEFTTON),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_RIGHTTON),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
