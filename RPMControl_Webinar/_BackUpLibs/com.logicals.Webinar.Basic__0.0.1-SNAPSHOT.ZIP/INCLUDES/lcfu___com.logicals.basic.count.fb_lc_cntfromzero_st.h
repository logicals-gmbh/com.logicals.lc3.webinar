#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST
{
  LC_TD_BOOL LC_VD_VIX_CNTEDGE;
  LC_TD_BOOL LC_VD_VIX_CNTRESET;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_UINT LC_VD_VOUI_CNTVAL;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_CNTEDGE)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_CNTRESET)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_CNTVAL)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_CNTEDGE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_CNTRESET),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_CNTVAL),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
