#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__TRACE.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST
{
  LC_TD_UINT LC_VD_VIUI_TRACELEVEL;
  LcCgChar LC_VD_VISTR_TRACETEXT[129];
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LX_CYCLEINIT;
  LC_TD_BOOL LC_VD_LX_TRACESTATE;
  LC_TD_FunctionBlock_R_TRIG LC_VD_FB_INITRTRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST(p) \
{ \
  LC_INIT_SIZED_STRING(&((p)->LC_VD_VISTR_TRACETEXT)); \
  (p)->LC_VD_VIUI_TRACELEVEL = (LC_TD_UINT)5; \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITRTRIG)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_TRACESTATE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST(p,RF) \
{ \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD_VISTR_TRACETEXT),RF); \
  if (RF==0) (p)->LC_VD_VIUI_TRACELEVEL = (LC_TD_UINT)5; \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITRTRIG),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_TRACESTATE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
