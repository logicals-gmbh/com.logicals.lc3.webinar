#include <RISMD.h>
#include <lcpu___prg_lc_testc_control1_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_PRG_LC_TESTC_CONTROL1_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_PRG_LC_TESTC_CONTROL1_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_PRG_LC_TESTC_CONTROL1_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_PRG_LC_TESTC_CONTROL1_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_CONTROL1_ST_ENO),
};

static char const lcmd_type_name_PRG_LC_TESTC_CONTROL1_ST[] RISMD_ATTRIBUTES = "PRG_LC_TESTC_CONTROL1_ST";
RISMDPOUType const lcmd_type_PRG_LC_TESTC_CONTROL1_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_PRG_LC_TESTC_CONTROL1_ST, sizeof(LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST), 1, lcmd_var_list_PRG_LC_TESTC_CONTROL1_ST);
