#include <RISMD.h>
#include <lcpu___prg_lc_testconvert1_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDPOUType const lcmd_type_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST;
static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_FB_CONVREALTO2INT[] RISMD_ATTRIBUTES = "FB_ConvRealTo2Int";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_FB_CONVREALTO2INT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_FB_CONVREALTO2INT, &lcmd_type_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_FB_CONVREALTO2INT));

extern RISMDSimpleNumType const risMdType_DINT;
static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LDI_HVAL[] RISMD_ATTRIBUTES = "ldi_HVal";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LDI_HVAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LDI_HVAL, &risMdType_DINT, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LDI_HVAL));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LDI_LVAL[] RISMD_ATTRIBUTES = "ldi_LVal";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LDI_LVAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LDI_LVAL, &risMdType_DINT, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LDI_LVAL));

extern RISMDSimpleNumType const risMdType_REAL;
static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LR_VAL[] RISMD_ATTRIBUTES = "lr_Val";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LR_VAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LR_VAL, &risMdType_REAL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LR_VAL));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_00THOUS[] RISMD_ATTRIBUTES = "lx_00Thous";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_00THOUS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_00THOUS, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_00THOUS));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_0THOUS[] RISMD_ATTRIBUTES = "lx_0Thous";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_0THOUS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_0THOUS, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_0THOUS));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DHUN[] RISMD_ATTRIBUTES = "lx_DHun";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DHUN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DHUN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_DHUN));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DSING[] RISMD_ATTRIBUTES = "lx_DSing";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DSING RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DSING, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_DSING));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DSINGLE[] RISMD_ATTRIBUTES = "lx_DSingle";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DSINGLE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DSINGLE, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_DSINGLE));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DTEN[] RISMD_ATTRIBUTES = "lx_DTen";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DTEN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_DTEN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_DTEN));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_HUN[] RISMD_ATTRIBUTES = "lx_Hun";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_HUN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_HUN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_HUN));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_MILL[] RISMD_ATTRIBUTES = "lx_Mill";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_MILL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_MILL, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_MILL));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_SIGN[] RISMD_ATTRIBUTES = "lx_Sign";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_SIGN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_SIGN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_SIGN));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_TEN[] RISMD_ATTRIBUTES = "lx_Ten";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_TEN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_TEN, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_TEN));

static char const lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_THOUS[] RISMD_ATTRIBUTES = "lx_Thous";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_THOUS RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCONVERT1_ST_LX_THOUS, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST,LC_VD_LX_THOUS));

static RISMDReference const lcmd_var_list_PRG_LC_TESTCONVERT1_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_ENO),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_FB_CONVREALTO2INT),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LDI_HVAL),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LDI_LVAL),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LR_VAL),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_00THOUS),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_0THOUS),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DHUN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DSING),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DSINGLE),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_DTEN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_HUN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_MILL),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_SIGN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_TEN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCONVERT1_ST_LX_THOUS),
};

static char const lcmd_type_name_PRG_LC_TESTCONVERT1_ST[] RISMD_ATTRIBUTES = "PRG_LC_TESTCONVERT1_ST";
RISMDPOUType const lcmd_type_PRG_LC_TESTCONVERT1_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_PRG_LC_TESTCONVERT1_ST, sizeof(LC_TD_Program_PRG_LC_TESTCONVERT1_ST), 16, lcmd_var_list_PRG_LC_TESTCONVERT1_ST);
