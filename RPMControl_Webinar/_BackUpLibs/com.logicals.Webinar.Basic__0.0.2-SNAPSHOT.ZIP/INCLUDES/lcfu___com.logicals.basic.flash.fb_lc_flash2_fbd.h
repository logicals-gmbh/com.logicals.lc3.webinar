#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__MOVE.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__SEL_ANY.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD
{
  LC_TD_BOOL LC_VD_VIX_SELPAR;
  LC_TD_BOOL LC_VD_VIX_START;
  LC_TD_TIME LC_VD_VIT_OFFTIME;
  LC_TD_TIME LC_VD_VIT_ONTIME;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_TIME LC_VD_VOT_OFFTIME;
  LC_TD_TIME LC_VD_VOT_ONTIME;
  LC_TD_BOOL LC_VD_LX_OUT;
  LC_TD_BOOL LC_VD_LX_TOOUT;
  LC_TD_BOOL LC_VD___7_ENO;
  LC_TD_BOOL LC_VD___7_MOVE;
  LC_TD_BOOL LC_VD___8_AND;
  LC_TD_BOOL LC_VD___9_NOT;
  LC_TD_TIME LC_VD_LIT_OFFTIME;
  LC_TD_TIME LC_VD_LIT_OFFTIMEPAR;
  LC_TD_TIME LC_VD_LIT_ONTIME;
  LC_TD_TIME LC_VD_LIT_ONTIMEPAR;
  LC_TD_TIME LC_VD___27_SEL;
  LC_TD_TIME LC_VD___35_SEL;
  LC_TD_FunctionBlock_TON LC_VD_TON;
  LC_TD_FunctionBlock_TON LC_VD_TON1;
  LC_TD_FunctionBlock_TON LC_VD_TON2;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(p) LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(p,RF) LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH2_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
