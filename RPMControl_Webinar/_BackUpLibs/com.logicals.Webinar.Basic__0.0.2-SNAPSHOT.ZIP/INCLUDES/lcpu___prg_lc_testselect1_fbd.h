#ifndef LC_PROT_LCPU___PRG_LC_TESTSELECT1_FBD__H
#define LC_PROT_LCPU___PRG_LC_TESTSELECT1_FBD__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.select.fb_lc_select_fbd.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTSELECT1_FBD
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD LC_VD_COM_LOGICALS_BASIC_SELECT_FB_LC_SELECT_FBD1;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTSELECT1_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTSELECT1_FBD(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(&((p)->LC_VD_COM_LOGICALS_BASIC_SELECT_FB_LC_SELECT_FBD1)); \

#define LC_INIT_Program_PRG_LC_TESTSELECT1_FBD(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTSELECT1_FBD(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTSELECT1_FBD(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESELECTx2EFB_LC_SELECT_FBD(&((p)->LC_VD_COM_LOGICALS_BASIC_SELECT_FB_LC_SELECT_FBD1),0); \

#define LC_WINIT_Program_PRG_LC_TESTSELECT1_FBD(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTSELECT1_FBD(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTSELECT1_FBD(LC_TD_Program_PRG_LC_TESTSELECT1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
