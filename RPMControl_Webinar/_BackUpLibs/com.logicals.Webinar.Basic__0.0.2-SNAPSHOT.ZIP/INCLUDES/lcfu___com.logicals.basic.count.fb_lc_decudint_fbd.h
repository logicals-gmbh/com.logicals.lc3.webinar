#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__SUB.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_UDINT LC_VD_CNT;
  LC_TD_UDINT LC_VD___2_SUB;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD(p) \
{ \
  (p)->LC_VD_CNT = (LC_TD_UDINT)0UL; \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD(p,RF) \
{ \
  if (RF==0) (p)->LC_VD_CNT = (LC_TD_UDINT)0UL; \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_DECUDINT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
