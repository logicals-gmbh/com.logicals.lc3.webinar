#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLE_ST__C

#include <lcfu___com.logicals.basic.logic.fb_lc_toggle_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_IN;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
  }
  {
    LC_TD_Function_XOR__BOOL lFunction_XOR;
    LC_INIT_Function_XOR__BOOL(&lFunction_XOR);
    lFunction_XOR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__XOR__BOOL__2(&lFunction_XOR, LC_this->LC_VD_R_TRIG.LC_VD_Q, LC_this->LC_VD_VOX_OUT, pEPDB);
    LC_this->LC_VD_VOX_OUT = lFunction_XOR.LC_VD_XOR;
  }
}

#endif
