#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST__C

#include <lcfu___com.logicals.basic.count.fb_lc_cntmsg_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_CNT == LC_EL_true))
  {
    LC_this->LC_VD_VOUI_CNTVAL = (LC_TD_UINT)(LC_this->LC_VD_VOUI_CNTVAL + (LC_TD_UINT)1);
  }
}

#endif
