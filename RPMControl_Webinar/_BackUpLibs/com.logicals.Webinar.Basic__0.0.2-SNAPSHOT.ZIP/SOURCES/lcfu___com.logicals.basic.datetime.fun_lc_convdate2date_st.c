#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_convdate2date_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST* LC_this, LC_TD_UINT LC_VD_VIUI_YEAR, LC_TD_UINT LC_VD_VIUI_MONTH, LC_TD_UINT LC_VD_VIUI_DAY, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_TD_UINT LC_VD_LUI_COUNT;
  LC_INIT_UINT(&(LC_VD_LUI_COUNT));
  if ((LC_TD_BOOL)(LC_VD_VIUI_MONTH > (LC_TD_UINT)2))
  {
    LC_VD_LUI_COUNT = (LC_TD_UINT)((LC_TD_UINT)(LC_VD_VIUI_MONTH - (LC_TD_UINT)1) * (LC_TD_UINT)30);
    if ((LC_TD_BOOL)(LC_VD_VIUI_MONTH > (LC_TD_UINT)7))
    {
      {
        LC_TD_Function_SHR__UINT lFunction__rightOp_SHR;
        LC_INIT_Function_SHR__UINT(&lFunction__rightOp_SHR);
        lFunction__rightOp_SHR.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__SHR__UINT(&lFunction__rightOp_SHR, (LC_TD_UINT)(LC_VD_VIUI_MONTH - (LC_TD_UINT)3), (LC_TD_INT)1, pEPDB);
        LC_VD_LUI_COUNT = (LC_TD_UINT)(LC_VD_LUI_COUNT + lFunction__rightOp_SHR.LC_VD_SHR);
      }
    }
    else
    {
      {
        LC_TD_Function_SHR__UINT lFunction__rightOp_SHR;
        LC_INIT_Function_SHR__UINT(&lFunction__rightOp_SHR);
        lFunction__rightOp_SHR.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__SHR__UINT(&lFunction__rightOp_SHR, (LC_TD_UINT)(LC_VD_VIUI_MONTH - (LC_TD_UINT)4), (LC_TD_INT)1, pEPDB);
        LC_VD_LUI_COUNT = (LC_TD_UINT)(LC_VD_LUI_COUNT + lFunction__rightOp_SHR.LC_VD_SHR);
      }
    }
    {
      LC_TD_BOOL conditionResult = LC_EL_false;
      {
        LC_TD_Function_SHL__UINT lFunction__leftOp_SHL;
        LC_INIT_Function_SHL__UINT(&lFunction__leftOp_SHL);
        lFunction__leftOp_SHL.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__SHL__UINT(&lFunction__leftOp_SHL, LC_VD_VIUI_YEAR, (LC_TD_INT)14, pEPDB);
        conditionResult = (LC_TD_BOOL)(lFunction__leftOp_SHL.LC_VD_SHL == (LC_TD_UINT)0);
      }
      if (conditionResult)
      {
        LC_VD_LUI_COUNT = (LC_TD_UINT)(LC_VD_LUI_COUNT + (LC_TD_UINT)1);
      }
    }
  }
  else
  {
    LC_VD_LUI_COUNT = (LC_TD_UINT)((LC_TD_UINT)(LC_VD_VIUI_MONTH - (LC_TD_UINT)1) * (LC_TD_UINT)31);
  }
  {
    LC_TD_Function_TO_UDINT lFunction_TO_DATE__IN__leftOp__rightOp_SHR__IN__leftOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_DATE__IN__leftOp__leftOp_TO_UDINT;
    LC_TD_Function_SHR__UDINT lFunction_TO_DATE__IN__leftOp__rightOp_SHR;
    LC_TD_Function_TO_DATE lFunction_TO_DATE;
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DATE__IN__leftOp__rightOp_SHR__IN__leftOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DATE__IN__leftOp__leftOp_TO_UDINT);
    LC_INIT_Function_SHR__UDINT(&lFunction_TO_DATE__IN__leftOp__rightOp_SHR);
    LC_INIT_Function_TO_DATE(&lFunction_TO_DATE);
    lFunction_TO_DATE__IN__leftOp__rightOp_SHR__IN__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__UINT(&lFunction_TO_DATE__IN__leftOp__rightOp_SHR__IN__leftOp__leftOp_TO_UDINT, LC_VD_VIUI_YEAR, pEPDB);
    lFunction_TO_DATE__IN__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__UINT(&lFunction_TO_DATE__IN__leftOp__leftOp_TO_UDINT, (LC_TD_UINT)((LC_TD_UINT)(LC_VD_LUI_COUNT + LC_VD_VIUI_DAY) - (LC_TD_UINT)1), pEPDB);
    lFunction_TO_DATE__IN__leftOp__rightOp_SHR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SHR__UDINT(&lFunction_TO_DATE__IN__leftOp__rightOp_SHR, (LC_TD_UDINT)((LC_TD_UDINT)(lFunction_TO_DATE__IN__leftOp__rightOp_SHR__IN__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)1461UL) - (LC_TD_UDINT)2878169UL), (LC_TD_INT)2, pEPDB);
    lFunction_TO_DATE.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DATE__UDINT(&lFunction_TO_DATE, (LC_TD_UDINT)((LC_TD_UDINT)(lFunction_TO_DATE__IN__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT + lFunction_TO_DATE__IN__leftOp__rightOp_SHR.LC_VD_SHR) * (LC_TD_UDINT)86400UL), pEPDB);
    LC_this->LC_VD_FUN_LC_CONVDATE2DATE_ST = lFunction_TO_DATE.LC_VD_TO_DATE;
  }
}

#endif
