#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_calcdt_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST* LC_this, LC_TD_UINT LC_VD_VIUI_YEAR, LC_TD_UINT LC_VD_VIUI_MONTH, LC_TD_UINT LC_VD_VIUI_DAY, LC_TD_UINT LC_VD_VIUI_HOUR, LC_TD_UINT LC_VD_VIUI_MINUTE, LC_TD_UINT LC_VD_VIUI_SECOND, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT__IN_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST;
    LC_TD_Function_TO_UDINT lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_DT__IN__leftOp__leftOp__rightOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_DT__IN__leftOp__rightOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_DT__IN__rightOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_DT lFunction_TO_DT;
    LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST(&lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT__IN_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DT__IN__leftOp__leftOp__rightOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DT__IN__leftOp__rightOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_DT__IN__rightOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_DT(&lFunction_TO_DT);
    lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT__IN_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST.LC_VD_ENO = LC_EL_true;
    lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST(&lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT__IN_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST, LC_VD_VIUI_YEAR, LC_VD_VIUI_MONTH, LC_VD_VIUI_DAY, pEPDB);
    lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__DATE(&lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT, lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT__IN_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVDATE2DATE_ST.LC_VD_FUN_LC_CONVDATE2DATE_ST, pEPDB);
    lFunction_TO_DT__IN__leftOp__leftOp__rightOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__UINT(&lFunction_TO_DT__IN__leftOp__leftOp__rightOp_TO_UDINT, LC_VD_VIUI_SECOND, pEPDB);
    lFunction_TO_DT__IN__leftOp__rightOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__UINT(&lFunction_TO_DT__IN__leftOp__rightOp__leftOp_TO_UDINT, LC_VD_VIUI_MINUTE, pEPDB);
    lFunction_TO_DT__IN__rightOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__UINT(&lFunction_TO_DT__IN__rightOp__leftOp_TO_UDINT, LC_VD_VIUI_HOUR, pEPDB);
    lFunction_TO_DT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DT__UDINT(&lFunction_TO_DT, (LC_TD_UDINT)((LC_TD_UDINT)((LC_TD_UDINT)(lFunction_TO_DT__IN__leftOp__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT + lFunction_TO_DT__IN__leftOp__leftOp__rightOp_TO_UDINT.LC_VD_TO_UDINT) + (LC_TD_UDINT)(lFunction_TO_DT__IN__leftOp__rightOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)60UL)) + (LC_TD_UDINT)(lFunction_TO_DT__IN__rightOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)3600UL)), pEPDB);
    LC_this->LC_VD_FUN_LC_CALCDT_ST = lFunction_TO_DT.LC_VD_TO_DT;
  }
}

#endif
