#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD__C

#include <lcfu___com.logicals.basic.logic.fb_lc_togglesw_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SET)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_TRG)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESET)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS)); \
  LC_INIT_BOOL(&((p)->LC_VD___116_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___114_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___117_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___113_OR)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_TRG),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___116_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___114_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___117_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___113_OR),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_TRG;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VOX_OUT)), LC_this->LC_VD_R_TRIG.LC_VD_Q, pEPDB);
      LC_this->LC_VD___117_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_VIX_SET, LC_this->LC_VD___117_AND, pEPDB);
      LC_this->LC_VD___113_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_R_TRIG.LC_VD_Q, LC_this->LC_VD_VOX_OUT, pEPDB);
      LC_this->LC_VD___116_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD___116_AND, LC_this->LC_VD_VIX_RESET, pEPDB);
      LC_this->LC_VD___114_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_RS.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS.LC_VD_S = LC_this->LC_VD___113_OR;
      LC_this->LC_VD_RS.LC_VD_R1 = LC_this->LC_VD___114_OR;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS), pEPDB);
      LC_this->LC_VD_VOX_OUT = LC_this->LC_VD_RS.LC_VD_Q1;
    }
  }
}

#endif
