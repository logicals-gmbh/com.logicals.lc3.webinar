#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST__C

#include <lcfu___com.logicals.basic.control.fb_lc_cntrl_pidt1_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__DIV.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_INP)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_TI)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_KV)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_T1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_AUTO)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_YMANUAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_LVU)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_LVD)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_KP)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_CYCTM_SEC)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LU)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LD)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_P)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_I)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_D)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEFLAG)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_IOLD)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DTV)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_PDT1)); \
  (p)->LC_VD_LX_CORR_I = LC_EL_false; \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_INP),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_TI),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_KV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_T1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_AUTO),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_YMANUAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_LVU),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_LVD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_KP),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_CYCTM_SEC),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LU),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_P),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_I),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_D),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEFLAG),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_IOLD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DTV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_PDT1),RF); \
  if (RF==0) (p)->LC_VD_LX_CORR_I = LC_EL_false; \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_CNTRL_PIDT1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIR_CYCTM_SEC == (LC_TD_REAL)0.0))
  {
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)1;
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_ERR == LC_EL_false))
  {
    LC_this->LC_VD_LR_DTV = LC_this->LC_VD_VIR_CYCTM_SEC;
    LC_this->LC_VD_VOR_P = (LC_TD_REAL)(LC_this->LC_VD_VIR_INP * LC_this->LC_VD_VIR_KP);
    {
      LC_TD_BOOL conditionResult = LC_EL_false;
      conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_CYCLEFLAG,(LC_TD_BOOL)(LC_this->LC_VD_VIR_T1 > (LC_TD_REAL)0.0)));
      if (conditionResult)
      {
        LC_this->LC_VD_VOR_D = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)(LC_this->LC_VD_VIR_T1 * (LC_TD_REAL)((LC_TD_REAL)(LC_this->LC_VD_VOR_D + (LC_TD_REAL)(LC_this->LC_VD_VIR_KV * LC_this->LC_VD_VIR_INP)) - LC_this->LC_VD_LR_IOLD)),(LC_TD_REAL)(LC_this->LC_VD_VIR_T1 + LC_this->LC_VD_LR_DTV)));
      }
      else
      {
        LC_this->LC_VD_VOR_D = (LC_TD_REAL)0.0;
      }
    }
    LC_this->LC_VD_LR_PDT1 = (LC_TD_REAL)(LC_this->LC_VD_VOR_P + LC_this->LC_VD_VOR_D);
    if (LC_this->LC_VD_VIX_AUTO)
    {
      {
        LC_TD_BOOL conditionResult = LC_EL_false;
        conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_CYCLEFLAG,(LC_TD_BOOL)(LC_this->LC_VD_VIR_KP != (LC_TD_REAL)0.0))),(LC_TD_BOOL)(LC_this->LC_VD_VIR_TI > (LC_TD_REAL)0.0)));
        if (conditionResult)
        {
          LC_this->LC_VD_VOR_I = (LC_TD_REAL)(LC_this->LC_VD_VOR_I + (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)((LC_TD_REAL)(LC_this->LC_VD_VIR_KP * LC_this->LC_VD_LR_DTV) * (LC_TD_REAL)(LC_this->LC_VD_VIR_INP + LC_this->LC_VD_LR_IOLD)),(LC_TD_REAL)2)));
        }
      }
    }
    if (LC_this->LC_VD_VIX_AUTO)
    {
      LC_this->LC_VD_VOR_OUT = (LC_TD_REAL)(LC_this->LC_VD_LR_PDT1 + LC_this->LC_VD_VOR_I);
    }
    else
    {
      LC_this->LC_VD_VOR_OUT = LC_this->LC_VD_VIR_YMANUAL;
      LC_this->LC_VD_LX_CORR_I = LC_EL_true;
    }
    LC_this->LC_VD_LR_IOLD = LC_this->LC_VD_VIR_INP;
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOR_OUT > LC_this->LC_VD_VIR_LVU))
    {
      LC_this->LC_VD_VOR_OUT = LC_this->LC_VD_VIR_LVU;
      LC_this->LC_VD_VOX_LU = LC_EL_true;
      LC_this->LC_VD_VOX_LD = LC_EL_false;
      LC_this->LC_VD_LX_CORR_I = LC_EL_true;
    }
    else
    {
      if ((LC_TD_BOOL)(LC_this->LC_VD_VOR_OUT <= LC_this->LC_VD_VIR_LVD))
      {
        LC_this->LC_VD_VOR_OUT = LC_this->LC_VD_VIR_LVD;
        LC_this->LC_VD_VOX_LU = LC_EL_false;
        LC_this->LC_VD_VOX_LD = LC_EL_true;
        LC_this->LC_VD_LX_CORR_I = LC_EL_true;
      }
      else
      {
        LC_this->LC_VD_VOX_LU = LC_EL_false;
        LC_this->LC_VD_VOX_LD = LC_EL_false;
      }
    }
    if (LC_this->LC_VD_LX_CORR_I)
    {
      LC_this->LC_VD_VOR_I = (LC_TD_REAL)(LC_this->LC_VD_VOR_OUT - LC_this->LC_VD_LR_PDT1);
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_AUTO == LC_EL_false))
    {
      LC_this->LC_VD_VOR_OUT = LC_this->LC_VD_VIR_YMANUAL;
    }
    LC_this->LC_VD_LX_CYCLEFLAG = LC_EL_true;
  }
}

#endif
