#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST__C

#include <lcfu___com.logicals.basic.siggen.fb_lc_gentrianglesig_st.h>
#include <lcfu_iec61131__DIV.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST* p = LC_this; \
  (p)->LC_VD_VIT_CYCLETIME_MS = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(100000000)); \
  (p)->LC_VD_VIUI_MAXVAL = (LC_TD_UINT)1024; \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_OUT)); \
  LC_INIT_WORD(&((p)->LC_VD_VOW_OUT)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_CYCLETIME)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_NOCYC)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_FACTOR)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MAXVAL)); \
  (p)->LC_VD_LR_OUT = (LC_TD_REAL)0.0; \
  (p)->LC_VD_LX_UP = LC_EL_true; \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST* p = LC_this; \
  if (RF==0) (p)->LC_VD_VIT_CYCLETIME_MS = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(100000000)); \
  if (RF==0) (p)->LC_VD_VIUI_MAXVAL = (LC_TD_UINT)1024; \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_OUT),RF); \
  LC_WINIT_WORD(&((p)->LC_VD_VOW_OUT),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_CYCLETIME),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_NOCYC),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_FACTOR),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MAXVAL),RF); \
  if (RF==0) (p)->LC_VD_LR_OUT = (LC_TD_REAL)0.0; \
  if (RF==0) (p)->LC_VD_LX_UP = LC_EL_true; \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENTRIANGLESIG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  {
    LC_TD_Function_TO_REAL lFunction_TO_REAL;
    LC_INIT_Function_TO_REAL(&lFunction_TO_REAL);
    lFunction_TO_REAL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_REAL__TIME(&lFunction_TO_REAL, LC_this->LC_VD_VIT_CYCLETIME_MS, pEPDB);
    LC_this->LC_VD_LR_CYCLETIME = lFunction_TO_REAL.LC_VD_TO_REAL;
  }
  {
    LC_TD_Function_TO_REAL lFunction_TO_REAL;
    LC_INIT_Function_TO_REAL(&lFunction_TO_REAL);
    lFunction_TO_REAL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_REAL__UINT(&lFunction_TO_REAL, LC_this->LC_VD_VIUI_MAXVAL, pEPDB);
    LC_this->LC_VD_LR_MAXVAL = lFunction_TO_REAL.LC_VD_TO_REAL;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_LR_CYCLETIME == (LC_TD_REAL)0.0))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)1;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_LR_MAXVAL == (LC_TD_REAL)0.0))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)2;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_ERR == LC_EL_false))
  {
    {
      LC_TD_Function_TO_REAL lFunction__leftOp__rightOp_TO_REAL;
      LC_INIT_Function_TO_REAL(&lFunction__leftOp__rightOp_TO_REAL);
      lFunction__leftOp__rightOp_TO_REAL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_REAL__TIME(&lFunction__leftOp__rightOp_TO_REAL, LC_this->LC_VD_VIT_CYCLETIME_MS, pEPDB);
      LC_this->LC_VD_LR_NOCYC = (LC_TD_REAL)((lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)1.0,lFunction__leftOp__rightOp_TO_REAL.LC_VD_TO_REAL)) * (LC_TD_REAL)5.0);
    }
    LC_this->LC_VD_LR_FACTOR = (lcfu_iec61131__DIV__REAL__INL(LC_this->LC_VD_LR_MAXVAL,LC_this->LC_VD_LR_NOCYC));
    if ((LC_TD_BOOL)(LC_this->LC_VD_LR_OUT > LC_this->LC_VD_LR_MAXVAL))
    {
      LC_this->LC_VD_LX_UP = LC_EL_false;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_LR_OUT < (LC_TD_REAL)0))
    {
      LC_this->LC_VD_LX_UP = LC_EL_true;
    }
    if (LC_this->LC_VD_LX_UP)
    {
      LC_this->LC_VD_LR_OUT = (LC_TD_REAL)(LC_this->LC_VD_LR_OUT + LC_this->LC_VD_LR_FACTOR);
    }
    else
    {
      LC_this->LC_VD_LR_OUT = (LC_TD_REAL)(LC_this->LC_VD_LR_OUT - LC_this->LC_VD_LR_FACTOR);
    }
    {
      LC_TD_Function_TO_WORD lFunction_TO_WORD;
      LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
      lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_WORD__REAL(&lFunction_TO_WORD, LC_this->LC_VD_LR_OUT, pEPDB);
      LC_this->LC_VD_VOW_OUT = lFunction_TO_WORD.LC_VD_TO_WORD;
    }
    {
      LC_TD_Function_TO_UINT lFunction_TO_UINT;
      LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
      lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_UINT__REAL(&lFunction_TO_UINT, LC_this->LC_VD_LR_OUT, pEPDB);
      LC_this->LC_VD_VOUI_OUT = lFunction_TO_UINT.LC_VD_TO_UINT;
    }
  }
}

#endif
