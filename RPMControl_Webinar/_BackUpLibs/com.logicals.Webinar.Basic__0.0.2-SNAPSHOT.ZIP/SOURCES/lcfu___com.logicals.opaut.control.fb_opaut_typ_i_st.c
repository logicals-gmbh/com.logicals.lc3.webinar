#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST__C

#include <lcfu___com.logicals.opaut.control.fb_opaut_typ_i_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__DIV.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_START,(LC_TD_BOOL)(LC_this->LC_VD_TN_T0 > (LC_TD_REAL)0.001)));
    if (conditionResult)
    {
      LC_this->LC_VD_Y_I = (LC_TD_REAL)(LC_this->LC_VD_Y_I_ALT + (lcfu_iec61131__DIV__REAL__INL(LC_this->LC_VD_E,LC_this->LC_VD_TN_T0)));
      LC_this->LC_VD_Y_I_ALT = LC_this->LC_VD_Y_I;
    }
    else
    {
      LC_this->LC_VD_Y_I = LC_this->LC_VD_Y_I_ALT;
    }
  }
  if (LC_this->LC_VD_RESET)
  {
    LC_this->LC_VD_Y_I = (LC_TD_REAL)0;
    LC_this->LC_VD_Y_I_ALT = (LC_TD_REAL)0;
  }
}

#endif
