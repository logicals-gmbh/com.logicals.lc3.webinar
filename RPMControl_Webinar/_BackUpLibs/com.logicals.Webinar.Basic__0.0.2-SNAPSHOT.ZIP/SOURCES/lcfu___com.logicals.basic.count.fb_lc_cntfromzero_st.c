#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST__C

#include <lcfu___com.logicals.basic.count.fb_lc_cntfromzero_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTFROMZERO_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_R_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_CNTEDGE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
  }
  {
    LC_TD_Function_ADD__UINT lFunction_ADD;
    LC_INIT_Function_ADD__UINT(&lFunction_ADD);
    if ((lFunction_ADD.LC_VD_ENO = LC_this->LC_VD_R_TRIG.LC_VD_Q) != LC_EL_false)
    {
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VOUI_CNTVAL, (LC_TD_UINT)1, pEPDB);
      LC_this->LC_VD_VOUI_CNTVAL = lFunction_ADD.LC_VD_ADD;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_CNTRESET == LC_EL_true))
  {
    LC_this->LC_VD_VOUI_CNTVAL = (LC_TD_UINT)0;
  }
}

#endif
