#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD__C

#include <lcfu___com.logicals.basic.actuator.fb_lc_motor1r_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS1)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1)); \
  LC_INIT_BOOL(&((p)->LC_VD___8_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___16_ENO)); \
  LC_INIT_INT(&((p)->LC_VD___16_MOVE)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS1),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___8_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___16_ENO),RF); \
  LC_WINIT_INT(&((p)->LC_VD___16_MOVE),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_VIX_START, LC_this->LC_VD_VIX_STOP, pEPDB);
      LC_this->LC_VD_VOX_ERR = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___8_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_MOVE__INT lFunction_MOVE;
      LC_INIT_Function_MOVE__INT(&lFunction_MOVE);
      if ((lFunction_MOVE.LC_VD_ENO = LC_this->LC_VD___8_AND) != LC_EL_false)
      {
        lcfu_iec61131__MOVE__INT(&lFunction_MOVE, (LC_TD_INT)1, pEPDB);
        LC_this->LC_VD___16_ENO = lFunction_MOVE.LC_VD_ENO;
        LC_this->LC_VD_VOI_ERRNO = lFunction_MOVE.LC_VD_MOVE;
        LC_this->LC_VD___16_MOVE = lFunction_MOVE.LC_VD_MOVE;
      }
      else
      {
        LC_INIT_BOOL(&(LC_this->LC_VD___16_ENO));
        LC_INIT_INT(&(LC_this->LC_VD___16_MOVE));
      }
    }
  }
  /* Network 2 */
  {
    {
      LC_this->LC_VD_R_TRIG1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG1.LC_VD_CLK = LC_this->LC_VD_VIX_START;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG1), pEPDB);
    }
    {
      LC_this->LC_VD_RS1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS1.LC_VD_S = LC_this->LC_VD_R_TRIG1.LC_VD_Q;
      LC_this->LC_VD_RS1.LC_VD_R1 = LC_this->LC_VD_VIX_STOP;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS1), pEPDB);
      LC_this->LC_VD_VOX_MOTOR = LC_this->LC_VD_RS1.LC_VD_Q1;
    }
  }
}

#endif
