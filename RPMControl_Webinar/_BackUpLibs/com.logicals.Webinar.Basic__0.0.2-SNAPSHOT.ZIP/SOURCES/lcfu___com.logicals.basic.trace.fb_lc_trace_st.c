#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST__C

#include <lcfu___com.logicals.basic.trace.fb_lc_trace_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ETRACEx2EFB_LC_TRACE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_STRING_STACK_OFFSET offset = LC_STRING_STATEMENT_BUFFER(pEPDB);
  {
    LC_this->LC_VD_FB_INITRTRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_INITRTRIG.LC_VD_CLK = LC_EL_true;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_INITRTRIG), pEPDB);
    LC_this->LC_VD_LX_CYCLEINIT = LC_this->LC_VD_FB_INITRTRIG.LC_VD_Q;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIUI_TRACELEVEL == (LC_TD_UINT)0))
  {
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIUI_TRACELEVEL == (LC_TD_UINT)1))
  {
    {
      LC_TD_Function_TRACE lFunction_TRACE;
      LC_INIT_Function_TRACE(&lFunction_TRACE);
      lFunction_TRACE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TRACE(&lFunction_TRACE, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_TRACETEXT,128), pEPDB);
      LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIUI_TRACELEVEL > (LC_TD_UINT)1))
  {
    {
      LC_TD_Function_TRACE lFunction_TRACE;
      LC_INIT_Function_TRACE(&lFunction_TRACE);
      lFunction_TRACE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TRACE(&lFunction_TRACE, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_TRACETEXT,128), pEPDB);
      LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
    }
  }
}

#endif
