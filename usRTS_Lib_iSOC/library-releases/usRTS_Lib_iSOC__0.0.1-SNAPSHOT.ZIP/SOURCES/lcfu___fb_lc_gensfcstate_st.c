#ifndef LC_PROT_LCFU___FB_LC_GENSFCSTATE_ST__C
#define LC_PROT_LCFU___FB_LC_GENSFCSTATE_ST__C

#include <lcfu___fb_lc_gensfcstate_st.h>



/*                            FunctionBlocks                   */
void  lcfu___FB_LC_GENSFCSTATE_ST(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_MOV_STRING(LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_STR_STEPNAME,20,LC_this->LC_VD_VISTR_STEPNAME,20,&LC_this->LC_VD_ENO);
  LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_X_STEPSTATE = LC_this->LC_VD_VIX_STEPSTATE;
  LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_UDI_STEPCOUNT = LC_this->LC_VD_VIUDI_STEPCOUNT;
  LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_T_STEPTIME = LC_this->LC_VD_VIT_STEPTIME;
  LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_UI_STEPNO = LC_this->LC_VD_VIUI_STEPNO;
  LC_this->LC_VD_VOSTRUC_SFCSTATE.LC_VD_X_STEPTRANS = LC_this->LC_VD_VIX_STEPTRANS;
}

#endif
