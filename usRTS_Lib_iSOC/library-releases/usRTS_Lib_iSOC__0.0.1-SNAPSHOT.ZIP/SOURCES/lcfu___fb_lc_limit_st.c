#ifndef LC_PROT_LCFU___FB_LC_LIMIT_ST__C
#define LC_PROT_LCFU___FB_LC_LIMIT_ST__C

#include <lcfu___fb_lc_limit_st.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_LC_LIMIT_ST* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_AI)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_GW_HH)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_GW_H)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_GW_L)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_GW_LL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_HH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_H)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_L)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LL)); \
  (p)->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0; \
  (p)->LC_VD_VOX_ERR = LC_EL_false; \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CHECKLT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CHECKGT)); \
}

void LC_WINIT_FUN_FunctionBlock_FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_LC_LIMIT_ST* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_AI),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_GW_HH),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_GW_H),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_GW_L),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_GW_LL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_HH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_H),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_L),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LL),RF); \
  if (RF==0) (p)->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0; \
  if (RF==0) (p)->LC_VD_VOX_ERR = LC_EL_false; \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CHECKLT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CHECKGT),RF); \
}

void  lcfu___FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_GT lFunction_GT;
    LC_INIT_Function_GT(&lFunction_GT);
    lFunction_GT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_AI, LC_this->LC_VD_VIR_GW_HH, pEPDB);
    LC_this->LC_VD_VOX_HH = lFunction_GT.LC_VD_GT;
  }
  {
    LC_TD_Function_LT lFunction_LT;
    LC_INIT_Function_LT(&lFunction_LT);
    lFunction_LT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_AI, LC_this->LC_VD_VIR_GW_HH, pEPDB);
    LC_this->LC_VD_LX_CHECKLT = lFunction_LT.LC_VD_LT;
  }
  {
    LC_TD_Function_GT lFunction_GT;
    LC_INIT_Function_GT(&lFunction_GT);
    lFunction_GT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_AI, LC_this->LC_VD_VIR_GW_H, pEPDB);
    LC_this->LC_VD_LX_CHECKGT = lFunction_GT.LC_VD_GT;
  }
  {
    LC_TD_Function_AND__BOOL lFunction_AND;
    LC_INIT_Function_AND__BOOL(&lFunction_AND);
    lFunction_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_LX_CHECKLT, LC_this->LC_VD_LX_CHECKGT, pEPDB);
    LC_this->LC_VD_VOX_H = lFunction_AND.LC_VD_AND;
  }
  {
    LC_TD_Function_LT lFunction_LT;
    LC_INIT_Function_LT(&lFunction_LT);
    lFunction_LT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_AI, LC_this->LC_VD_VIR_GW_L, pEPDB);
    LC_this->LC_VD_VOX_L = lFunction_LT.LC_VD_LT;
  }
  {
    LC_TD_Function_LT lFunction_LT;
    LC_INIT_Function_LT(&lFunction_LT);
    lFunction_LT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_AI, LC_this->LC_VD_VIR_GW_LL, pEPDB);
    LC_this->LC_VD_VOX_LL = lFunction_LT.LC_VD_LT;
  }
}

#endif
