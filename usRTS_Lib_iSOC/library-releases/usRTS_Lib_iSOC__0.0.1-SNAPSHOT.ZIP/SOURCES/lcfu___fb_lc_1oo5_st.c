#ifndef LC_PROT_LCFU___FB_LC_1OO5_ST__C
#define LC_PROT_LCFU___FB_LC_1OO5_ST__C

#include <lcfu___fb_lc_1oo5_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_FB_LC_1OO5_ST(LC_TD_FunctionBlock_FB_LC_1OO5_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_LC_1OO5_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT5)); \
}

void LC_WINIT_FUN_FunctionBlock_FB_LC_1OO5_ST(LC_TD_FunctionBlock_FB_LC_1OO5_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_FB_LC_1OO5_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT5),RF); \
}

void  lcfu___FB_LC_1OO5_ST(LC_TD_FunctionBlock_FB_LC_1OO5_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_OUT = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN4)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN5)))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN2,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN4)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN5)))))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN3,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN4)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN5)))))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN4,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN5)))))),(lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN5,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)))),(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN4))))));
  LC_this->LC_VD_VOX_OUT1 = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN1,LC_this->LC_VD_VOX_OUT));
  LC_this->LC_VD_VOX_OUT2 = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN2,LC_this->LC_VD_VOX_OUT));
  LC_this->LC_VD_VOX_OUT3 = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN3,LC_this->LC_VD_VOX_OUT));
  LC_this->LC_VD_VOX_OUT4 = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN4,LC_this->LC_VD_VOX_OUT));
  LC_this->LC_VD_VOX_OUT5 = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_VIX_IN5,LC_this->LC_VD_VOX_OUT));
  LC_this->LC_VD_VOX_ERR = (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VOX_OUT));
}

#endif
