#ifndef LC_PROT_LCFU___FB_LC_GENSFCSTATE_ST__H
#define LC_PROT_LCFU___FB_LC_GENSFCSTATE_ST__H

#include <LC3CGBase.h>
#include <lcdt___dt_lc_sfcval.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST
{
  LC_TD_BOOL LC_VD_VIX_STEPSTATE;
  LC_TD_BOOL LC_VD_VIX_STEPTRANS;
  LC_TD_UINT LC_VD_VIUI_STEPNO;
  LC_TD_UDINT LC_VD_VIUDI_STEPCOUNT;
  LC_TD_TIME LC_VD_VIT_STEPTIME;
  LcCgChar LC_VD_VISTR_STEPNAME[21];
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_DataType_DT_LC_SFCVAL LC_VD_VOSTRUC_SFCSTATE;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_FB_LC_GENSFCSTATE_ST(p) \
{ \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STEPCOUNT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STEPTRANS)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_STEPTIME)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STEPSTATE)); \
  LC_INIT_SIZED_STRING(&((p)->LC_VD_VISTR_STEPNAME)); \
  LC_INIT_UINT(&((p)->LC_VD_VIUI_STEPNO)); \
  LC_INIT_DataType_DT_LC_SFCVAL(&((p)->LC_VD_VOSTRUC_SFCSTATE)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_FB_LC_GENSFCSTATE_ST(p,RF) \
{ \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STEPCOUNT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STEPTRANS),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_STEPTIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STEPSTATE),RF); \
  LC_WINIT_SIZED_STRING(&((p)->LC_VD_VISTR_STEPNAME),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VIUI_STEPNO),RF); \
  LC_WINIT_DataType_DT_LC_SFCVAL(&((p)->LC_VD_VOSTRUC_SFCSTATE),RF); \
}

/*                            Prototype                        */
void  lcfu___FB_LC_GENSFCSTATE_ST(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
