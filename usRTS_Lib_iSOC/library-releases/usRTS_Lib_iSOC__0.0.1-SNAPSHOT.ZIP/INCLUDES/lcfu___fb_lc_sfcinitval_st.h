#ifndef LC_PROT_LCFU___FB_LC_SFCINITVAL_ST__H
#define LC_PROT_LCFU___FB_LC_SFCINITVAL_ST__H

#include <LC3CGBase.h>
#include <lcdt___dt_lc_sfcval.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_LC_SFCINITVAL_ST
{
  LC_TD_DataType_DT_LC_SFCVAL LC_VD_VIARRSTRUC_SFCSTATE[21];
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_DataType_DT_LC_SFCVAL LC_VD_VOARRSTRUC_SFCSTATE[21];
  LC_TD_REAL LC_VD_VORARR_SETSFC20TIME[21];
  LC_TD_REAL LC_VD_VORARR_SFC20TIME[21];
  LC_TD_REAL LC_VD_VORARR_SFC20TIME_ACT[21];
  LC_TD_TIME LC_VD_VOTARR_SFC20TIME[21];
  LC_TD_TIME LC_VD_VOTARR_SFC20TIME_ACT[21];
  LC_TD_BOOL LC_VD_VOXARR_SFC20_ACTION_STATE[21];
  LC_TD_UINT LC_VD_LUI_IDX;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_LC_SFCINITVAL_ST;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_LC_SFCINITVAL_ST(LC_TD_FunctionBlock_FB_LC_SFCINITVAL_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_LC_SFCINITVAL_ST(p) LC_INIT_FUN_FunctionBlock_FB_LC_SFCINITVAL_ST((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_LC_SFCINITVAL_ST(LC_TD_FunctionBlock_FB_LC_SFCINITVAL_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_LC_SFCINITVAL_ST(p,RF) LC_WINIT_FUN_FunctionBlock_FB_LC_SFCINITVAL_ST((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_LC_SFCINITVAL_ST(LC_TD_FunctionBlock_FB_LC_SFCINITVAL_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
