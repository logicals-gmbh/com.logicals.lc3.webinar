#ifndef LC_PROT_LCFU___FB_LC_SCALE_ST__H
#define LC_PROT_LCFU___FB_LC_SCALE_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__DIV.h>
#include <lcfu_iec61131__GT.h>
#include <lcfu_iec61131__LT.h>
#include <lcfu_iec61131__MUL.h>
#include <lcfu_iec61131__NE.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcfu_iec61131__SUB.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_LC_SCALE_ST
{
  LC_TD_REAL LC_VD_VIR_IN;
  LC_TD_REAL LC_VD_VIR_MAXINVAL;
  LC_TD_REAL LC_VD_VIR_MAXPHYSVAL;
  LC_TD_REAL LC_VD_VIR_MININVAL;
  LC_TD_REAL LC_VD_VIR_MINPHYSVAL;
  LC_TD_REAL LC_VD_VIR_OFFSETPHYSVAL;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_INVALERROR;
  LC_TD_BOOL LC_VD_VOX_PHYSVALERROR;
  LC_TD_UINT LC_VD_VOUI_ERRNO;
  LC_TD_REAL LC_VD_VOR_OUTPHYSVAL;
  LC_TD_BOOL LC_VD_LX_CYCLEINIT;
  LC_TD_BOOL LC_VD_LX_CYCLEPULSE;
  LC_TD_BOOL LC_VD_LX_NOTEQUALDELTAINVAL;
  LC_TD_INT LC_VD_LI_CYCLECOUNT;
  LC_TD_REAL LC_VD_LR_DELTAINVAL;
  LC_TD_REAL LC_VD_LR_DELTAPHYSVAL;
  LC_TD_REAL LC_VD_LR_SCALE;
  LC_TD_REAL LC_VD_LR_STEIGUNG;
  LC_TD_FunctionBlock_R_TRIG LC_VD_FB_INITR_TRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_LC_SCALE_ST;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_LC_SCALE_ST(LC_TD_FunctionBlock_FB_LC_SCALE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_LC_SCALE_ST(p) LC_INIT_FUN_FunctionBlock_FB_LC_SCALE_ST((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_LC_SCALE_ST(LC_TD_FunctionBlock_FB_LC_SCALE_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_LC_SCALE_ST(p,RF) LC_WINIT_FUN_FunctionBlock_FB_LC_SCALE_ST((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_LC_SCALE_ST(LC_TD_FunctionBlock_FB_LC_SCALE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
