#ifndef LC_PROT_LCFU___FB_LC_LIMIT_ST__H
#define LC_PROT_LCFU___FB_LC_LIMIT_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__GT.h>
#include <lcfu_iec61131__LT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_FB_LC_LIMIT_ST
{
  LC_TD_REAL LC_VD_VIR_AI;
  LC_TD_REAL LC_VD_VIR_GW_H;
  LC_TD_REAL LC_VD_VIR_GW_HH;
  LC_TD_REAL LC_VD_VIR_GW_L;
  LC_TD_REAL LC_VD_VIR_GW_LL;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_H;
  LC_TD_BOOL LC_VD_VOX_HH;
  LC_TD_BOOL LC_VD_VOX_L;
  LC_TD_BOOL LC_VD_VOX_LL;
  LC_TD_UINT LC_VD_VOUI_ERRNO;
  LC_TD_BOOL LC_VD_LX_CHECKGT;
  LC_TD_BOOL LC_VD_LX_CHECKLT;
} LCCG_StructAttrib LC_TD_FunctionBlock_FB_LC_LIMIT_ST;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_FB_LC_LIMIT_ST(p) LC_INIT_FUN_FunctionBlock_FB_LC_LIMIT_ST((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_FB_LC_LIMIT_ST(p,RF) LC_WINIT_FUN_FunctionBlock_FB_LC_LIMIT_ST((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___FB_LC_LIMIT_ST(LC_TD_FunctionBlock_FB_LC_LIMIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
