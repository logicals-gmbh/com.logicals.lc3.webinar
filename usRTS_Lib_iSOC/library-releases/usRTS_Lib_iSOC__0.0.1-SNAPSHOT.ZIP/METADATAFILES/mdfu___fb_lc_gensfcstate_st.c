#include <RISMD.h>
#include <lcfu___fb_lc_gensfcstate_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

RISMDStringType const lcmd_type_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME_STR RISMD_ATTRIBUTES = INIT_RISMDStringType(21);
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME[] RISMD_ATTRIBUTES = "vistr_StepName";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME, &lcmd_type_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME_STR, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VISTR_STEPNAME), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDSimpleNumType const risMdType_TIME;
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIT_STEPTIME[] RISMD_ATTRIBUTES = "vit_StepTime";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VIT_STEPTIME RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIT_STEPTIME, &risMdType_TIME, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VIT_STEPTIME), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDSimpleNumType const risMdType_UDINT;
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIUDI_STEPCOUNT[] RISMD_ATTRIBUTES = "viudi_StepCount";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VIUDI_STEPCOUNT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIUDI_STEPCOUNT, &risMdType_UDINT, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VIUDI_STEPCOUNT), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIUI_STEPNO[] RISMD_ATTRIBUTES = "viui_StepNo";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VIUI_STEPNO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIUI_STEPNO, &risMdType_UINT, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VIUI_STEPNO), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIX_STEPSTATE[] RISMD_ATTRIBUTES = "vix_StepState";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VIX_STEPSTATE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIX_STEPSTATE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VIX_STEPSTATE), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIX_STEPTRANS[] RISMD_ATTRIBUTES = "vix_StepTrans";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VIX_STEPTRANS RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VIX_STEPTRANS, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VIX_STEPTRANS), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDCompoundType const lcmd_type_DT_LC_SFCVAL;
static char const lcmd_var_name_FB_LC_GENSFCSTATE_ST_VOSTRUC_SFCSTATE[] RISMD_ATTRIBUTES = "vostruc_SFCState";
static RISMDInterfaceVariable const lcmd_var_FB_LC_GENSFCSTATE_ST_VOSTRUC_SFCSTATE RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_GENSFCSTATE_ST_VOSTRUC_SFCSTATE, &lcmd_type_DT_LC_SFCVAL, offsetof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST,LC_VD_VOSTRUC_SFCSTATE), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_FB_LC_GENSFCSTATE_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_ENO),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VISTR_STEPNAME),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VIT_STEPTIME),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VIUDI_STEPCOUNT),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VIUI_STEPNO),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VIX_STEPSTATE),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VIX_STEPTRANS),
  INIT_RISMDReference(&lcmd_var_FB_LC_GENSFCSTATE_ST_VOSTRUC_SFCSTATE),
};

static char const lcmd_type_name_FB_LC_GENSFCSTATE_ST[] RISMD_ATTRIBUTES = "FB_LC_GENSFCSTATE_ST";
RISMDPOUType const lcmd_type_FB_LC_GENSFCSTATE_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_LC_GENSFCSTATE_ST, sizeof(LC_TD_FunctionBlock_FB_LC_GENSFCSTATE_ST), 8, lcmd_var_list_FB_LC_GENSFCSTATE_ST);
