#include <RISMD.h>
#include <lcfu___fb_lc_limit_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_LC_LIMIT_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_LX_CHECKGT[] RISMD_ATTRIBUTES = "lx_CheckGT";
static RISMDStdVariable const lcmd_var_FB_LC_LIMIT_ST_LX_CHECKGT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_LIMIT_ST_LX_CHECKGT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_LX_CHECKGT));

static char const lcmd_var_name_FB_LC_LIMIT_ST_LX_CHECKLT[] RISMD_ATTRIBUTES = "lx_CheckLT";
static RISMDStdVariable const lcmd_var_FB_LC_LIMIT_ST_LX_CHECKLT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_LIMIT_ST_LX_CHECKLT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_LX_CHECKLT));

extern RISMDSimpleNumType const risMdType_REAL;
static char const lcmd_var_name_FB_LC_LIMIT_ST_VIR_AI[] RISMD_ATTRIBUTES = "vir_AI";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VIR_AI RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VIR_AI, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VIR_AI), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_H[] RISMD_ATTRIBUTES = "vir_GW_H";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VIR_GW_H RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_H, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VIR_GW_H), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_HH[] RISMD_ATTRIBUTES = "vir_GW_HH";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VIR_GW_HH RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_HH, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VIR_GW_HH), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_L[] RISMD_ATTRIBUTES = "vir_GW_L";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VIR_GW_L RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_L, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VIR_GW_L), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_LL[] RISMD_ATTRIBUTES = "vir_GW_LL";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VIR_GW_LL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VIR_GW_LL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VIR_GW_LL), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_FB_LC_LIMIT_ST_VOUI_ERRNO[] RISMD_ATTRIBUTES = "voui_ErrNo";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOUI_ERRNO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOUI_ERRNO, &risMdType_UINT, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOUI_ERRNO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VOX_ERR[] RISMD_ATTRIBUTES = "vox_Err";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOX_ERR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOX_ERR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOX_ERR), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VOX_H[] RISMD_ATTRIBUTES = "vox_H";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOX_H RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOX_H, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOX_H), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VOX_HH[] RISMD_ATTRIBUTES = "vox_HH";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOX_HH RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOX_HH, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOX_HH), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VOX_L[] RISMD_ATTRIBUTES = "vox_L";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOX_L RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOX_L, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOX_L), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_LIMIT_ST_VOX_LL[] RISMD_ATTRIBUTES = "vox_LL";
static RISMDInterfaceVariable const lcmd_var_FB_LC_LIMIT_ST_VOX_LL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_LIMIT_ST_VOX_LL, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST,LC_VD_VOX_LL), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_FB_LC_LIMIT_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_ENO),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_LX_CHECKGT),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_LX_CHECKLT),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VIR_AI),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VIR_GW_H),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VIR_GW_HH),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VIR_GW_L),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VIR_GW_LL),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOUI_ERRNO),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOX_ERR),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOX_H),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOX_HH),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOX_L),
  INIT_RISMDReference(&lcmd_var_FB_LC_LIMIT_ST_VOX_LL),
};

static char const lcmd_type_name_FB_LC_LIMIT_ST[] RISMD_ATTRIBUTES = "FB_LC_LIMIT_ST";
RISMDPOUType const lcmd_type_FB_LC_LIMIT_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_LC_LIMIT_ST, sizeof(LC_TD_FunctionBlock_FB_LC_LIMIT_ST), 14, lcmd_var_list_FB_LC_LIMIT_ST);
