#include <RISMD.h>
#include <lcfu___fb_lc_scale_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_LC_SCALE_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDPOUType const lcmd_type_R_TRIG;
static char const lcmd_var_name_FB_LC_SCALE_ST_FB_INITR_TRIG[] RISMD_ATTRIBUTES = "FB_InitR_TRIG";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_FB_INITR_TRIG RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_FB_INITR_TRIG, &lcmd_type_R_TRIG, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_FB_INITR_TRIG));

extern RISMDSimpleNumType const risMdType_INT;
static char const lcmd_var_name_FB_LC_SCALE_ST_LI_CYCLECOUNT[] RISMD_ATTRIBUTES = "li_CycleCount";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LI_CYCLECOUNT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LI_CYCLECOUNT, &risMdType_INT, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LI_CYCLECOUNT));

extern RISMDSimpleNumType const risMdType_REAL;
static char const lcmd_var_name_FB_LC_SCALE_ST_LR_DELTAINVAL[] RISMD_ATTRIBUTES = "lr_DeltaInVal";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LR_DELTAINVAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LR_DELTAINVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LR_DELTAINVAL));

static char const lcmd_var_name_FB_LC_SCALE_ST_LR_DELTAPHYSVAL[] RISMD_ATTRIBUTES = "lr_DeltaPhysVal";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LR_DELTAPHYSVAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LR_DELTAPHYSVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LR_DELTAPHYSVAL));

static char const lcmd_var_name_FB_LC_SCALE_ST_LR_SCALE[] RISMD_ATTRIBUTES = "lr_Scale";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LR_SCALE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LR_SCALE, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LR_SCALE));

static char const lcmd_var_name_FB_LC_SCALE_ST_LR_STEIGUNG[] RISMD_ATTRIBUTES = "lr_Steigung";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LR_STEIGUNG RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LR_STEIGUNG, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LR_STEIGUNG));

static char const lcmd_var_name_FB_LC_SCALE_ST_LX_CYCLEINIT[] RISMD_ATTRIBUTES = "lx_CycleInit";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LX_CYCLEINIT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LX_CYCLEINIT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LX_CYCLEINIT));

static char const lcmd_var_name_FB_LC_SCALE_ST_LX_CYCLEPULSE[] RISMD_ATTRIBUTES = "lx_CyclePulse";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LX_CYCLEPULSE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LX_CYCLEPULSE, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LX_CYCLEPULSE));

static char const lcmd_var_name_FB_LC_SCALE_ST_LX_NOTEQUALDELTAINVAL[] RISMD_ATTRIBUTES = "lx_NotEqualDeltaInVal";
static RISMDStdVariable const lcmd_var_FB_LC_SCALE_ST_LX_NOTEQUALDELTAINVAL RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_FB_LC_SCALE_ST_LX_NOTEQUALDELTAINVAL, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_LX_NOTEQUALDELTAINVAL));

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_IN[] RISMD_ATTRIBUTES = "vir_In";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_IN RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_IN, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_IN), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_MAXINVAL[] RISMD_ATTRIBUTES = "vir_MaxInVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_MAXINVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_MAXINVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_MAXINVAL), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_MAXPHYSVAL[] RISMD_ATTRIBUTES = "vir_MaxPhysVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_MAXPHYSVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_MAXPHYSVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_MAXPHYSVAL), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_MININVAL[] RISMD_ATTRIBUTES = "vir_MinInVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_MININVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_MININVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_MININVAL), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_MINPHYSVAL[] RISMD_ATTRIBUTES = "vir_MinPhysVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_MINPHYSVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_MINPHYSVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_MINPHYSVAL), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VIR_OFFSETPHYSVAL[] RISMD_ATTRIBUTES = "vir_OffsetPhysVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VIR_OFFSETPHYSVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VIR_OFFSETPHYSVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VIR_OFFSETPHYSVAL), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VOR_OUTPHYSVAL[] RISMD_ATTRIBUTES = "vor_OutPhysVal";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VOR_OUTPHYSVAL RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VOR_OUTPHYSVAL, &risMdType_REAL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VOR_OUTPHYSVAL), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_FB_LC_SCALE_ST_VOUI_ERRNO[] RISMD_ATTRIBUTES = "voui_ErrNo";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VOUI_ERRNO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VOUI_ERRNO, &risMdType_UINT, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VOUI_ERRNO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VOX_ERR[] RISMD_ATTRIBUTES = "vox_Err";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VOX_ERR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VOX_ERR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VOX_ERR), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VOX_INVALERROR[] RISMD_ATTRIBUTES = "vox_InValError";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VOX_INVALERROR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VOX_INVALERROR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VOX_INVALERROR), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_SCALE_ST_VOX_PHYSVALERROR[] RISMD_ATTRIBUTES = "vox_PhysValError";
static RISMDInterfaceVariable const lcmd_var_FB_LC_SCALE_ST_VOX_PHYSVALERROR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_SCALE_ST_VOX_PHYSVALERROR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_SCALE_ST,LC_VD_VOX_PHYSVALERROR), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_FB_LC_SCALE_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_ENO),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_FB_INITR_TRIG),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LI_CYCLECOUNT),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LR_DELTAINVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LR_DELTAPHYSVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LR_SCALE),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LR_STEIGUNG),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LX_CYCLEINIT),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LX_CYCLEPULSE),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_LX_NOTEQUALDELTAINVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_IN),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_MAXINVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_MAXPHYSVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_MININVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_MINPHYSVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VIR_OFFSETPHYSVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VOR_OUTPHYSVAL),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VOUI_ERRNO),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VOX_ERR),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VOX_INVALERROR),
  INIT_RISMDReference(&lcmd_var_FB_LC_SCALE_ST_VOX_PHYSVALERROR),
};

static char const lcmd_type_name_FB_LC_SCALE_ST[] RISMD_ATTRIBUTES = "FB_LC_SCALE_ST";
RISMDPOUType const lcmd_type_FB_LC_SCALE_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_LC_SCALE_ST, sizeof(LC_TD_FunctionBlock_FB_LC_SCALE_ST), 21, lcmd_var_list_FB_LC_SCALE_ST);
