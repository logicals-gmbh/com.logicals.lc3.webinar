#include <RISMD.h>
#include <lcfu___fb_lc_1oo5_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_FB_LC_1OO5_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VIX_IN1[] RISMD_ATTRIBUTES = "vix_In1";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VIX_IN1 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VIX_IN1, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VIX_IN1), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VIX_IN2[] RISMD_ATTRIBUTES = "vix_In2";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VIX_IN2 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VIX_IN2, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VIX_IN2), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VIX_IN3[] RISMD_ATTRIBUTES = "vix_In3";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VIX_IN3 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VIX_IN3, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VIX_IN3), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VIX_IN4[] RISMD_ATTRIBUTES = "vix_In4";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VIX_IN4 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VIX_IN4, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VIX_IN4), RISMD_VARIABLE_SECTION_INPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VIX_IN5[] RISMD_ATTRIBUTES = "vix_In5";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VIX_IN5 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VIX_IN5, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VIX_IN5), RISMD_VARIABLE_SECTION_INPUT);

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_FB_LC_1OO5_ST_VOUI_ERRNO[] RISMD_ATTRIBUTES = "voui_ErrNo";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOUI_ERRNO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOUI_ERRNO, &risMdType_UINT, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOUI_ERRNO), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_ERR[] RISMD_ATTRIBUTES = "vox_Err";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_ERR RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_ERR, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_ERR), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT[] RISMD_ATTRIBUTES = "vox_Out";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT1[] RISMD_ATTRIBUTES = "vox_Out1";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT1 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT1, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT1), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT2[] RISMD_ATTRIBUTES = "vox_Out2";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT2 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT2, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT2), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT3[] RISMD_ATTRIBUTES = "vox_Out3";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT3 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT3, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT3), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT4[] RISMD_ATTRIBUTES = "vox_Out4";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT4 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT4, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT4), RISMD_VARIABLE_SECTION_OUTPUT);

static char const lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT5[] RISMD_ATTRIBUTES = "vox_Out5";
static RISMDInterfaceVariable const lcmd_var_FB_LC_1OO5_ST_VOX_OUT5 RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_FB_LC_1OO5_ST_VOX_OUT5, &risMdType_BOOL, offsetof(LC_TD_FunctionBlock_FB_LC_1OO5_ST,LC_VD_VOX_OUT5), RISMD_VARIABLE_SECTION_OUTPUT);

static RISMDReference const lcmd_var_list_FB_LC_1OO5_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_ENO),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VIX_IN1),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VIX_IN2),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VIX_IN3),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VIX_IN4),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VIX_IN5),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOUI_ERRNO),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_ERR),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT1),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT2),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT3),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT4),
  INIT_RISMDReference(&lcmd_var_FB_LC_1OO5_ST_VOX_OUT5),
};

static char const lcmd_type_name_FB_LC_1OO5_ST[] RISMD_ATTRIBUTES = "FB_LC_1OO5_ST";
RISMDPOUType const lcmd_type_FB_LC_1OO5_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_FB_LC_1OO5_ST, sizeof(LC_TD_FunctionBlock_FB_LC_1OO5_ST), 14, lcmd_var_list_FB_LC_1OO5_ST);
