#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__NOT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST
{
  LC_TD_BOOL LC_VD_VIX_IN1;
  LC_TD_BOOL LC_VD_VIX_IN2;
  LC_TD_BOOL LC_VD_VIX_IN3;
  LC_TD_BOOL LC_VD_VIX_IN4;
  LC_TD_BOOL LC_VD_VIX_IN5;
  LC_TD_BOOL LC_VD_VIX_IN6;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_OUT1;
  LC_TD_BOOL LC_VD_VOX_OUT2;
  LC_TD_BOOL LC_VD_VOX_OUT3;
  LC_TD_BOOL LC_VD_VOX_OUT4;
  LC_TD_BOOL LC_VD_VOX_OUT5;
  LC_TD_BOOL LC_VD_VOX_OUT6;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(p) LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(p,RF) LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
