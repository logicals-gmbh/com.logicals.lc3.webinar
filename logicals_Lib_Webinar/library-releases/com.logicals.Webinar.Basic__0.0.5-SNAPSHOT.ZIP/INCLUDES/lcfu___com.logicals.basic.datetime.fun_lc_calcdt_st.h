#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.datetime.fun_lc_convdate2date_st.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__TO_DT.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_DT LC_VD_FUN_LC_CALCDT_ST;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST(p) \
{ \
  LC_INIT_DT(&((p)->LC_VD_FUN_LC_CALCDT_ST)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDT_ST* LC_this, LC_TD_UINT LC_VD_VIUI_YEAR, LC_TD_UINT LC_VD_VIUI_MONTH, LC_TD_UINT LC_VD_VIUI_DAY, LC_TD_UINT LC_VD_VIUI_HOUR, LC_TD_UINT LC_VD_VIUI_MINUTE, LC_TD_UINT LC_VD_VIUI_SECOND, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
