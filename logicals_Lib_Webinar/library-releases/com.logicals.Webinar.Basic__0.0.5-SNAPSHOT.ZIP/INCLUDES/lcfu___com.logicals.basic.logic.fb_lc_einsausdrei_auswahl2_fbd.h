#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD
{
  LC_TD_BOOL LC_VD_VIX_IN1;
  LC_TD_BOOL LC_VD_VIX_IN2;
  LC_TD_BOOL LC_VD_VIX_IN3;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_BOOL LC_VD___13_AND;
  LC_TD_BOOL LC_VD___14_AND;
  LC_TD_BOOL LC_VD___15_OR;
  LC_TD_BOOL LC_VD___16_AND;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
