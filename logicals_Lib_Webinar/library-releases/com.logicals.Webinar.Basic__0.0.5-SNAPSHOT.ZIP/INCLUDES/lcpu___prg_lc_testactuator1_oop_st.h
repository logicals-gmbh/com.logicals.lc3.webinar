#ifndef LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_OOP_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_OOP_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.oop.actuator.fb_lc_idf_2dirvarspeed1_oop_st.h>
#include <lcfu_iec61131__NOT.h>
#include <lcpu___prg_lc_testactuator1_oop_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTACTUATOR1_OOP_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LX_BWD;
  LC_TD_BOOL LC_VD_LX_CYCLEINIT;
  LC_TD_BOOL LC_VD_LX_CYCLEPULSE;
  LC_TD_BOOL LC_VD_LX_FWD;
  LC_TD_BOOL LC_VD_LX_ISACTIVATED;
  LC_TD_BOOL LC_VD_LX_ISLOCKED;
  LC_TD_BOOL LC_VD_LX_MANUALLOCK;
  LC_TD_BOOL LC_VD_LX_MOTOR;
  LC_TD_BOOL LC_VD_LX_MOTORENABLE;
  LC_TD_BOOL LC_VD_LX_OFF;
  LC_TD_BOOL LC_VD_LX_ON;
  LC_TD_INT LC_VD_LI_CYCLECOUNT;
  LC_TD_INT LC_VD_LI_CYCLECOUNTINIT;
  LC_TD_INT LC_VD_LI_SPEEDVAL;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOOPx2EACTUATORx2EFB_LC_IDF_2DIRVARSPEED1_OOP_ST LC_VD_FB_IDF_2DIRVARSPEED_OOP_ST;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTACTUATOR1_OOP_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOOPx2EACTUATORx2EFB_LC_IDF_2DIRVARSPEED1_OOP_ST(&((p)->LC_VD_FB_IDF_2DIRVARSPEED_OOP_ST)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_ON)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_OFF)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_FWD)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_BWD)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MANUALLOCK)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTORENABLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_ISACTIVATED)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_ISLOCKED)); \
  LC_INIT_INT(&((p)->LC_VD_LI_SPEEDVAL)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \

#define LC_INIT_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOOPx2EACTUATORx2EFB_LC_IDF_2DIRVARSPEED1_OOP_ST(&((p)->LC_VD_FB_IDF_2DIRVARSPEED_OOP_ST),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_ON),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_OFF),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_FWD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_BWD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MANUALLOCK),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTORENABLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_ISACTIVATED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_ISLOCKED),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_SPEEDVAL),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \

#define LC_WINIT_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTACTUATOR1_OOP_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTACTUATOR1_OOP_ST(LC_TD_Program_PRG_LC_TESTACTUATOR1_OOP_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
