#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD__C

#include <lcfu___com.logicals.basic.sequence.fb_lc_sequence_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESET)); \
  (p)->LC_VD_VIT_SEQTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_STEP0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_STEP1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_STEP2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_STEP3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_STEP4)); \
  LC_INIT_ARRAY(&((p)->LC_VD_VOTARR_STEPTIME),TIME,5); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON2)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON3)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON4)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON)); \
  LC_INIT_BOOL(&((p)->LC_VD___26_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___27_AND)); \
  LC_INIT_DataType__INITSTEPTYPE(&((p)->LC_VD_S0)); \
  LC_INIT_DataType__STEPTYPE(&((p)->LC_VD_S1)); \
  LC_INIT_DataType__STEPTYPE(&((p)->LC_VD_S2)); \
  LC_INIT_DataType__STEPTYPE(&((p)->LC_VD_S3)); \
  LC_INIT_DataType__STEPTYPE(&((p)->LC_VD_S4)); \
  LC_INIT_BOOL(&((p)->LC_VD_T0)); \
  LC_INIT_BOOL(&((p)->LC_VD_T1)); \
  LC_INIT_BOOL(&((p)->LC_VD_T2)); \
  LC_INIT_BOOL(&((p)->LC_VD_T3)); \
  LC_INIT_BOOL(&((p)->LC_VD_T4)); \
  LC_INIT_BOOL(&((p)->LC_VD_T5)); \
  LC_INIT_BOOL(&((p)->LC_VD_T6)); \
  LC_INIT_BOOL(&((p)->LC_VD_T7)); \
  LC_INIT_BOOL(&((p)->LC_VD_T8)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESET),RF); \
  if (RF==0) (p)->LC_VD_VIT_SEQTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_STEP0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_STEP1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_STEP2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_STEP3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_STEP4),RF); \
  LC_WINIT_ARRAY(&((p)->LC_VD_VOTARR_STEPTIME),TIME,5,RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON2),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON3),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON4),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___26_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___27_AND),RF); \
  LC_WINIT_DataType__INITSTEPTYPE(&((p)->LC_VD_S0),RF); \
  LC_WINIT_DataType__STEPTYPE(&((p)->LC_VD_S1),RF); \
  LC_WINIT_DataType__STEPTYPE(&((p)->LC_VD_S2),RF); \
  LC_WINIT_DataType__STEPTYPE(&((p)->LC_VD_S3),RF); \
  LC_WINIT_DataType__STEPTYPE(&((p)->LC_VD_S4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T6),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T7),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_T8),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESEQUENCEx2EFB_LC_SEQUENCE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /*TRANSITION evaluation T0 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S1,LC_this->LC_VD_T0);
  /*TRANSITION evaluation T5 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S0,LC_this->LC_VD_T5);
  /*TRANSITION evaluation T1 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S2,LC_this->LC_VD_T1);
  /*TRANSITION evaluation T6 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S0,LC_this->LC_VD_T6);
  /*TRANSITION evaluation T2 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S3,LC_this->LC_VD_T2);
  /*TRANSITION evaluation T7 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S0,LC_this->LC_VD_T7);
  /*TRANSITION evaluation T3 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S4,LC_this->LC_VD_T3);
  /*TRANSITION evaluation T8 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S0,LC_this->LC_VD_T8);
  /*TRANSITION evaluation T4 */
  LC_MS_SFC_STEP_ACTIVATION(LC_this->LC_VD_S1,LC_this->LC_VD_T4);

  /*STEP time evaluation */
  LC_MS_SFC_STEP_TIME_CALCULATION(LC_this->LC_VD_S0);
  LC_MS_SFC_STEP_TIME_CALCULATION(LC_this->LC_VD_S1);
  LC_MS_SFC_STEP_TIME_CALCULATION(LC_this->LC_VD_S2);
  LC_MS_SFC_STEP_TIME_CALCULATION(LC_this->LC_VD_S3);
  LC_MS_SFC_STEP_TIME_CALCULATION(LC_this->LC_VD_S4);

  /*STEP S0 */
  /*STEP S1 */
  /*STEP S2 */
  /*STEP S3 */
  /*STEP S4 */
  /* Network 1 */
  {
    /*TRANSITION T0 */
    /*TRANSITION T5 */
    /*TRANSITION T1 */
    /*TRANSITION T6 */
    /*TRANSITION T2 */
    /*TRANSITION T7 */
    /*TRANSITION T3 */
    /*TRANSITION T8 */
    /*TRANSITION T4 */
    LC_this->LC_VD_VOX_STEP0 = LC_this->LC_VD_S0.LC_VD_X;
    LC_this->LC_VD_VOX_STEP1 = LC_this->LC_VD_S1.LC_VD_X;
    LC_this->LC_VD_VOX_STEP2 = LC_this->LC_VD_S2.LC_VD_X;
    LC_this->LC_VD_VOX_STEP3 = LC_this->LC_VD_S3.LC_VD_X;
    LC_this->LC_VD_VOX_STEP4 = LC_this->LC_VD_S4.LC_VD_X;
    {
      LC_this->LC_VD_TON.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON.LC_VD_IN = LC_this->LC_VD_S0.LC_VD_X;
      LC_this->LC_VD_TON.LC_VD_PT = LC_TIME_VALUE(RT_CC_CONST_LL(3600),RT_CC_CONST_LL(0));
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON), pEPDB);
      LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOTARR_STEPTIME,(LC_TD_USINT)0,(LC_TD_DINT)0,(LC_TD_DINT)4) = LC_this->LC_VD_TON.LC_VD_ET;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_VIX_RESET, pEPDB);
      LC_this->LC_VD___26_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_VIX_START, LC_this->LC_VD___26_NOT, pEPDB);
      LC_this->LC_VD___27_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_R_TRIG1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG1.LC_VD_CLK = LC_this->LC_VD___27_AND;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG1), pEPDB);
    }
    {
      LC_this->LC_VD_TON1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON1.LC_VD_IN = LC_this->LC_VD_S1.LC_VD_X;
      LC_this->LC_VD_TON1.LC_VD_PT = LC_this->LC_VD_VIT_SEQTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON1), pEPDB);
      LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOTARR_STEPTIME,(LC_TD_USINT)1,(LC_TD_DINT)0,(LC_TD_DINT)4) = LC_this->LC_VD_TON1.LC_VD_ET;
    }
    {
      LC_this->LC_VD_TON2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON2.LC_VD_IN = LC_this->LC_VD_S2.LC_VD_X;
      LC_this->LC_VD_TON2.LC_VD_PT = LC_this->LC_VD_VIT_SEQTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON2), pEPDB);
      LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOTARR_STEPTIME,(LC_TD_USINT)2,(LC_TD_DINT)0,(LC_TD_DINT)4) = LC_this->LC_VD_TON2.LC_VD_ET;
    }
    {
      LC_this->LC_VD_TON3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON3.LC_VD_IN = LC_this->LC_VD_S3.LC_VD_X;
      LC_this->LC_VD_TON3.LC_VD_PT = LC_this->LC_VD_VIT_SEQTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON3), pEPDB);
      LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOTARR_STEPTIME,(LC_TD_USINT)3,(LC_TD_DINT)0,(LC_TD_DINT)4) = LC_this->LC_VD_TON3.LC_VD_ET;
    }
    {
      LC_this->LC_VD_TON4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON4.LC_VD_IN = LC_this->LC_VD_S4.LC_VD_X;
      LC_this->LC_VD_TON4.LC_VD_PT = LC_this->LC_VD_VIT_SEQTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON4), pEPDB);
      LC_SUBSCRIPT_ARRAY(LC_this->LC_VD_VOTARR_STEPTIME,(LC_TD_USINT)4,(LC_TD_DINT)0,(LC_TD_DINT)4) = LC_this->LC_VD_TON4.LC_VD_ET;
    }
  }

  /*TRANSITION calculation T0 */
  if (LC_this->LC_VD_S0.LC_VD_X)
    LC_this->LC_VD_T0 = LC_this->LC_VD_R_TRIG1.LC_VD_Q;
  else
    {
      LC_this->LC_VD_T0 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S0,LC_this->LC_VD_T0);

  /*TRANSITION calculation T5 */
  if (LC_this->LC_VD_S1.LC_VD_X)
    LC_this->LC_VD_T5 = LC_this->LC_VD_VIX_RESET;
  else
    {
      LC_this->LC_VD_T5 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S1,LC_this->LC_VD_T5);

  /*TRANSITION calculation T1 */
  if (LC_this->LC_VD_S1.LC_VD_X)
    LC_this->LC_VD_T1 = LC_this->LC_VD_TON1.LC_VD_Q;
  else
    {
      LC_this->LC_VD_T1 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S1,LC_this->LC_VD_T1);

  /*TRANSITION calculation T6 */
  if (LC_this->LC_VD_S2.LC_VD_X)
    LC_this->LC_VD_T6 = LC_this->LC_VD_VIX_RESET;
  else
    {
      LC_this->LC_VD_T6 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S2,LC_this->LC_VD_T6);

  /*TRANSITION calculation T2 */
  if (LC_this->LC_VD_S2.LC_VD_X)
    LC_this->LC_VD_T2 = LC_this->LC_VD_TON2.LC_VD_Q;
  else
    {
      LC_this->LC_VD_T2 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S2,LC_this->LC_VD_T2);

  /*TRANSITION calculation T7 */
  if (LC_this->LC_VD_S3.LC_VD_X)
    LC_this->LC_VD_T7 = LC_this->LC_VD_VIX_RESET;
  else
    {
      LC_this->LC_VD_T7 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S3,LC_this->LC_VD_T7);

  /*TRANSITION calculation T3 */
  if (LC_this->LC_VD_S3.LC_VD_X)
    LC_this->LC_VD_T3 = LC_this->LC_VD_TON3.LC_VD_Q;
  else
    {
      LC_this->LC_VD_T3 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S3,LC_this->LC_VD_T3);

  /*TRANSITION calculation T8 */
  if (LC_this->LC_VD_S4.LC_VD_X)
    LC_this->LC_VD_T8 = LC_this->LC_VD_VIX_RESET;
  else
    {
      LC_this->LC_VD_T8 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S4,LC_this->LC_VD_T8);

  /*TRANSITION calculation T4 */
  if (LC_this->LC_VD_S4.LC_VD_X)
    LC_this->LC_VD_T4 = LC_this->LC_VD_TON4.LC_VD_Q;
  else
    {
      LC_this->LC_VD_T4 = 0;
    }
  LC_MS_SFC_STEP_DEACTIVATION(LC_this->LC_VD_S4,LC_this->LC_VD_T4);
}

#endif
