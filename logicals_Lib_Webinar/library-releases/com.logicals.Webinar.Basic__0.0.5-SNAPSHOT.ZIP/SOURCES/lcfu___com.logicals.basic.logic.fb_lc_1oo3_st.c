#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO3_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO3_ST__C

#include <lcfu___com.logicals.basic.logic.fb_lc_1oo3_st.h>
#include <lcfu_iec61131__NOT.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO3_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO3_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_AND__BOOL lFunction_AND;
    LC_INIT_Function_AND__BOOL(&lFunction_AND);
    lFunction_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD_VIX_IN1, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
    LC_this->LC_VD_LX_VAR_AND1 = lFunction_AND.LC_VD_AND;
  }
  {
    LC_TD_Function_AND__BOOL lFunction_AND;
    LC_INIT_Function_AND__BOOL(&lFunction_AND);
    lFunction_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), LC_this->LC_VD_VIX_IN2, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
    LC_this->LC_VD_LX_VAR_AND2 = lFunction_AND.LC_VD_AND;
  }
  {
    LC_TD_Function_AND__BOOL lFunction_AND;
    LC_INIT_Function_AND__BOOL(&lFunction_AND);
    lFunction_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), LC_this->LC_VD_VIX_IN3, pEPDB);
    LC_this->LC_VD_LX_VAR_AND3 = lFunction_AND.LC_VD_AND;
  }
  {
    LC_TD_Function_OR__BOOL lFunction_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_OR);
    lFunction_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD_LX_VAR_AND1, LC_this->LC_VD_LX_VAR_AND2, LC_this->LC_VD_LX_VAR_AND3, pEPDB);
    LC_this->LC_VD_VOX_OUT = lFunction_OR.LC_VD_OR;
  }
}

#endif
