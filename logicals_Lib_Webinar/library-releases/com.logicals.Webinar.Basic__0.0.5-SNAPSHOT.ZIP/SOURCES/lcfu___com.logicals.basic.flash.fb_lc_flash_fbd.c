#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD__C

#include <lcfu___com.logicals.basic.flash.fb_lc_flash_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_START)); \
  (p)->LC_VD_ONTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_OFFTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_INIT_BOOL(&((p)->LC_VD_OUT)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_OUT)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON2)); \
  (p)->LC_VD_LX_TOOUT = LC_EL_true; \
  LC_INIT_BOOL(&((p)->LC_VD___9_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___8_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___7_ENO)); \
  LC_INIT_BOOL(&((p)->LC_VD___7_MOVE)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_START),RF); \
  if (RF==0) (p)->LC_VD_ONTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_OFFTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_WINIT_BOOL(&((p)->LC_VD_OUT),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_OUT),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON2),0); \
  if (RF==0) (p)->LC_VD_LX_TOOUT = LC_EL_true; \
  LC_WINIT_BOOL(&((p)->LC_VD___9_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___8_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___7_ENO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___7_MOVE),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_TON2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON2.LC_VD_IN = LC_this->LC_VD_TON1.LC_VD_Q;
      LC_this->LC_VD_TON2.LC_VD_PT = LC_this->LC_VD_OFFTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON2), pEPDB);
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_TON2.LC_VD_Q, pEPDB);
      LC_this->LC_VD___9_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_START, LC_this->LC_VD___9_NOT, pEPDB);
      LC_this->LC_VD___8_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON1.LC_VD_IN = LC_this->LC_VD___8_AND;
      LC_this->LC_VD_TON1.LC_VD_PT = LC_this->LC_VD_ONTIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON1), pEPDB);
      LC_this->LC_VD_LX_OUT = LC_this->LC_VD_TON1.LC_VD_Q;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_MOVE__BOOL lFunction_MOVE;
      LC_INIT_Function_MOVE__BOOL(&lFunction_MOVE);
      if ((lFunction_MOVE.LC_VD_ENO = LC_this->LC_VD_LX_TOOUT) != LC_EL_false)
      {
        lcfu_iec61131__MOVE__BOOL(&lFunction_MOVE, LC_this->LC_VD_LX_OUT, pEPDB);
        LC_this->LC_VD___7_ENO = lFunction_MOVE.LC_VD_ENO;
        LC_this->LC_VD_OUT = lFunction_MOVE.LC_VD_MOVE;
        LC_this->LC_VD___7_MOVE = lFunction_MOVE.LC_VD_MOVE;
      }
      else
      {
        LC_INIT_BOOL(&(LC_this->LC_VD___7_ENO));
        LC_INIT_BOOL(&(LC_this->LC_VD___7_MOVE));
      }
    }
  }
}

#endif
