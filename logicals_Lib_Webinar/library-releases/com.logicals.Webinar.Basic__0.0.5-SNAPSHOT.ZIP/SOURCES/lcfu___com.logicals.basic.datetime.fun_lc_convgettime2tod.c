#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVGETTIME2TOD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVGETTIME2TOD__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_convgettime2tod.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVGETTIME2TOD(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVGETTIME2TOD* LC_this, LC_TD_DataType_COMx2ELOGICALSx2EBASICx2EOPHOURx2EDT_LC_OPHOURGETTIME LC_VD_VISTRUC_IN, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_TO_UDINT lFunction_TO_TOD__IN__leftOp__leftOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_TOD__IN__leftOp__rightOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_UDINT lFunction_TO_TOD__IN__rightOp__leftOp_TO_UDINT;
    LC_TD_Function_TO_TOD lFunction_TO_TOD;
    LC_INIT_Function_TO_UDINT(&lFunction_TO_TOD__IN__leftOp__leftOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_TOD__IN__leftOp__rightOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_UDINT(&lFunction_TO_TOD__IN__rightOp__leftOp_TO_UDINT);
    LC_INIT_Function_TO_TOD(&lFunction_TO_TOD);
    lFunction_TO_TOD__IN__leftOp__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__DINT(&lFunction_TO_TOD__IN__leftOp__leftOp__leftOp_TO_UDINT, LC_VD_VISTRUC_IN.LC_VD_DI_HOUR, pEPDB);
    lFunction_TO_TOD__IN__leftOp__rightOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__DINT(&lFunction_TO_TOD__IN__leftOp__rightOp__leftOp_TO_UDINT, LC_VD_VISTRUC_IN.LC_VD_DI_MIN, pEPDB);
    lFunction_TO_TOD__IN__rightOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__DINT(&lFunction_TO_TOD__IN__rightOp__leftOp_TO_UDINT, LC_VD_VISTRUC_IN.LC_VD_DI_SEC, pEPDB);
    lFunction_TO_TOD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_TOD__UDINT(&lFunction_TO_TOD, (LC_TD_UDINT)((LC_TD_UDINT)((LC_TD_UDINT)(lFunction_TO_TOD__IN__leftOp__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)3600000UL) + (LC_TD_UDINT)(lFunction_TO_TOD__IN__leftOp__rightOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)60000UL)) + (LC_TD_UDINT)(lFunction_TO_TOD__IN__rightOp__leftOp_TO_UDINT.LC_VD_TO_UDINT * (LC_TD_UDINT)1000UL)), pEPDB);
    LC_this->LC_VD_FUN_LC_CONVGETTIME2TOD = lFunction_TO_TOD.LC_VD_TO_TOD;
  }
}

#endif
