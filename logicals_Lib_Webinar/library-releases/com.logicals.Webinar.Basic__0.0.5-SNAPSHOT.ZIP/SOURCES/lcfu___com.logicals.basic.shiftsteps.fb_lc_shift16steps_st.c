#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST__C

#include <lcfu___com.logicals.basic.shiftsteps.fb_lc_shift16steps_st.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESET)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_ONTIME)); \
  LC_INIT_DataType_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EDT_LC_STEPALIVESTATE(&((p)->LC_VD_VOSTRUC_STEPSTATE)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_CHGSTATER_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_INITR_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_STARTR_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RESETR_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP01)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP02)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP03)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP04)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP05)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP06)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP07)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP08)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP09)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP10)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP11)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP12)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP13)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP14)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP15)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP16)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_INITRS)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP01)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP02)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP03)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP04)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP05)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP06)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP07)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP08)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP09)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP10)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP11)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP12)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP13)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP14)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP15)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP16)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP17)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP18)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CHGSTATECTU)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_INITCTU)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTART)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTURESET)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP01)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP02)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP03)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP04)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP05)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP06)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP07)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP08)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP09)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP10)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP11)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP12)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP13)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP14)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP15)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP16)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_STARTVAR)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL01)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL02)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL03)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL04)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL05)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL06)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL07)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL08)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL09)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL10)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL11)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL12)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL13)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL14)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL15)); \
  LC_INIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL16)); \
  LC_INIT_INT(&((p)->LC_VD_LI_LI_CNTSET_INIT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_START)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_RESET)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP01)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP02)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP03)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP04)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP05)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP06)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP07)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP08)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP09)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP10)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP11)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP12)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP13)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP14)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP15)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP16)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALINIT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTART)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALRESET)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP01)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP02)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP03)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP04)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP05)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP06)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP07)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP08)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP09)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP10)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP11)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP12)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP13)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP14)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP15)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP16)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_EVERTRUE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_EVERFALSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CHGSTATE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CHGSTATEPULSE)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CNTVAL_INIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
  LC_INIT_UINT(&((p)->LC_VD_LUI_CYCLECOUNT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESET),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_ONTIME),RF); \
  LC_WINIT_DataType_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EDT_LC_STEPALIVESTATE(&((p)->LC_VD_VOSTRUC_STEPSTATE),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_CHGSTATER_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_INITR_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_STARTR_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RESETR_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP01),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP02),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP03),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP04),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP05),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP06),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP07),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP08),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP09),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP10),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP11),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP12),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP13),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP14),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP15),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS_STEP16),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_INITRS),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP01),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP02),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP03),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP04),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP05),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP06),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP07),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP08),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP09),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP10),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP11),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP12),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP13),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP14),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP15),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP16),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP17),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON_STEP18),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CHGSTATECTU),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_INITCTU),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTART),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTURESET),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP01),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP02),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP03),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP04),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP05),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP06),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP07),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP08),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP09),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP10),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP11),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP12),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP13),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP14),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP15),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_CTUSTEP16),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_STARTVAR),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL01),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL02),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL03),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL04),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL05),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL06),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL07),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL08),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL09),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL10),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL11),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL12),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL13),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL14),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL15),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_LT_TIMEACTVAL16),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_LI_CNTSET_INIT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_START),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_RESET),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP01),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP02),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP03),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP04),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP05),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP06),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP07),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP08),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP09),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP10),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP11),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP12),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP13),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP14),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP15),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_STEP16),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALINIT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTART),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALRESET),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP01),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP02),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP03),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP04),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP05),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP06),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP07),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP08),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP09),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP10),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP11),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP12),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP13),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP14),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP15),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTSETVALSTEP16),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_EVERTRUE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_EVERFALSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CHGSTATE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CHGSTATEPULSE),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CNTVAL_INIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_LUI_CYCLECOUNT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESHIFTSTEPSx2EFB_LC_SHIFT16STEPS_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LUI_CYCLECOUNT = (LC_TD_UINT)(LC_this->LC_VD_LUI_CYCLECOUNT + (LC_TD_UINT)1);
  {
    LC_this->LC_VD_INITR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_INITR_TRIG.LC_VD_CLK = LC_this->LC_VD_LX_EVERTRUE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_INITR_TRIG), pEPDB);
    LC_this->LC_VD_LX_CYCLEINIT = LC_this->LC_VD_INITR_TRIG.LC_VD_Q;
  }
  {
    LC_this->LC_VD_INITRS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_INITRS.LC_VD_S = LC_this->LC_VD_LX_CYCLEINIT;
    LC_this->LC_VD_INITRS.LC_VD_R1 = LC_this->LC_VD_VIX_RESET;
    lcfu_iec61131__RS(&(LC_this->LC_VD_INITRS), pEPDB);
  }
  {
    LC_TD_Function_OR__BOOL lFunction_INITCTU__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_INITCTU__R_OR);
    lFunction_INITCTU__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_INITCTU__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_INITCTU.LC_VD_Q, pEPDB);
    LC_this->LC_VD_INITCTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_INITCTU.LC_VD_CU = LC_this->LC_VD_LX_CYCLEINIT;
    LC_this->LC_VD_INITCTU.LC_VD_R = lFunction_INITCTU__R_OR.LC_VD_OR;
    LC_this->LC_VD_INITCTU.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALINIT;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_INITCTU), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_INIT = LC_this->LC_VD_INITCTU.LC_VD_CV;
  LC_this->LC_VD_LX_EVERTRUE = LC_EL_true;
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_CYCLEINIT == LC_EL_true))
  {
    LC_this->LC_VD_LI_CNTSETVALINIT = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTART = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALRESET = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP01 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP02 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP03 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP04 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP05 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP06 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP07 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP08 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP09 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP10 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP11 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP12 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP13 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP14 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP15 = (LC_TD_INT)100;
    LC_this->LC_VD_LI_CNTSETVALSTEP16 = (LC_TD_INT)100;
  }
  {
    LC_this->LC_VD_STARTR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_STARTR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_START;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_STARTR_TRIG), pEPDB);
    LC_this->LC_VD_LX_STARTVAR = LC_this->LC_VD_STARTR_TRIG.LC_VD_Q;
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CTUSTART__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CTUSTART__R_OR);
    lFunction_CTUSTART__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CTUSTART__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CTUSTART.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CTUSTART.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTART.LC_VD_CU = LC_this->LC_VD_STARTR_TRIG.LC_VD_Q;
    LC_this->LC_VD_CTUSTART.LC_VD_R = lFunction_CTUSTART__R_OR.LC_VD_OR;
    LC_this->LC_VD_CTUSTART.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTART;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTART), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_START = LC_this->LC_VD_CTUSTART.LC_VD_CV;
  {
    LC_this->LC_VD_RESETR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RESETR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_RESET;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RESETR_TRIG), pEPDB);
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CTURESET__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CTURESET__R_OR);
    lFunction_CTURESET__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CTURESET__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CTURESET.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CTURESET.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTURESET.LC_VD_CU = LC_this->LC_VD_RESETR_TRIG.LC_VD_Q;
    LC_this->LC_VD_CTURESET.LC_VD_R = lFunction_CTURESET__R_OR.LC_VD_OR;
    LC_this->LC_VD_CTURESET.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALRESET;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTURESET), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_RESET = LC_this->LC_VD_CTURESET.LC_VD_CV;
  if (LC_this->LC_VD_LX_CHGSTATEPULSE)
  {
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT16.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)16;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT15.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)15;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT14.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)14;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT13.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)13;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT12.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)12;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT11.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)11;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT10.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)10;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT09.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)9;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT08.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)8;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT07.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)7;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT06.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)6;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT05.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)5;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT04.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)4;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT03.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)3;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT02.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)2;
    }
    if ((LC_TD_BOOL)(LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT01.LC_VD_OUT == LC_EL_true))
    {
      LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_ACTSTATENO = (LC_TD_USINT)1;
    }
  }
  LC_this->LC_VD_LX_CHGSTATE = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_TON_STEP16.LC_VD_Q,LC_this->LC_VD_TON_STEP15.LC_VD_Q)),LC_this->LC_VD_TON_STEP14.LC_VD_Q)),LC_this->LC_VD_TON_STEP13.LC_VD_Q)),LC_this->LC_VD_TON_STEP12.LC_VD_Q)),LC_this->LC_VD_TON_STEP11.LC_VD_Q)),LC_this->LC_VD_TON_STEP10.LC_VD_Q)),LC_this->LC_VD_TON_STEP09.LC_VD_Q)),LC_this->LC_VD_TON_STEP08.LC_VD_Q)),LC_this->LC_VD_TON_STEP07.LC_VD_Q)),LC_this->LC_VD_TON_STEP06.LC_VD_Q)),LC_this->LC_VD_TON_STEP05.LC_VD_Q)),LC_this->LC_VD_TON_STEP04.LC_VD_Q)),LC_this->LC_VD_TON_STEP03.LC_VD_Q)),LC_this->LC_VD_TON_STEP02.LC_VD_Q)),LC_this->LC_VD_TON_STEP01.LC_VD_Q)),LC_this->LC_VD_LX_CYCLEINIT));
  {
    LC_this->LC_VD_CHGSTATER_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CHGSTATER_TRIG.LC_VD_CLK = LC_this->LC_VD_LX_CHGSTATE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_CHGSTATER_TRIG), pEPDB);
    LC_this->LC_VD_LX_CHGSTATEPULSE = LC_this->LC_VD_CHGSTATER_TRIG.LC_VD_Q;
  }
  {
    LC_TD_Function_OR__BOOL lFunction_CHGSTATECTU__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_CHGSTATECTU__R_OR);
    lFunction_CHGSTATECTU__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_CHGSTATECTU__R_OR, LC_this->LC_VD_VIX_RESET, LC_this->LC_VD_CHGSTATECTU.LC_VD_Q, pEPDB);
    LC_this->LC_VD_CHGSTATECTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CHGSTATECTU.LC_VD_CU = LC_this->LC_VD_LX_CHGSTATEPULSE;
    LC_this->LC_VD_CHGSTATECTU.LC_VD_R = lFunction_CHGSTATECTU__R_OR.LC_VD_OR;
    LC_this->LC_VD_CHGSTATECTU.LC_VD_PV = (LC_TD_INT)16;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CHGSTATECTU), pEPDB);
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CHGSTATECTU.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_CHGSTATECNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_CHGSTATE = LC_this->LC_VD_LX_CHGSTATEPULSE;
  {
    LC_this->LC_VD_RS_STEP16.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP16.LC_VD_S = LC_this->LC_VD_TON_STEP15.LC_VD_Q;
    LC_this->LC_VD_RS_STEP16.LC_VD_R1 = LC_this->LC_VD_RS_STEP01.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP16), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT16.LC_VD_OUT = LC_this->LC_VD_RS_STEP16.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP16.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP16.LC_VD_IN = LC_this->LC_VD_RS_STEP16.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP16.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP16), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP16.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP16.LC_VD_CU = LC_this->LC_VD_RS_STEP16.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP16.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP16.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP16;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP16), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP16 = LC_this->LC_VD_CTUSTEP16.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP15.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP15.LC_VD_S = LC_this->LC_VD_TON_STEP14.LC_VD_Q;
    LC_this->LC_VD_RS_STEP15.LC_VD_R1 = LC_this->LC_VD_RS_STEP16.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP15), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT15.LC_VD_OUT = LC_this->LC_VD_RS_STEP15.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP15.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP15.LC_VD_IN = LC_this->LC_VD_RS_STEP15.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP15.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP15), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP15.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP15.LC_VD_CU = LC_this->LC_VD_RS_STEP15.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP15.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP15.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP15;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP15), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP15 = LC_this->LC_VD_CTUSTEP15.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP14.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP14.LC_VD_S = LC_this->LC_VD_TON_STEP13.LC_VD_Q;
    LC_this->LC_VD_RS_STEP14.LC_VD_R1 = LC_this->LC_VD_RS_STEP15.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP14), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT14.LC_VD_OUT = LC_this->LC_VD_RS_STEP14.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP14.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP14.LC_VD_IN = LC_this->LC_VD_RS_STEP14.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP14.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP14), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP14.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP14.LC_VD_CU = LC_this->LC_VD_RS_STEP14.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP14.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP14.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP14;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP14), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP14 = LC_this->LC_VD_CTUSTEP14.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP13.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP13.LC_VD_S = LC_this->LC_VD_TON_STEP12.LC_VD_Q;
    LC_this->LC_VD_RS_STEP13.LC_VD_R1 = LC_this->LC_VD_RS_STEP14.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP13), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT13.LC_VD_OUT = LC_this->LC_VD_RS_STEP13.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP13.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP13.LC_VD_IN = LC_this->LC_VD_RS_STEP13.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP13.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP13), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP13.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP13.LC_VD_CU = LC_this->LC_VD_RS_STEP13.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP13.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP13.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP13;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP13), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP13 = LC_this->LC_VD_CTUSTEP13.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP12.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP12.LC_VD_S = LC_this->LC_VD_TON_STEP11.LC_VD_Q;
    LC_this->LC_VD_RS_STEP12.LC_VD_R1 = LC_this->LC_VD_RS_STEP13.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP12), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT12.LC_VD_OUT = LC_this->LC_VD_RS_STEP12.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP12.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP12.LC_VD_IN = LC_this->LC_VD_RS_STEP12.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP12.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP12), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP12.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP12.LC_VD_CU = LC_this->LC_VD_RS_STEP12.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP12.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP12.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP12;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP12), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP12 = LC_this->LC_VD_CTUSTEP12.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP11.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP11.LC_VD_S = LC_this->LC_VD_TON_STEP10.LC_VD_Q;
    LC_this->LC_VD_RS_STEP11.LC_VD_R1 = LC_this->LC_VD_RS_STEP12.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP11), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT11.LC_VD_OUT = LC_this->LC_VD_RS_STEP11.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP11.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP11.LC_VD_IN = LC_this->LC_VD_RS_STEP11.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP11.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP11), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP11.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP11.LC_VD_CU = LC_this->LC_VD_RS_STEP11.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP11.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP11.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP11;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP11), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP11 = LC_this->LC_VD_CTUSTEP11.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP10.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP10.LC_VD_S = LC_this->LC_VD_TON_STEP09.LC_VD_Q;
    LC_this->LC_VD_RS_STEP10.LC_VD_R1 = LC_this->LC_VD_RS_STEP11.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP10), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT10.LC_VD_OUT = LC_this->LC_VD_RS_STEP10.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP10.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP10.LC_VD_IN = LC_this->LC_VD_RS_STEP10.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP10.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP10), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP10.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP10.LC_VD_CU = LC_this->LC_VD_RS_STEP10.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP10.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP10.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP10;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP10), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP10 = LC_this->LC_VD_CTUSTEP10.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP09.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP09.LC_VD_S = LC_this->LC_VD_TON_STEP08.LC_VD_Q;
    LC_this->LC_VD_RS_STEP09.LC_VD_R1 = LC_this->LC_VD_RS_STEP10.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP09), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT09.LC_VD_OUT = LC_this->LC_VD_RS_STEP09.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP09.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP09.LC_VD_IN = LC_this->LC_VD_RS_STEP09.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP09.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP09), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP09.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP09.LC_VD_CU = LC_this->LC_VD_RS_STEP09.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP09.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP09.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP09;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP09), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP09 = LC_this->LC_VD_CTUSTEP09.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP08.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP08.LC_VD_S = LC_this->LC_VD_TON_STEP07.LC_VD_Q;
    LC_this->LC_VD_RS_STEP08.LC_VD_R1 = LC_this->LC_VD_RS_STEP09.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP08), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT08.LC_VD_OUT = LC_this->LC_VD_RS_STEP08.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP08.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP08.LC_VD_IN = LC_this->LC_VD_RS_STEP08.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP08.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP08), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP08.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP08.LC_VD_CU = LC_this->LC_VD_RS_STEP08.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP08.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP08.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP08;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP08), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP08 = LC_this->LC_VD_CTUSTEP08.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP07.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP07.LC_VD_S = LC_this->LC_VD_TON_STEP06.LC_VD_Q;
    LC_this->LC_VD_RS_STEP07.LC_VD_R1 = LC_this->LC_VD_RS_STEP08.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP07), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT07.LC_VD_OUT = LC_this->LC_VD_RS_STEP07.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP07.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP07.LC_VD_IN = LC_this->LC_VD_RS_STEP07.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP07.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP07), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP07.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP07.LC_VD_CU = LC_this->LC_VD_RS_STEP07.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP07.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP07.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP07;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP07), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP07 = LC_this->LC_VD_CTUSTEP07.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP06.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP06.LC_VD_S = LC_this->LC_VD_TON_STEP05.LC_VD_Q;
    LC_this->LC_VD_RS_STEP06.LC_VD_R1 = LC_this->LC_VD_RS_STEP07.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP06), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT06.LC_VD_OUT = LC_this->LC_VD_RS_STEP06.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP06.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP06.LC_VD_IN = LC_this->LC_VD_RS_STEP06.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP06.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP06), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP06.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP06.LC_VD_CU = LC_this->LC_VD_RS_STEP06.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP06.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP06.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP06;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP06), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP06 = LC_this->LC_VD_CTUSTEP06.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP05.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP05.LC_VD_S = LC_this->LC_VD_TON_STEP04.LC_VD_Q;
    LC_this->LC_VD_RS_STEP05.LC_VD_R1 = LC_this->LC_VD_RS_STEP06.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP05), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT05.LC_VD_OUT = LC_this->LC_VD_RS_STEP05.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP05.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP05.LC_VD_IN = LC_this->LC_VD_RS_STEP05.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP05.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP05), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP05.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP05.LC_VD_CU = LC_this->LC_VD_RS_STEP05.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP05.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP05.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP05;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP05), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP05 = LC_this->LC_VD_CTUSTEP05.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP04.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP04.LC_VD_S = LC_this->LC_VD_TON_STEP03.LC_VD_Q;
    LC_this->LC_VD_RS_STEP04.LC_VD_R1 = LC_this->LC_VD_RS_STEP05.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP04), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT04.LC_VD_OUT = LC_this->LC_VD_RS_STEP04.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP04.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP04.LC_VD_IN = LC_this->LC_VD_RS_STEP04.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP04.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP04), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP04.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP04.LC_VD_CU = LC_this->LC_VD_RS_STEP04.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP04.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP04.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP04;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP04), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP04 = LC_this->LC_VD_CTUSTEP04.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP03.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP03.LC_VD_S = LC_this->LC_VD_TON_STEP02.LC_VD_Q;
    LC_this->LC_VD_RS_STEP03.LC_VD_R1 = LC_this->LC_VD_RS_STEP04.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP03), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT03.LC_VD_OUT = LC_this->LC_VD_RS_STEP03.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP03.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP03.LC_VD_IN = LC_this->LC_VD_RS_STEP03.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP03.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP03), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP03.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP03.LC_VD_CU = LC_this->LC_VD_RS_STEP03.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP03.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP03.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP03;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP03), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP03 = LC_this->LC_VD_CTUSTEP03.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP02.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP02.LC_VD_S = LC_this->LC_VD_TON_STEP01.LC_VD_Q;
    LC_this->LC_VD_RS_STEP02.LC_VD_R1 = LC_this->LC_VD_RS_STEP03.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP02), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT02.LC_VD_OUT = LC_this->LC_VD_RS_STEP02.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP02.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP02.LC_VD_IN = LC_this->LC_VD_RS_STEP02.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP02.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP02), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP02.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP02.LC_VD_CU = LC_this->LC_VD_RS_STEP02.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP02.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP02.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP02;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP02), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP02 = LC_this->LC_VD_CTUSTEP02.LC_VD_CV;
  {
    LC_this->LC_VD_RS_STEP01.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RS_STEP01.LC_VD_S = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_LX_STARTVAR,LC_this->LC_VD_TON_STEP16.LC_VD_Q));
    LC_this->LC_VD_RS_STEP01.LC_VD_R1 = LC_this->LC_VD_RS_STEP02.LC_VD_Q1;
    lcfu_iec61131__RS(&(LC_this->LC_VD_RS_STEP01), pEPDB);
  }
  LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT01.LC_VD_OUT = LC_this->LC_VD_RS_STEP01.LC_VD_Q1;
  {
    LC_this->LC_VD_TON_STEP01.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_TON_STEP01.LC_VD_IN = LC_this->LC_VD_RS_STEP01.LC_VD_Q1;
    LC_this->LC_VD_TON_STEP01.LC_VD_PT = LC_this->LC_VD_VIT_ONTIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_TON_STEP01), pEPDB);
  }
  {
    LC_this->LC_VD_CTUSTEP01.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_CTUSTEP01.LC_VD_CU = LC_this->LC_VD_RS_STEP01.LC_VD_Q1;
    LC_this->LC_VD_CTUSTEP01.LC_VD_R = LC_this->LC_VD_VIX_RESET;
    LC_this->LC_VD_CTUSTEP01.LC_VD_PV = LC_this->LC_VD_LI_CNTSETVALSTEP01;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_CTUSTEP01), pEPDB);
  }
  LC_this->LC_VD_LI_CNTVAL_STEP01 = LC_this->LC_VD_CTUSTEP01.LC_VD_CV;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP01.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT01.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP02.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT02.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP03.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT03.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP04.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT04.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP05.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT05.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP06.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT06.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP07.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT07.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP08.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT08.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP09.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT09.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP10.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT10.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP11.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT11.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP12.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT12.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP13.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT13.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP14.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT14.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP15.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT15.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_CTUSTEP16.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT16.LC_VD_ACTCOUNT = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL = LC_this->LC_VD_TON_STEP01.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP01.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT01.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL01 = LC_this->LC_VD_TON_STEP02.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP02.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT02.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL02 = LC_this->LC_VD_TON_STEP03.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP03.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT03.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL03 = LC_this->LC_VD_TON_STEP04.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP04.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT04.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL04 = LC_this->LC_VD_TON_STEP05.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP05.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT05.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL05 = LC_this->LC_VD_TON_STEP06.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP06.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT06.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL06 = LC_this->LC_VD_TON_STEP07.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP07.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT07.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL07 = LC_this->LC_VD_TON_STEP08.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP08.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT08.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL08 = LC_this->LC_VD_TON_STEP09.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP09.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT09.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL09 = LC_this->LC_VD_TON_STEP10.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP10.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT10.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL10 = LC_this->LC_VD_TON_STEP11.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP11.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT11.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL11 = LC_this->LC_VD_TON_STEP12.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP12.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT12.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL12 = LC_this->LC_VD_TON_STEP13.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP14.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT13.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL13 = LC_this->LC_VD_TON_STEP14.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP15.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT15.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL14 = LC_this->LC_VD_TON_STEP15.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP16.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT16.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  LC_this->LC_VD_LT_TIMEACTVAL15 = LC_this->LC_VD_TON_STEP16.LC_VD_ET;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__TIME(&lFunction_TO_UINT, LC_this->LC_VD_TON_STEP17.LC_VD_ET, pEPDB);
    LC_this->LC_VD_VOSTRUC_STEPSTATE.LC_VD_OUT17.LC_VD_ACTTIME = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
}

#endif
