#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST__C

#include <lcfu___com.logicals.opaut.control.fb_opaut_typ_d_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_Y_D = (LC_TD_REAL)(LC_this->LC_VD_TV_T0 * (LC_TD_REAL)(LC_this->LC_VD_E - LC_this->LC_VD_E_ALT));
  LC_this->LC_VD_E_ALT = LC_this->LC_VD_E;
}

#endif
