#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST__C

#include <lcfu___com.logicals.basic.logic.fb_lc_logicmode_1oo6_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_MODESET5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESETMODE)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MODEOUT5)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(&((p)->LC_VD_FB_1OO6_ST)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_1OO6_ERR)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE0)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE1)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE2)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE3)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE4)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODE5)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MODERESET)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE0_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE1_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE2_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE3_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE4_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE5_R_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODERESETON_R_TRIG)); \
  LC_INIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FB_MODERESETOFF_F_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE0_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE1_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE2_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE3_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE4_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE5_RS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODERESET_RS)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_MODESET5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESETMODE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MODEOUT5),RF); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(&((p)->LC_VD_FB_1OO6_ST),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_1OO6_ERR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODE5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MODERESET),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE0_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE1_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE2_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE3_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE4_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODE5_R_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_MODERESETON_R_TRIG),0); \
  LC_WINIT_FunctionBlock_F_TRIG(&((p)->LC_VD_FB_MODERESETOFF_F_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE0_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE1_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE2_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE3_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE4_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODE5_RS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MODERESET_RS),0); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_LOGICMODE_1OO6_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN1 = LC_this->LC_VD_VIX_MODESET0;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN2 = LC_this->LC_VD_VIX_MODESET1;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN3 = LC_this->LC_VD_VIX_MODESET2;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN4 = LC_this->LC_VD_VIX_MODESET3;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN5 = LC_this->LC_VD_VIX_MODESET4;
    LC_this->LC_VD_FB_1OO6_ST.LC_VD_VIX_IN6 = LC_this->LC_VD_VIX_MODESET5;
    lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO6_ST(&(LC_this->LC_VD_FB_1OO6_ST), pEPDB);
    LC_this->LC_VD_LX_MODE0 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT1;
    LC_this->LC_VD_LX_MODE1 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT2;
    LC_this->LC_VD_LX_MODE2 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT3;
    LC_this->LC_VD_LX_MODE3 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT4;
    LC_this->LC_VD_LX_MODE4 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT5;
    LC_this->LC_VD_LX_MODE5 = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_OUT6;
    LC_this->LC_VD_LX_1OO6_ERR = LC_this->LC_VD_FB_1OO6_ST.LC_VD_VOX_ERR;
  }
  {
    LC_this->LC_VD_FB_MODE0_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE0_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE0,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE0_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE1_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE1_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE1,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE1_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE2_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE2_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE2,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE2_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE3_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE3_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE3,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE3_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE4_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE4_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE4,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE4_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE5_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE5_R_TRIG.LC_VD_CLK = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MODE5,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_LX_MODERESET))));
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODE5_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODE0_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE0_RS.LC_VD_S = LC_this->LC_VD_FB_MODE0_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE0_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE0_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT0 = LC_this->LC_VD_FB_MODE0_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODE1_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE1_RS.LC_VD_S = LC_this->LC_VD_FB_MODE1_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE1_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE1_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT1 = LC_this->LC_VD_FB_MODE1_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODE2_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE2_RS.LC_VD_S = LC_this->LC_VD_FB_MODE2_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE2_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE2_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT2 = LC_this->LC_VD_FB_MODE2_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODE3_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE3_RS.LC_VD_S = LC_this->LC_VD_FB_MODE3_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE3_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE3_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT3 = LC_this->LC_VD_FB_MODE3_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODE4_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE4_RS.LC_VD_S = LC_this->LC_VD_FB_MODE4_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE4_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE4_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT4 = LC_this->LC_VD_FB_MODE4_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODE5_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODE5_RS.LC_VD_S = LC_this->LC_VD_FB_MODE5_R_TRIG.LC_VD_Q;
    LC_this->LC_VD_FB_MODE5_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODE5_RS), pEPDB);
    LC_this->LC_VD_VOX_MODEOUT5 = LC_this->LC_VD_FB_MODE5_RS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_FB_MODERESETON_R_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODERESETON_R_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_RESETMODE;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_MODERESETON_R_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODERESETOFF_F_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_RESETMODE;
    lcfu_iec61131__F_TRIG(&(LC_this->LC_VD_FB_MODERESETOFF_F_TRIG), pEPDB);
  }
  {
    LC_this->LC_VD_FB_MODERESET_RS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MODERESET_RS.LC_VD_S = (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_LX_MODE0,LC_this->LC_VD_LX_MODE1)),LC_this->LC_VD_LX_MODE2)),LC_this->LC_VD_LX_MODE3)),LC_this->LC_VD_LX_MODE4)),LC_this->LC_VD_LX_MODE5));
    LC_this->LC_VD_FB_MODERESET_RS.LC_VD_R1 = LC_this->LC_VD_FB_MODERESETON_R_TRIG.LC_VD_Q;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MODERESET_RS), pEPDB);
    LC_this->LC_VD_LX_MODERESET = LC_this->LC_VD_FB_MODERESET_RS.LC_VD_Q1;
  }
}

#endif
