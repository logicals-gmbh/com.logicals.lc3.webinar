#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST__C

#include <lcfu___com.logicals.basic.actuator_sim.fb_lc_motor2r_fb_sim_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_LEFTTON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_LEFTTON.LC_VD_IN = LC_this->LC_VD_VIX_LEFT;
    LC_this->LC_VD_FB_LEFTTON.LC_VD_PT = LC_this->LC_VD_VIT_LEFTDELAY;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_LEFTTON), pEPDB);
    LC_this->LC_VD_VOX_LEFTFB = LC_this->LC_VD_FB_LEFTTON.LC_VD_Q;
  }
  {
    LC_this->LC_VD_FB_RIGHTTON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_RIGHTTON.LC_VD_IN = LC_this->LC_VD_VIX_RIGHT;
    LC_this->LC_VD_FB_RIGHTTON.LC_VD_PT = LC_this->LC_VD_VIT_RIGHTDELAY;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_RIGHTTON), pEPDB);
    LC_this->LC_VD_VOX_RIGHTFB = LC_this->LC_VD_FB_RIGHTTON.LC_VD_Q;
  }
}

#endif
