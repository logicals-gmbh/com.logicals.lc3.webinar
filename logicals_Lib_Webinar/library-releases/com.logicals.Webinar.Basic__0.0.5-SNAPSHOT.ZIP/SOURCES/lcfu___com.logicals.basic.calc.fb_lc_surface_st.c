#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST__C

#include <lcfu___com.logicals.basic.calc.fb_lc_surface_st.h>
#include <lcfu_iec61131__DIV.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_INITR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_INITR_TRIG.LC_VD_CLK = LC_EL_true;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_INITR_TRIG), pEPDB);
    LC_this->LC_VD_LX_CYCLEINIT = LC_this->LC_VD_FB_INITR_TRIG.LC_VD_Q;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_CYCLEINIT == LC_EL_true))
  {
    LC_this->LC_VD_LI_CYCLECOUNTINITVAL = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNTINITVAL + (LC_TD_INT)1);
    LC_this->LC_VD_LR_PI = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)22,(LC_TD_REAL)7));
  }
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LI_CYCLECOUNT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNT + (LC_TD_INT)1);
  {
    LC_TD_Function_EXPT__REAL lFunction__leftOp__rightOp_EXPT;
    LC_INIT_Function_EXPT__REAL(&lFunction__leftOp__rightOp_EXPT);
    lFunction__leftOp__rightOp_EXPT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__EXPT__REAL(&lFunction__leftOp__rightOp_EXPT, LC_this->LC_VD_VIR_DIAMETER, (LC_TD_REAL)2, pEPDB);
    LC_this->LC_VD_VOR_SURFACE = (lcfu_iec61131__DIV__REAL__INL((LC_TD_REAL)(LC_this->LC_VD_LR_PI * lFunction__leftOp__rightOp_EXPT.LC_VD_EXPT),(LC_TD_REAL)4));
  }
}

#endif
