#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD__C

#include <lcfu___com.logicals.basic.convert.fb_lc_timetodays_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD* p = LC_this; \
  LC_INIT_TIME(&((p)->LC_VD_VIT_IN)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_DAY)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_HOUR)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_MIN)); \
  LC_INIT_DINT(&((p)->LC_VD_VODI_SEC)); \
  LC_INIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A)); \
  LC_INIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F)); \
  LC_INIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6)); \
  LC_INIT_DINT(&((p)->LC_VD___104_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___106_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___108_SUB)); \
  LC_INIT_DINT(&((p)->LC_VD___112_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___113_MUL)); \
  LC_INIT_DINT(&((p)->LC_VD___115_MUL)); \
  LC_INIT_DINT(&((p)->LC_VD___116_SUB)); \
  LC_INIT_DINT(&((p)->LC_VD___117_TO_DINT)); \
  LC_INIT_DINT(&((p)->LC_VD___120_MUL)); \
  LC_INIT_DINT(&((p)->LC_VD___121_SUB)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD* p = LC_this; \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_IN),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_DAY),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_HOUR),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_MIN),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VODI_SEC),RF); \
  LC_WINIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F),0); \
  LC_WINIT_FunctionBlock_FORCEMRK__DINT(&((p)->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6),0); \
  LC_WINIT_DINT(&((p)->LC_VD___104_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___106_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___108_SUB),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___112_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___113_MUL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___115_MUL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___116_SUB),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___117_TO_DINT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___120_MUL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___121_SUB),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_TIMETODAYS_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_TO_DINT lFunction_TO_DINT;
      LC_INIT_Function_TO_DINT(&lFunction_TO_DINT);
      lFunction_TO_DINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_DINT__TIME(&lFunction_TO_DINT, LC_this->LC_VD_VIT_IN, pEPDB);
      LC_this->LC_VD___117_TO_DINT = lFunction_TO_DINT.LC_VD_TO_DINT;
    }
    {
      LC_this->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A.LC_VD_IN = LC_this->LC_VD___117_TO_DINT;
      lcfu_iec61131__FORCEMRK__DINT(&(LC_this->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A), pEPDB);
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A.LC_VD_OUT, (LC_TD_DINT)86400L, pEPDB);
      LC_this->LC_VD_VODI_DAY = lFunction_DIV.LC_VD_DIV;
      LC_this->LC_VD___112_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__DINT lFunction_MUL;
      LC_INIT_Function_MUL__DINT(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___112_DIV, (LC_TD_DINT)86400L, pEPDB);
      LC_this->LC_VD___120_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SUB__DINT lFunction_SUB;
      LC_INIT_Function_SUB__DINT(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_UUID_D0B4593F_A5CB_4A31_89F5_7C421E9CAC6A.LC_VD_OUT, LC_this->LC_VD___120_MUL, pEPDB);
      LC_this->LC_VD___121_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_this->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F.LC_VD_IN = LC_this->LC_VD___121_SUB;
      lcfu_iec61131__FORCEMRK__DINT(&(LC_this->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F), pEPDB);
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F.LC_VD_OUT, (LC_TD_DINT)3600L, pEPDB);
      LC_this->LC_VD_VODI_HOUR = lFunction_DIV.LC_VD_DIV;
      LC_this->LC_VD___106_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__DINT lFunction_MUL;
      LC_INIT_Function_MUL__DINT(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___106_DIV, (LC_TD_DINT)3600L, pEPDB);
      LC_this->LC_VD___113_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SUB__DINT lFunction_SUB;
      LC_INIT_Function_SUB__DINT(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_UUID_95358CAA_7702_4AF4_9B22_BFAB69DBF30F.LC_VD_OUT, LC_this->LC_VD___113_MUL, pEPDB);
      LC_this->LC_VD___116_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_this->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6.LC_VD_IN = LC_this->LC_VD___116_SUB;
      lcfu_iec61131__FORCEMRK__DINT(&(LC_this->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6), pEPDB);
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6.LC_VD_OUT, (LC_TD_DINT)60L, pEPDB);
      LC_this->LC_VD_VODI_MIN = lFunction_DIV.LC_VD_DIV;
      LC_this->LC_VD___104_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__DINT lFunction_MUL;
      LC_INIT_Function_MUL__DINT(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___104_DIV, (LC_TD_DINT)60L, pEPDB);
      LC_this->LC_VD___115_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SUB__DINT lFunction_SUB;
      LC_INIT_Function_SUB__DINT(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_UUID_9EDBE6A6_63EC_4267_B8F6_98045CA94CD6.LC_VD_OUT, LC_this->LC_VD___115_MUL, pEPDB);
      LC_this->LC_VD_VODI_SEC = lFunction_SUB.LC_VD_SUB;
      LC_this->LC_VD___108_SUB = lFunction_SUB.LC_VD_SUB;
    }
  }
}

#endif
