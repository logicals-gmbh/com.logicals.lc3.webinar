#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV2BYTE2INT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV2BYTE2INT_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_conv2byte2int_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV2BYTE2INT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV2BYTE2INT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_TO_WORD lFunction_TO_WORD;
    LC_INIT_Function_TO_WORD(&lFunction_TO_WORD);
    lFunction_TO_WORD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_WORD__BYTE(&lFunction_TO_WORD, LC_this->LC_VD_VIB_LBYTE, pEPDB);
    LC_this->LC_VD_LW_INLOWWRD = lFunction_TO_WORD.LC_VD_TO_WORD;
  }
  {
    LC_TD_Function_ROL__WORD lFunction_ROL;
    LC_INIT_Function_ROL__WORD(&lFunction_ROL);
    lFunction_ROL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__ROL__WORD(&lFunction_ROL, LC_this->LC_VD_VIB_HBYTE, (LC_TD_INT)8, pEPDB);
    LC_this->LC_VD_LW_INHIGHWRD = lFunction_ROL.LC_VD_ROL;
  }
  {
    LC_TD_Function_OR__WORD lFunction_OR;
    LC_INIT_Function_OR__WORD(&lFunction_OR);
    lFunction_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__ANY__2(&lFunction_OR, LC_this->LC_VD_LW_INLOWWRD, LC_this->LC_VD_LW_INHIGHWRD, pEPDB);
    LC_this->LC_VD_LW_INWRD = lFunction_OR.LC_VD_OR;
  }
  {
    LC_TD_Function_TO_INT lFunction_TO_INT;
    LC_INIT_Function_TO_INT(&lFunction_TO_INT);
    lFunction_TO_INT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_INT__WORD(&lFunction_TO_INT, LC_this->LC_VD_LW_INWRD, pEPDB);
    LC_this->LC_VD_VOI_OUT = lFunction_TO_INT.LC_VD_TO_INT;
  }
}

#endif
