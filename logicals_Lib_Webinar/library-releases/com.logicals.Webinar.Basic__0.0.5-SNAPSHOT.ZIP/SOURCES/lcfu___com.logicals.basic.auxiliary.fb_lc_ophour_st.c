#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST__C

#include <lcfu___com.logicals.basic.auxiliary.fb_lc_ophour_st.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_LDSTARTVAL)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTSEC)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTMIN)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTHOUR)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTDAY)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTMON)); \
  LC_INIT_UDINT(&((p)->LC_VD_VIUDI_STARTYEAR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESETACTVAL)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTSECALL)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTSEC)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTMIN)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTHOUR)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTDAY)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTMON)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTYEAR)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ALLSEC)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_SECPULSEEDGER_TRIG)); \
  LC_INIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_SEC_CTU)); \
  LC_INIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_MIN_CTU)); \
  LC_INIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_HOUR_CTU)); \
  (p)->LC_VD_LT_SECPULSETIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_SECTACTTON)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_SECTACT1TON)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_SECPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_SECPULSEEDGE)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_LDSTARTVAL),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTSEC),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTMIN),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTHOUR),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTDAY),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTMON),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VIUDI_STARTYEAR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESETACTVAL),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTSECALL),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTSEC),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTMIN),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTHOUR),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTDAY),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTMON),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTYEAR),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ALLSEC),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_SECPULSEEDGER_TRIG),0); \
  LC_WINIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_SEC_CTU),0); \
  LC_WINIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_MIN_CTU),0); \
  LC_WINIT_FunctionBlock_CTU_UDINT(&((p)->LC_VD_FB_HOUR_CTU),0); \
  if (RF==0) (p)->LC_VD_LT_SECPULSETIME = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_SECTACTTON),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_SECTACT1TON),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_SECPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_SECPULSEEDGE),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EAUXILIARYx2EFB_LC_OPHOUR_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOI_ERRNO = (LC_TD_INT)0;
  {
    LC_TD_Function_NOT__BOOL lFunction_FB_SECTACTTON__IN_AND__IN2_NOT;
    LC_TD_Function_AND__BOOL lFunction_FB_SECTACTTON__IN_AND;
    LC_INIT_Function_NOT__BOOL(&lFunction_FB_SECTACTTON__IN_AND__IN2_NOT);
    LC_INIT_Function_AND__BOOL(&lFunction_FB_SECTACTTON__IN_AND);
    lFunction_FB_SECTACTTON__IN_AND__IN2_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_FB_SECTACTTON__IN_AND__IN2_NOT, LC_this->LC_VD_FB_SECTACT1TON.LC_VD_Q, pEPDB);
    lFunction_FB_SECTACTTON__IN_AND.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__AND__BOOL__2(&lFunction_FB_SECTACTTON__IN_AND, LC_this->LC_VD_VIX_START, lFunction_FB_SECTACTTON__IN_AND__IN2_NOT.LC_VD_NOT, pEPDB);
    LC_this->LC_VD_FB_SECTACTTON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SECTACTTON.LC_VD_IN = lFunction_FB_SECTACTTON__IN_AND.LC_VD_AND;
    LC_this->LC_VD_FB_SECTACTTON.LC_VD_PT = LC_this->LC_VD_LT_SECPULSETIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_SECTACTTON), pEPDB);
  }
  LC_this->LC_VD_LX_SECPULSE = LC_this->LC_VD_FB_SECTACTTON.LC_VD_Q;
  {
    LC_this->LC_VD_FB_SECTACT1TON.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SECTACT1TON.LC_VD_IN = LC_this->LC_VD_FB_SECTACTTON.LC_VD_Q;
    LC_this->LC_VD_FB_SECTACT1TON.LC_VD_PT = LC_this->LC_VD_LT_SECPULSETIME;
    lcfu_iec61131__TON(&(LC_this->LC_VD_FB_SECTACT1TON), pEPDB);
  }
  {
    LC_this->LC_VD_FB_SECPULSEEDGER_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SECPULSEEDGER_TRIG.LC_VD_CLK = LC_this->LC_VD_FB_SECTACTTON.LC_VD_Q;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_SECPULSEEDGER_TRIG), pEPDB);
  }
  LC_this->LC_VD_LX_SECPULSEEDGE = LC_this->LC_VD_FB_SECPULSEEDGER_TRIG.LC_VD_Q;
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_SECPULSEEDGE == LC_EL_true))
  {
    LC_this->LC_VD_VOUDI_ALLSEC = (LC_TD_UDINT)(LC_this->LC_VD_VOUDI_ALLSEC + (LC_TD_UDINT)1UL);
  }
  {
    LC_TD_Function_OR__BOOL lFunction_FB_SEC_CTU__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_FB_SEC_CTU__R_OR);
    lFunction_FB_SEC_CTU__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_FB_SEC_CTU__R_OR, LC_this->LC_VD_FB_SEC_CTU.LC_VD_Q, LC_this->LC_VD_VIX_LDSTARTVAL, pEPDB);
    LC_this->LC_VD_FB_SEC_CTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SEC_CTU.LC_VD_CU = LC_this->LC_VD_LX_SECPULSEEDGE;
    LC_this->LC_VD_FB_SEC_CTU.LC_VD_R = lFunction_FB_SEC_CTU__R_OR.LC_VD_OR;
    LC_this->LC_VD_FB_SEC_CTU.LC_VD_PV = (LC_TD_UDINT)59UL;
    lcfu_iec61131__CTU_UDINT(&(LC_this->LC_VD_FB_SEC_CTU), pEPDB);
  }
  LC_this->LC_VD_VOUDI_ACTSEC = LC_this->LC_VD_FB_SEC_CTU.LC_VD_CV;
  {
    LC_TD_Function_OR__BOOL lFunction_FB_MIN_CTU__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_FB_MIN_CTU__R_OR);
    lFunction_FB_MIN_CTU__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_FB_MIN_CTU__R_OR, LC_this->LC_VD_FB_MIN_CTU.LC_VD_Q, LC_this->LC_VD_VIX_LDSTARTVAL, pEPDB);
    LC_this->LC_VD_FB_MIN_CTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MIN_CTU.LC_VD_CU = LC_this->LC_VD_FB_SEC_CTU.LC_VD_Q;
    LC_this->LC_VD_FB_MIN_CTU.LC_VD_R = lFunction_FB_MIN_CTU__R_OR.LC_VD_OR;
    LC_this->LC_VD_FB_MIN_CTU.LC_VD_PV = (LC_TD_UDINT)59UL;
    lcfu_iec61131__CTU_UDINT(&(LC_this->LC_VD_FB_MIN_CTU), pEPDB);
  }
  LC_this->LC_VD_VOUDI_ACTMIN = LC_this->LC_VD_FB_MIN_CTU.LC_VD_CV;
  {
    LC_TD_Function_OR__BOOL lFunction_FB_HOUR_CTU__R_OR;
    LC_INIT_Function_OR__BOOL(&lFunction_FB_HOUR_CTU__R_OR);
    lFunction_FB_HOUR_CTU__R_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_FB_HOUR_CTU__R_OR, LC_this->LC_VD_FB_HOUR_CTU.LC_VD_Q, LC_this->LC_VD_VIX_LDSTARTVAL, pEPDB);
    LC_this->LC_VD_FB_HOUR_CTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_HOUR_CTU.LC_VD_CU = LC_this->LC_VD_FB_MIN_CTU.LC_VD_Q;
    LC_this->LC_VD_FB_HOUR_CTU.LC_VD_R = lFunction_FB_HOUR_CTU__R_OR.LC_VD_OR;
    LC_this->LC_VD_FB_HOUR_CTU.LC_VD_PV = (LC_TD_UDINT)23UL;
    lcfu_iec61131__CTU_UDINT(&(LC_this->LC_VD_FB_HOUR_CTU), pEPDB);
  }
  LC_this->LC_VD_VOUDI_ACTHOUR = LC_this->LC_VD_FB_HOUR_CTU.LC_VD_CV;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_RESETACTVAL == LC_EL_true))
  {
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_LDSTARTVAL == LC_EL_true))
  {
    LC_this->LC_VD_VOUDI_ACTYEAR = LC_this->LC_VD_VIUDI_STARTYEAR;
    LC_this->LC_VD_VOUDI_ACTMON = LC_this->LC_VD_VIUDI_STARTMON;
    LC_this->LC_VD_VOUDI_ACTDAY = LC_this->LC_VD_VIUDI_STARTDAY;
    LC_this->LC_VD_VOUDI_ACTHOUR = LC_this->LC_VD_VIUDI_STARTHOUR;
    LC_this->LC_VD_VOUDI_ACTMIN = LC_this->LC_VD_VIUDI_STARTMIN;
    LC_this->LC_VD_VOUDI_ACTSEC = LC_this->LC_VD_VIUDI_STARTSEC;
    {
      LC_TD_Function_MUL__UDINT lFunction_ADD__IN2_MUL;
      LC_TD_Function_MUL__UDINT lFunction_ADD__IN3_MUL;
      LC_TD_Function_ADD__UDINT lFunction_ADD;
      LC_INIT_Function_MUL__UDINT(&lFunction_ADD__IN2_MUL);
      LC_INIT_Function_MUL__UDINT(&lFunction_ADD__IN3_MUL);
      LC_INIT_Function_ADD__UDINT(&lFunction_ADD);
      lFunction_ADD__IN2_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_ADD__IN2_MUL, LC_this->LC_VD_VOUDI_ACTMIN, (LC_TD_UDINT)60UL, pEPDB);
      lFunction_ADD__IN3_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_ADD__IN3_MUL, LC_this->LC_VD_VOUDI_ACTHOUR, (LC_TD_UDINT)3600UL, pEPDB);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__3(&lFunction_ADD, LC_this->LC_VD_VOUDI_ACTSEC, lFunction_ADD__IN2_MUL.LC_VD_MUL, lFunction_ADD__IN3_MUL.LC_VD_MUL, pEPDB);
      LC_this->LC_VD_VOUDI_ACTSECALL = lFunction_ADD.LC_VD_ADD;
    }
  }
}

#endif
