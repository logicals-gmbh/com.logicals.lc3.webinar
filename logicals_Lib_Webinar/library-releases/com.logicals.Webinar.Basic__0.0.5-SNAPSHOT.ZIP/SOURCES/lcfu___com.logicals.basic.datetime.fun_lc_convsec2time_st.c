#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVSEC2TIME_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVSEC2TIME_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_convsec2time_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVSEC2TIME_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVSEC2TIME_ST* LC_this, LC_TD_UDINT LC_VD_VIUDI_IN, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_TO_DWORD lFunction_TO_TIME__IN_TO_DWORD;
    LC_TD_Function_TO_TIME lFunction_TO_TIME;
    LC_INIT_Function_TO_DWORD(&lFunction_TO_TIME__IN_TO_DWORD);
    LC_INIT_Function_TO_TIME(&lFunction_TO_TIME);
    lFunction_TO_TIME__IN_TO_DWORD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_DWORD__UDINT(&lFunction_TO_TIME__IN_TO_DWORD, LC_VD_VIUDI_IN, pEPDB);
    lFunction_TO_TIME.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_TIME__DWORD(&lFunction_TO_TIME, lFunction_TO_TIME__IN_TO_DWORD.LC_VD_TO_DWORD, pEPDB);
    LC_this->LC_VD_FUN_LC_CONVSEC2TIME_ST = lFunction_TO_TIME.LC_VD_TO_TIME;
  }
}

#endif
