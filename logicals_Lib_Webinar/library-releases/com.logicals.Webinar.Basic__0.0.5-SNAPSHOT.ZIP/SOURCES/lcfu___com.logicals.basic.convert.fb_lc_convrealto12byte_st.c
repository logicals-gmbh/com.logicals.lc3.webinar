#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_convrealto12byte_st.h>
#include <lcfu_iec61131__AND.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST* p = LC_this; \
  (p)->LC_VD_VIR_IN = (LC_TD_REAL)0.0; \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_VALMAXERR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_VALMINERR)); \
  (p)->LC_VD_VOB_SIGN = (LC_TD_BYTE)43; \
  (p)->LC_VD_VOB_MILL = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_00THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_0THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_HUN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_TEN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_SINGLE = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DOT = (LC_TD_BYTE)46; \
  (p)->LC_VD_VOB_DSING = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DTEN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DHUND = (LC_TD_BYTE)48; \
  (p)->LC_VD_LR_VALMAX = (LC_TD_REAL)2147483.0; \
  (p)->LC_VD_LR_VALMIN = (LC_TD_REAL)-2147483.0; \
  LC_INIT_BOOL(&((p)->LC_VD_LX_GE_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_ABS_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MUL_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_TO_DINT_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV0_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV1_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD1_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD1_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD2_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV2_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD2_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD3_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV3_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD3_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD4_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV4_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD4_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD5_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV5_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD5_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD6_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV6_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD6_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD7_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV7_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD7_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD8_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_DIV8_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD8_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_MOD9_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD9_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_ADD10_OUT)); \
  (p)->LC_VD_LDI_MILL = (LC_TD_DINT)1000000000L; \
  (p)->LC_VD_LDI_00THOUS = (LC_TD_DINT)100000000L; \
  (p)->LC_VD_LDI_0THOUS = (LC_TD_DINT)10000000L; \
  (p)->LC_VD_LDI_THOUS = (LC_TD_DINT)1000000L; \
  (p)->LC_VD_LDI_HUN = (LC_TD_DINT)100000L; \
  (p)->LC_VD_LDI_TEN = (LC_TD_DINT)10000L; \
  (p)->LC_VD_LDI_DSINGLE = (LC_TD_DINT)1000L; \
  (p)->LC_VD_LDI_DSING = (LC_TD_DINT)100L; \
  (p)->LC_VD_LDI_DTEN = (LC_TD_DINT)10L; \
  (p)->LC_VD_LDI_DHUN = (LC_TD_DINT)1L; \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST* p = LC_this; \
  if (RF==0) (p)->LC_VD_VIR_IN = (LC_TD_REAL)0.0; \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_VALMAXERR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_VALMINERR),RF); \
  if (RF==0) (p)->LC_VD_VOB_SIGN = (LC_TD_BYTE)43; \
  if (RF==0) (p)->LC_VD_VOB_MILL = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_00THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_0THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_HUN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_TEN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_SINGLE = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DOT = (LC_TD_BYTE)46; \
  if (RF==0) (p)->LC_VD_VOB_DSING = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DTEN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DHUND = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_LR_VALMAX = (LC_TD_REAL)2147483.0; \
  if (RF==0) (p)->LC_VD_LR_VALMIN = (LC_TD_REAL)-2147483.0; \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_GE_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_ABS_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MUL_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_TO_DINT_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV0_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV1_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD1_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD1_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD2_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV2_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD2_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD3_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV3_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD3_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD4_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV4_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD4_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD5_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV5_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD5_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD6_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV6_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD6_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD7_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV7_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD7_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD8_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_DIV8_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD8_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_MOD9_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD9_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_ADD10_OUT),RF); \
  if (RF==0) (p)->LC_VD_LDI_MILL = (LC_TD_DINT)1000000000L; \
  if (RF==0) (p)->LC_VD_LDI_00THOUS = (LC_TD_DINT)100000000L; \
  if (RF==0) (p)->LC_VD_LDI_0THOUS = (LC_TD_DINT)10000000L; \
  if (RF==0) (p)->LC_VD_LDI_THOUS = (LC_TD_DINT)1000000L; \
  if (RF==0) (p)->LC_VD_LDI_HUN = (LC_TD_DINT)100000L; \
  if (RF==0) (p)->LC_VD_LDI_TEN = (LC_TD_DINT)10000L; \
  if (RF==0) (p)->LC_VD_LDI_DSINGLE = (LC_TD_DINT)1000L; \
  if (RF==0) (p)->LC_VD_LDI_DSING = (LC_TD_DINT)100L; \
  if (RF==0) (p)->LC_VD_LDI_DTEN = (LC_TD_DINT)10L; \
  if (RF==0) (p)->LC_VD_LDI_DHUN = (LC_TD_DINT)1L; \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO12BYTE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_INT)0;
  {
    LC_TD_Function_GT lFunction_GT;
    LC_INIT_Function_GT(&lFunction_GT);
    lFunction_GT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_LR_VALMAX, pEPDB);
    LC_this->LC_VD_VOX_VALMAXERR = lFunction_GT.LC_VD_GT;
  }
  {
    LC_TD_Function_LT lFunction_LT;
    LC_INIT_Function_LT(&lFunction_LT);
    lFunction_LT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_LR_VALMIN, pEPDB);
    LC_this->LC_VD_VOX_VALMINERR = lFunction_LT.LC_VD_LT;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_VALMAXERR == LC_EL_true))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_INT)1;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_VALMINERR == LC_EL_true))
  {
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_INT)2;
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VOX_VALMAXERR == LC_EL_false),(LC_TD_BOOL)(LC_this->LC_VD_VOX_VALMINERR == LC_EL_false)));
    if (conditionResult)
    {
      {
        LC_TD_Function_GE lFunction_GE;
        LC_INIT_Function_GE(&lFunction_GE);
        lFunction_GE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_IN, (LC_TD_REAL)0.0, pEPDB);
        LC_this->LC_VD_LX_GE_OUT = lFunction_GE.LC_VD_GE;
      }
      {
        LC_TD_Function_SEL__BYTE lFunction_SEL;
        LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
        lFunction_SEL.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD_LX_GE_OUT, (LC_TD_BYTE)45, (LC_TD_BYTE)43, pEPDB);
        LC_this->LC_VD_VOB_SIGN = lFunction_SEL.LC_VD_SEL;
      }
      {
        LC_TD_Function_ABS__REAL lFunction_ABS;
        LC_INIT_Function_ABS__REAL(&lFunction_ABS);
        lFunction_ABS.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ABS__REAL(&lFunction_ABS, LC_this->LC_VD_VIR_IN, pEPDB);
        LC_this->LC_VD_LR_ABS_OUT = lFunction_ABS.LC_VD_ABS;
      }
      {
        LC_TD_Function_MUL__REAL lFunction_MUL;
        LC_INIT_Function_MUL__REAL(&lFunction_MUL);
        lFunction_MUL.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_LR_ABS_OUT, (LC_TD_REAL)1000.0, pEPDB);
        LC_this->LC_VD_LR_MUL_OUT = lFunction_MUL.LC_VD_MUL;
      }
      {
        LC_TD_Function_TO_DINT lFunction_TO_DINT;
        LC_INIT_Function_TO_DINT(&lFunction_TO_DINT);
        lFunction_TO_DINT.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_DINT__REAL(&lFunction_TO_DINT, LC_this->LC_VD_LR_MUL_OUT, pEPDB);
        LC_this->LC_VD_LDI_TO_DINT_OUT = lFunction_TO_DINT.LC_VD_TO_DINT;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_TO_DINT_OUT, (LC_TD_DINT)1000000000L, pEPDB);
        LC_this->LC_VD_LDI_DIV0_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV0_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD1_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD1_OUT, pEPDB);
        LC_this->LC_VD_VOB_MILL = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_TO_DINT_OUT, (LC_TD_DINT)1000000000L, pEPDB);
        LC_this->LC_VD_LDI_MOD1_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD1_OUT, (LC_TD_DINT)100000000L, pEPDB);
        LC_this->LC_VD_LDI_DIV1_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV1_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD2_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD2_OUT, pEPDB);
        LC_this->LC_VD_VOB_00THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD1_OUT, (LC_TD_DINT)100000000L, pEPDB);
        LC_this->LC_VD_LDI_MOD2_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD2_OUT, (LC_TD_DINT)10000000L, pEPDB);
        LC_this->LC_VD_LDI_DIV2_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV2_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD3_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD3_OUT, pEPDB);
        LC_this->LC_VD_VOB_0THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD2_OUT, (LC_TD_DINT)10000000L, pEPDB);
        LC_this->LC_VD_LDI_MOD3_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD3_OUT, (LC_TD_DINT)1000000L, pEPDB);
        LC_this->LC_VD_LDI_DIV3_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD3_OUT, (LC_TD_DINT)1000000L, pEPDB);
        LC_this->LC_VD_LDI_MOD4_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV3_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD4_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD4_OUT, pEPDB);
        LC_this->LC_VD_VOB_THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD4_OUT, (LC_TD_DINT)100000L, pEPDB);
        LC_this->LC_VD_LDI_DIV4_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD4_OUT, (LC_TD_DINT)100000L, pEPDB);
        LC_this->LC_VD_LDI_MOD5_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV4_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD5_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD5_OUT, pEPDB);
        LC_this->LC_VD_VOB_HUN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD5_OUT, (LC_TD_DINT)10000L, pEPDB);
        LC_this->LC_VD_LDI_DIV5_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD5_OUT, (LC_TD_DINT)10000L, pEPDB);
        LC_this->LC_VD_LDI_MOD6_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV5_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD6_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD6_OUT, pEPDB);
        LC_this->LC_VD_VOB_TEN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD6_OUT, (LC_TD_DINT)1000L, pEPDB);
        LC_this->LC_VD_LDI_DIV6_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV6_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD7_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD7_OUT, pEPDB);
        LC_this->LC_VD_VOB_SINGLE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD6_OUT, (LC_TD_DINT)1000L, pEPDB);
        LC_this->LC_VD_LDI_MOD7_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD7_OUT, (LC_TD_DINT)100L, pEPDB);
        LC_this->LC_VD_LDI_DIV7_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV7_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD8_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD8_OUT, pEPDB);
        LC_this->LC_VD_VOB_DSING = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD7_OUT, (LC_TD_DINT)100L, pEPDB);
        LC_this->LC_VD_LDI_MOD8_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_DIV__DINT lFunction_DIV;
        LC_INIT_Function_DIV__DINT(&lFunction_DIV);
        lFunction_DIV.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD_LDI_MOD8_OUT, (LC_TD_DINT)10L, pEPDB);
        LC_this->LC_VD_LDI_DIV8_OUT = lFunction_DIV.LC_VD_DIV;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_DIV8_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD9_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD9_OUT, pEPDB);
        LC_this->LC_VD_VOB_DTEN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      {
        LC_TD_Function_MOD__DINT lFunction_MOD;
        LC_INIT_Function_MOD__DINT(&lFunction_MOD);
        lFunction_MOD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD_LDI_MOD8_OUT, (LC_TD_DINT)10L, pEPDB);
        LC_this->LC_VD_LDI_MOD9_OUT = lFunction_MOD.LC_VD_MOD;
      }
      {
        LC_TD_Function_ADD__DINT lFunction_ADD;
        LC_INIT_Function_ADD__DINT(&lFunction_ADD);
        lFunction_ADD.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LDI_MOD9_OUT, (LC_TD_DINT)48L, pEPDB);
        LC_this->LC_VD_LDI_ADD10_OUT = lFunction_ADD.LC_VD_ADD;
      }
      {
        LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
        LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
        lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
        lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD_LDI_ADD10_OUT, pEPDB);
        LC_this->LC_VD_VOB_DHUND = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      }
      LC_this->LC_VD_VOB_DOT = (LC_TD_BYTE)46;
    }
    else
    {
      LC_this->LC_VD_VOB_SIGN = (LC_TD_BYTE)43;
      LC_this->LC_VD_VOB_MILL = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_00THOUS = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_0THOUS = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_THOUS = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_HUN = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_TEN = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_SINGLE = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_DOT = (LC_TD_BYTE)46;
      LC_this->LC_VD_VOB_DSING = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_DTEN = (LC_TD_BYTE)48;
      LC_this->LC_VD_VOB_DHUND = (LC_TD_BYTE)48;
    }
  }
}

#endif
