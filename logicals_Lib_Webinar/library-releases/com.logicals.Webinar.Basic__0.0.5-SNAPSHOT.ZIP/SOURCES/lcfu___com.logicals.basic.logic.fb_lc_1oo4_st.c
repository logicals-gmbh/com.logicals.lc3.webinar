#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST__C

#include <lcfu___com.logicals.basic.logic.fb_lc_1oo4_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__OR.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_1OO4_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_OUT1 = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN1 == LC_EL_true),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN2 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN3 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN4 == LC_EL_false)));
  LC_this->LC_VD_VOX_OUT2 = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN1 == LC_EL_false),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN2 == LC_EL_true))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN3 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN4 == LC_EL_false)));
  LC_this->LC_VD_VOX_OUT3 = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN1 == LC_EL_false),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN2 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN3 == LC_EL_true))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN4 == LC_EL_false)));
  LC_this->LC_VD_VOX_OUT4 = (lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN1 == LC_EL_false),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN2 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN3 == LC_EL_false))),(LC_TD_BOOL)(LC_this->LC_VD_VIX_IN4 == LC_EL_true)));
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, (lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((lcfu_iec61131__OR__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VOX_OUT1 == LC_EL_true),(LC_TD_BOOL)(LC_this->LC_VD_VOX_OUT2 == LC_EL_true))),(LC_TD_BOOL)(LC_this->LC_VD_VOX_OUT3 == LC_EL_true))),(LC_TD_BOOL)(LC_this->LC_VD_VOX_OUT4 == LC_EL_true))), pEPDB);
    LC_this->LC_VD_VOX_ERR = lFunction_NOT.LC_VD_NOT;
  }
}

#endif
