#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD__C

#include <lcfu___com.logicals.opaut.control.fb_opaut_typ_pid_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_SP)); \
  LC_INIT_REAL(&((p)->LC_VD_PV)); \
  LC_INIT_REAL(&((p)->LC_VD_KP)); \
  LC_INIT_REAL(&((p)->LC_VD_TN_T0)); \
  LC_INIT_REAL(&((p)->LC_VD_TV_T0)); \
  LC_INIT_BOOL(&((p)->LC_VD_AUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_EXT)); \
  LC_INIT_REAL(&((p)->LC_VD_MV_MAN)); \
  (p)->LC_VD_MV_LOW = (LC_TD_REAL)0.0; \
  (p)->LC_VD_MV_HIGH = (LC_TD_REAL)100.0; \
  LC_INIT_REAL(&((p)->LC_VD_MV)); \
  LC_INIT_BOOL(&((p)->LC_VD_AH)); \
  LC_INIT_BOOL(&((p)->LC_VD_AL)); \
  LC_INIT_REAL(&((p)->LC_VD_W)); \
  LC_INIT_REAL(&((p)->LC_VD_E)); \
  LC_INIT_REAL(&((p)->LC_VD_REFVAL)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(&((p)->LC_VD_I)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(&((p)->LC_VD_D)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(&((p)->LC_VD_FB_TYP_I1)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(&((p)->LC_VD_FB_TYP_D1)); \
  LC_INIT_REAL(&((p)->LC_VD___1_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___8_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___12_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___16_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___18_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___23_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___32_NOT)); \
  LC_INIT_REAL(&((p)->LC_VD___40_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___44_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___50_LE)); \
  LC_INIT_BOOL(&((p)->LC_VD___57_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___66_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___68_SEL)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_SP),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_PV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_KP),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_TN_T0),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_TV_T0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_AUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_EXT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_MV_MAN),RF); \
  if (RF==0) (p)->LC_VD_MV_LOW = (LC_TD_REAL)0.0; \
  if (RF==0) (p)->LC_VD_MV_HIGH = (LC_TD_REAL)100.0; \
  LC_WINIT_REAL(&((p)->LC_VD_MV),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_AH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_AL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_W),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_E),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_REFVAL),RF); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(&((p)->LC_VD_I),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(&((p)->LC_VD_D),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(&((p)->LC_VD_FB_TYP_I1),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(&((p)->LC_VD_FB_TYP_D1),0); \
  LC_WINIT_REAL(&((p)->LC_VD___1_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___8_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___12_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___16_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___18_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___23_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___32_NOT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___40_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___44_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___50_LE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___57_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___66_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___68_SEL),RF); \
}

void  lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_EXT, LC_this->LC_VD_REFVAL, LC_this->LC_VD_SP, pEPDB);
      LC_this->LC_VD___1_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD___1_SEL, LC_this->LC_VD_PV, pEPDB);
      LC_this->LC_VD___8_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_AL, pEPDB);
      LC_this->LC_VD___23_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_AH, pEPDB);
      LC_this->LC_VD___18_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___23_NOT, LC_this->LC_VD___18_NOT, pEPDB);
      LC_this->LC_VD___16_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_AUT, pEPDB);
      LC_this->LC_VD___32_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_this->LC_VD_FB_TYP_I1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_TYP_I1.LC_VD_START = LC_this->LC_VD___16_AND;
      LC_this->LC_VD_FB_TYP_I1.LC_VD_RESET = LC_this->LC_VD___32_NOT;
      LC_this->LC_VD_FB_TYP_I1.LC_VD_E = LC_this->LC_VD_E;
      LC_this->LC_VD_FB_TYP_I1.LC_VD_TN_T0 = LC_this->LC_VD_TN_T0;
      lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST(&(LC_this->LC_VD_FB_TYP_I1), pEPDB);
    }
    {
      LC_this->LC_VD_FB_TYP_D1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_TYP_D1.LC_VD_E = LC_this->LC_VD_E;
      LC_this->LC_VD_FB_TYP_D1.LC_VD_TV_T0 = LC_this->LC_VD_TV_T0;
      lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(&(LC_this->LC_VD_FB_TYP_D1), pEPDB);
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__3(&lFunction_ADD, LC_this->LC_VD___8_SUB, LC_this->LC_VD_FB_TYP_I1.LC_VD_Y_I, LC_this->LC_VD_FB_TYP_D1.LC_VD_Y_D, pEPDB);
      LC_this->LC_VD___12_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___12_ADD, LC_this->LC_VD_KP, pEPDB);
      LC_this->LC_VD___40_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_AUT, LC_this->LC_VD_MV_MAN, LC_this->LC_VD___40_MUL, pEPDB);
      LC_this->LC_VD_MV = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___44_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_LE lFunction_LE;
      LC_INIT_Function_LE(&lFunction_LE);
      lFunction_LE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LE__ANY__2(&lFunction_LE, LC_this->LC_VD_MV, LC_this->LC_VD_MV_LOW, pEPDB);
      LC_this->LC_VD_AL = lFunction_LE.LC_VD_LE;
      LC_this->LC_VD___50_LE = lFunction_LE.LC_VD_LE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_AL, LC_this->LC_VD_MV, LC_this->LC_VD_MV_LOW, pEPDB);
      LC_this->LC_VD_MV = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___66_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_MV, LC_this->LC_VD_MV_HIGH, pEPDB);
      LC_this->LC_VD_AH = lFunction_GE.LC_VD_GE;
      LC_this->LC_VD___57_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_AH, LC_this->LC_VD_MV, LC_this->LC_VD_MV_HIGH, pEPDB);
      LC_this->LC_VD_MV = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___68_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
}

#endif
