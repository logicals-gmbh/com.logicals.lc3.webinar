#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD__C

#include <lcfu___com.logicals.basic.calc.fb_lc_polygon_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X1)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y1)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X2)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y2)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X3)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y3)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X4)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y4)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X5)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y5)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_X6)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_Y6)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_Y)); \
  LC_INIT_REAL(&((p)->LC_VD___193_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___195_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___197_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___198_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___199_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___200_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___201_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___202_GE)); \
  LC_INIT_BOOL(&((p)->LC_VD___203_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___204_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___205_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___206_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___207_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___208_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___209_DIV)); \
  LC_INIT_REAL(&((p)->LC_VD___210_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___211_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___212_DIV)); \
  LC_INIT_REAL(&((p)->LC_VD___213_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___214_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___215_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___216_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___217_DIV)); \
  LC_INIT_REAL(&((p)->LC_VD___218_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___219_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___220_DIV)); \
  LC_INIT_REAL(&((p)->LC_VD___221_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___222_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___223_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___224_DIV)); \
  LC_INIT_REAL(&((p)->LC_VD___225_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___226_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___227_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___228_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___229_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___230_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___231_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___232_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___233_GE)); \
  LC_INIT_REAL(&((p)->LC_VD___189_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___191_ADD)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X2),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y2),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X3),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y3),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X4),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y4),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X5),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y5),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_X6),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_Y6),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_Y),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___193_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___195_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___197_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___198_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___199_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___200_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___201_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___202_GE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___203_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___204_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___205_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___206_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___207_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___208_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___209_DIV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___210_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___211_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___212_DIV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___213_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___214_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___215_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___216_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___217_DIV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___218_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___219_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___220_DIV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___221_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___222_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___223_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___224_DIV),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___225_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___226_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___227_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___228_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___229_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___230_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___231_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___232_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___233_GE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___189_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___191_ADD),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_POLYGON_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_Y2, LC_this->LC_VD_VIR_Y1, pEPDB);
      LC_this->LC_VD___229_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X2, LC_this->LC_VD_VIR_X1, pEPDB);
      LC_this->LC_VD___216_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD___229_SUB, LC_this->LC_VD___216_SUB, pEPDB);
      LC_this->LC_VD___220_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_X, LC_this->LC_VD___220_DIV, pEPDB);
      LC_this->LC_VD___219_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___219_MUL, LC_this->LC_VD_VIR_Y1, pEPDB);
      LC_this->LC_VD___189_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X2, pEPDB);
      LC_this->LC_VD___208_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_Y3, LC_this->LC_VD_VIR_Y2, pEPDB);
      LC_this->LC_VD___227_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X3, LC_this->LC_VD_VIR_X2, pEPDB);
      LC_this->LC_VD___230_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD___227_SUB, LC_this->LC_VD___230_SUB, pEPDB);
      LC_this->LC_VD___209_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___208_SUB, LC_this->LC_VD___209_DIV, pEPDB);
      LC_this->LC_VD___207_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___207_MUL, LC_this->LC_VD_VIR_Y2, pEPDB);
      LC_this->LC_VD___195_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X3, pEPDB);
      LC_this->LC_VD___223_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_Y4, LC_this->LC_VD_VIR_Y3, pEPDB);
      LC_this->LC_VD___231_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X4, LC_this->LC_VD_VIR_X3, pEPDB);
      LC_this->LC_VD___232_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD___231_SUB, LC_this->LC_VD___232_SUB, pEPDB);
      LC_this->LC_VD___224_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___223_SUB, LC_this->LC_VD___224_DIV, pEPDB);
      LC_this->LC_VD___222_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___222_MUL, LC_this->LC_VD_VIR_Y3, pEPDB);
      LC_this->LC_VD___197_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X4, pEPDB);
      LC_this->LC_VD___211_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_Y5, LC_this->LC_VD_VIR_Y4, pEPDB);
      LC_this->LC_VD___221_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X5, LC_this->LC_VD_VIR_X4, pEPDB);
      LC_this->LC_VD___199_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD___221_SUB, LC_this->LC_VD___199_SUB, pEPDB);
      LC_this->LC_VD___212_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___211_SUB, LC_this->LC_VD___212_DIV, pEPDB);
      LC_this->LC_VD___210_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___210_MUL, LC_this->LC_VD_VIR_Y4, pEPDB);
      LC_this->LC_VD___191_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X5, pEPDB);
      LC_this->LC_VD___201_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_Y6, LC_this->LC_VD_VIR_Y5, pEPDB);
      LC_this->LC_VD___226_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_X6, LC_this->LC_VD_VIR_X5, pEPDB);
      LC_this->LC_VD___225_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD___226_SUB, LC_this->LC_VD___225_SUB, pEPDB);
      LC_this->LC_VD___217_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___201_SUB, LC_this->LC_VD___217_DIV, pEPDB);
      LC_this->LC_VD___200_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___200_MUL, LC_this->LC_VD_VIR_Y5, pEPDB);
      LC_this->LC_VD___193_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X1, pEPDB);
      LC_this->LC_VD___206_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___206_GE, LC_this->LC_VD_VIR_Y1, LC_this->LC_VD___189_ADD, pEPDB);
      LC_this->LC_VD___205_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X2, pEPDB);
      LC_this->LC_VD___228_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___228_GE, LC_this->LC_VD___205_SEL, LC_this->LC_VD___195_ADD, pEPDB);
      LC_this->LC_VD___215_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X3, pEPDB);
      LC_this->LC_VD___214_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___214_GE, LC_this->LC_VD___215_SEL, LC_this->LC_VD___197_ADD, pEPDB);
      LC_this->LC_VD___213_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X4, pEPDB);
      LC_this->LC_VD___233_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___233_GE, LC_this->LC_VD___213_SEL, LC_this->LC_VD___191_ADD, pEPDB);
      LC_this->LC_VD___218_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X5, pEPDB);
      LC_this->LC_VD___202_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___202_GE, LC_this->LC_VD___218_SEL, LC_this->LC_VD___193_ADD, pEPDB);
      LC_this->LC_VD___204_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_X, LC_this->LC_VD_VIR_X6, pEPDB);
      LC_this->LC_VD___203_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___203_GE, LC_this->LC_VD___204_SEL, LC_this->LC_VD_VIR_Y6, pEPDB);
      LC_this->LC_VD_VOR_Y = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___198_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
}

#endif
