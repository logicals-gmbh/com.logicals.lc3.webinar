#include <RISMD.h>
#include <lcpu___prg_lc_testcalc1_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_PRG_LC_TESTCALC1_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDPOUType const lcmd_type_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST;
static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_FB_SURFACE[] RISMD_ATTRIBUTES = "FB_Surface";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_FB_SURFACE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_FB_SURFACE, &lcmd_type_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_FB_SURFACE));

extern RISMDPOUType const lcmd_type_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST;
static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_FB_VOLUMETANK[] RISMD_ATTRIBUTES = "FB_VolumeTank";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_FB_VOLUMETANK RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_FB_VOLUMETANK, &lcmd_type_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_FB_VOLUMETANK));

extern RISMDSimpleNumType const risMdType_REAL;
static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_DIAMETER[] RISMD_ATTRIBUTES = "lr_Diameter";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_LR_DIAMETER RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_DIAMETER, &risMdType_REAL, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_LR_DIAMETER));

static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_HEIGHT[] RISMD_ATTRIBUTES = "lr_Height";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_LR_HEIGHT RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_HEIGHT, &risMdType_REAL, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_LR_HEIGHT));

static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_SURFACE[] RISMD_ATTRIBUTES = "lr_Surface";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_LR_SURFACE RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_SURFACE, &risMdType_REAL, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_LR_SURFACE));

static char const lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_VOLTANK[] RISMD_ATTRIBUTES = "lr_VolTank";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTCALC1_ST_LR_VOLTANK RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTCALC1_ST_LR_VOLTANK, &risMdType_REAL, offsetof(LC_TD_Program_PRG_LC_TESTCALC1_ST,LC_VD_LR_VOLTANK));

static RISMDReference const lcmd_var_list_PRG_LC_TESTCALC1_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_ENO),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_FB_SURFACE),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_FB_VOLUMETANK),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_LR_DIAMETER),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_LR_HEIGHT),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_LR_SURFACE),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTCALC1_ST_LR_VOLTANK),
};

static char const lcmd_type_name_PRG_LC_TESTCALC1_ST[] RISMD_ATTRIBUTES = "PRG_LC_TESTCALC1_ST";
RISMDPOUType const lcmd_type_PRG_LC_TESTCALC1_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_PRG_LC_TESTCALC1_ST, sizeof(LC_TD_Program_PRG_LC_TESTCALC1_ST), 7, lcmd_var_list_PRG_LC_TESTCALC1_ST);
