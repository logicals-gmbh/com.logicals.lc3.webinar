#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD__C

#include <lcfu___com.logicals.basic.rangecheck.fb_lc_rangecheck_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_LU)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_LL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_HYST)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_INRNG)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_URCHD)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LRCHD)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUTOFRNG)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR1)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR2)); \
  LC_INIT_BOOL(&((p)->LC_VD___7_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___10_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___9_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___13_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___21_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___22_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___35_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___40_NOT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_LU),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_LL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_HYST),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_INRNG),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_URCHD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LRCHD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUTOFRNG),RF); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR1),0); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR2),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___7_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___10_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___9_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___13_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___21_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___22_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___35_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___40_NOT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_RANGECHECK_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_LU, LC_this->LC_VD_VIR_HYST, pEPDB);
      LC_this->LC_VD___9_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___9_SUB, pEPDB);
      LC_this->LC_VD___7_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___9_SUB, pEPDB);
      LC_this->LC_VD___22_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_this->LC_VD_SR1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR1.LC_VD_S1 = LC_this->LC_VD___7_GT;
      LC_this->LC_VD_SR1.LC_VD_R = LC_this->LC_VD___22_LT;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR1), pEPDB);
      LC_this->LC_VD_VOX_URCHD = LC_this->LC_VD_SR1.LC_VD_Q1;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_LL, LC_this->LC_VD_VIR_HYST, pEPDB);
      LC_this->LC_VD___13_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___13_ADD, pEPDB);
      LC_this->LC_VD___10_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___13_ADD, pEPDB);
      LC_this->LC_VD___21_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_this->LC_VD_SR2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR2.LC_VD_S1 = LC_this->LC_VD___10_LT;
      LC_this->LC_VD_SR2.LC_VD_R = LC_this->LC_VD___21_GT;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR2), pEPDB);
      LC_this->LC_VD_VOX_LRCHD = LC_this->LC_VD_SR2.LC_VD_Q1;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_SR1.LC_VD_Q1, LC_this->LC_VD_SR2.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOX_OUTOFRNG = lFunction_OR.LC_VD_OR;
      LC_this->LC_VD___35_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD___35_OR, pEPDB);
      LC_this->LC_VD_VOX_INRNG = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___40_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
}

#endif
