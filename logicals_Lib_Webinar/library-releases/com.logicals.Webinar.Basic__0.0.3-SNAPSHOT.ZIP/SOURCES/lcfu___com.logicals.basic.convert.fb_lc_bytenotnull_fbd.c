#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD__C

#include <lcfu___com.logicals.basic.convert.fb_lc_bytenotnull_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD* p = LC_this; \
  (p)->LC_VD_VIB_BYTE9 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE8 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE7 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE6 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE5 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE4 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE3 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE2 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE1 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VIB_BYTE0 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE9 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE8 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE7 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE6 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE5 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE4 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE3 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE2 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE1 = (LC_TD_BYTE)95; \
  (p)->LC_VD_VOB_BYTE0 = (LC_TD_BYTE)95; \
  LC_INIT_BYTE(&((p)->LC_VD___118_SEL)); \
  LC_INIT_BYTE(&((p)->LC_VD___150_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___163_EQ)); \
  LC_INIT_BOOL(&((p)->LC_VD___167_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___143_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___168_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___148_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___165_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___156_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___169_EQ)); \
  LC_INIT_BOOL(&((p)->LC_VD___166_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___115_SEL)); \
  LC_INIT_BYTE(&((p)->LC_VD___130_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___162_EQ)); \
  LC_INIT_BOOL(&((p)->LC_VD___164_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___105_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___160_EQ)); \
  LC_INIT_BYTE(&((p)->LC_VD___121_SEL)); \
  LC_INIT_BYTE(&((p)->LC_VD___153_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___161_EQ)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD* p = LC_this; \
  if (RF==0) (p)->LC_VD_VIB_BYTE9 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE8 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE7 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE6 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE5 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE4 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE3 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE2 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE1 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VIB_BYTE0 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE9 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE8 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE7 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE6 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE5 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE4 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE3 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE2 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE1 = (LC_TD_BYTE)95; \
  if (RF==0) (p)->LC_VD_VOB_BYTE0 = (LC_TD_BYTE)95; \
  LC_WINIT_BYTE(&((p)->LC_VD___118_SEL),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___150_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___163_EQ),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___167_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___143_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___168_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___148_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___165_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___156_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___169_EQ),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___166_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___115_SEL),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___130_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___162_EQ),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___164_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___105_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___160_EQ),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___121_SEL),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___153_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___161_EQ),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_BYTENOTNULL_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE0, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___161_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___161_EQ, LC_this->LC_VD_VIB_BYTE0, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE0 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___153_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE1, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___160_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___160_EQ, LC_this->LC_VD_VIB_BYTE1, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE1 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___121_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE2, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___164_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___164_EQ, LC_this->LC_VD_VIB_BYTE2, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE2 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___105_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 4 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE3, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___162_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___162_EQ, LC_this->LC_VD_VIB_BYTE3, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE3 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___130_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 5 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE4, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___166_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___166_EQ, LC_this->LC_VD_VIB_BYTE4, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE4 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___115_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 6 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE5, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___169_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___169_EQ, LC_this->LC_VD_VIB_BYTE5, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE5 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___156_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 7 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE6, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___165_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___165_EQ, LC_this->LC_VD_VIB_BYTE6, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE6 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___148_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 8 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE7, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___168_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___168_EQ, LC_this->LC_VD_VIB_BYTE7, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE7 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___143_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 9 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE8, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___163_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___163_EQ, LC_this->LC_VD_VIB_BYTE8, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE8 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___150_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 10 */
  {
    {
      LC_TD_Function_EQ lFunction_EQ;
      LC_INIT_Function_EQ(&lFunction_EQ);
      lFunction_EQ.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__EQ__ANY__2(&lFunction_EQ, LC_this->LC_VD_VIB_BYTE9, (LC_TD_BYTE)0, pEPDB);
      LC_this->LC_VD___167_EQ = lFunction_EQ.LC_VD_EQ;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___167_EQ, LC_this->LC_VD_VIB_BYTE9, (LC_TD_BYTE)95, pEPDB);
      LC_this->LC_VD_VOB_BYTE9 = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___118_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
}

#endif
