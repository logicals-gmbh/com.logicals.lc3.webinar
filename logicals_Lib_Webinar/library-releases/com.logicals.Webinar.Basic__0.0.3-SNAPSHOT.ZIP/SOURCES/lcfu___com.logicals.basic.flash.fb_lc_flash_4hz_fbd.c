#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_4HZ_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_4HZ_FBD__C

#include <lcfu___com.logicals.basic.flash.fb_lc_flash_4hz_fbd.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_4HZ_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_4HZ_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_ADD_TIME lFunction_ADD_TIME;
      LC_INIT_Function_ADD_TIME(&lFunction_ADD_TIME);
      lFunction_ADD_TIME.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD_TIME(&lFunction_ADD_TIME, LC_this->LC_VD_LT_OFFTIME, LC_this->LC_VD_LT_ONTIME, pEPDB);
      LC_this->LC_VD___108_ADD_TIME = lFunction_ADD_TIME.LC_VD_ADD_TIME;
    }
    {
      LC_this->LC_VD_TON.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON.LC_VD_IN = LC_this->LC_VD_SR.LC_VD_Q1;
      LC_this->LC_VD_TON.LC_VD_PT = LC_this->LC_VD___108_ADD_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON), pEPDB);
    }
    {
      LC_this->LC_VD_TOF.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TOF.LC_VD_IN = LC_this->LC_VD_TON.LC_VD_Q;
      LC_this->LC_VD_TOF.LC_VD_PT = LC_this->LC_VD_LT_ONTIME;
      lcfu_iec61131__TOF(&(LC_this->LC_VD_TOF), pEPDB);
      LC_this->LC_VD_VOX_OUT = LC_this->LC_VD_TOF.LC_VD_Q;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_TON.LC_VD_Q, pEPDB);
      LC_this->LC_VD___109_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_this->LC_VD_SR.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_SR.LC_VD_S1 = LC_this->LC_VD___109_NOT;
      LC_this->LC_VD_SR.LC_VD_R = LC_this->LC_VD_TOF.LC_VD_Q;
      lcfu_iec61131__SR(&(LC_this->LC_VD_SR), pEPDB);
    }
  }
}

#endif
