#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD__C

#include <lcfu___com.logicals.basic.rangecheck.fb_lc_4limmon_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESETALL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL_HH)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL_H)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL_L)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL_LL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VAL_HYST)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DLYTM_HH_LL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DLYTM_H_L)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_GT_HH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_LT_HH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_GT_H)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_LT_H)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_GT_L)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_LT_L)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_GT_LL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOR_LT_LL)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON2)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON3)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON4)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS2)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON5)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON6)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS3)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON7)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON8)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS4)); \
  LC_INIT_TIME(&((p)->LC_VD___3_TO_TIME)); \
  LC_INIT_REAL(&((p)->LC_VD___10_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___11_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___19_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___24_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___25_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___26_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___18_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___36_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___54_GT)); \
  LC_INIT_REAL(&((p)->LC_VD___55_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___57_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___58_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___59_SUB)); \
  LC_INIT_TIME(&((p)->LC_VD___61_TO_TIME)); \
  LC_INIT_BOOL(&((p)->LC_VD___62_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___63_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___64_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___106_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___107_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___108_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___109_GT)); \
  LC_INIT_REAL(&((p)->LC_VD___112_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___113_SUB)); \
  LC_INIT_TIME(&((p)->LC_VD___114_TO_TIME)); \
  LC_INIT_BOOL(&((p)->LC_VD___115_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___116_NOT)); \
  LC_INIT_TIME(&((p)->LC_VD___117_TO_TIME)); \
  LC_INIT_REAL(&((p)->LC_VD___118_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___120_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___121_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___122_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___123_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___126_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___127_NOT)); \
  LC_INIT_BOOL(&((p)->LC_VD___128_AND)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESETALL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL_HH),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL_H),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL_L),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL_LL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VAL_HYST),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DLYTM_HH_LL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DLYTM_H_L),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_GT_HH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_LT_HH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_GT_H),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_LT_H),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_GT_L),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_LT_L),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_GT_LL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOR_LT_LL),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON2),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON3),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON4),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS2),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON5),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON6),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS3),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON7),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON8),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS4),0); \
  LC_WINIT_TIME(&((p)->LC_VD___3_TO_TIME),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___10_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___11_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___19_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___24_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___25_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___26_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___18_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___36_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___54_GT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___55_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___57_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___58_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___59_SUB),RF); \
  LC_WINIT_TIME(&((p)->LC_VD___61_TO_TIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___62_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___63_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___64_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___106_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___107_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___108_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___109_GT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___112_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___113_SUB),RF); \
  LC_WINIT_TIME(&((p)->LC_VD___114_TO_TIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___115_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___116_NOT),RF); \
  LC_WINIT_TIME(&((p)->LC_VD___117_TO_TIME),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___118_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___120_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___121_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___122_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___123_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___126_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___127_NOT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___128_AND),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ERANGECHECKx2EFB_LC_4LIMMON_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_VIX_RESETALL, pEPDB);
      LC_this->LC_VD___24_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VAL_HH, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___10_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___10_ADD, pEPDB);
      LC_this->LC_VD___18_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VAL_HH, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___11_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___11_SUB, pEPDB);
      LC_this->LC_VD___36_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_TO_TIME lFunction_TO_TIME;
      LC_INIT_Function_TO_TIME(&lFunction_TO_TIME);
      lFunction_TO_TIME.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_TIME__REAL(&lFunction_TO_TIME, LC_this->LC_VD_VIR_DLYTM_HH_LL, pEPDB);
      LC_this->LC_VD___3_TO_TIME = lFunction_TO_TIME.LC_VD_TO_TIME;
    }
    {
      LC_this->LC_VD_TON1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON1.LC_VD_IN = LC_this->LC_VD___18_GT;
      LC_this->LC_VD_TON1.LC_VD_PT = LC_this->LC_VD___3_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON1), pEPDB);
    }
    {
      LC_this->LC_VD_TON2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON2.LC_VD_IN = LC_this->LC_VD___36_LT;
      LC_this->LC_VD_TON2.LC_VD_PT = LC_this->LC_VD___3_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON2), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_VIX_RESETALL, LC_this->LC_VD_TON2.LC_VD_Q, pEPDB);
      LC_this->LC_VD___19_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_RS1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS1.LC_VD_S = LC_this->LC_VD_TON1.LC_VD_Q;
      LC_this->LC_VD_RS1.LC_VD_R1 = LC_this->LC_VD___19_OR;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS1), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___24_NOT, LC_this->LC_VD_RS1.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_GT_HH = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___26_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_RS1.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_LT_HH = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___25_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_VIX_RESETALL, pEPDB);
      LC_this->LC_VD___62_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VAL_H, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___55_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___55_ADD, pEPDB);
      LC_this->LC_VD___54_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VAL_H, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___59_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___59_SUB, pEPDB);
      LC_this->LC_VD___58_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_TO_TIME lFunction_TO_TIME;
      LC_INIT_Function_TO_TIME(&lFunction_TO_TIME);
      lFunction_TO_TIME.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_TIME__REAL(&lFunction_TO_TIME, LC_this->LC_VD_VIR_DLYTM_H_L, pEPDB);
      LC_this->LC_VD___61_TO_TIME = lFunction_TO_TIME.LC_VD_TO_TIME;
    }
    {
      LC_this->LC_VD_TON3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON3.LC_VD_IN = LC_this->LC_VD___54_GT;
      LC_this->LC_VD_TON3.LC_VD_PT = LC_this->LC_VD___61_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON3), pEPDB);
    }
    {
      LC_this->LC_VD_TON4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON4.LC_VD_IN = LC_this->LC_VD___58_LT;
      LC_this->LC_VD_TON4.LC_VD_PT = LC_this->LC_VD___61_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON4), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_VIX_RESETALL, LC_this->LC_VD_TON4.LC_VD_Q, pEPDB);
      LC_this->LC_VD___57_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_RS2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS2.LC_VD_S = LC_this->LC_VD_TON3.LC_VD_Q;
      LC_this->LC_VD_RS2.LC_VD_R1 = LC_this->LC_VD___57_OR;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS2), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___62_NOT, LC_this->LC_VD_RS2.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_GT_H = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___64_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_RS2.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_LT_H = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___63_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_VIX_RESETALL, pEPDB);
      LC_this->LC_VD___116_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VAL_L, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___112_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___112_ADD, pEPDB);
      LC_this->LC_VD___109_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VAL_L, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___113_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___113_SUB, pEPDB);
      LC_this->LC_VD___106_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_TO_TIME lFunction_TO_TIME;
      LC_INIT_Function_TO_TIME(&lFunction_TO_TIME);
      lFunction_TO_TIME.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_TIME__REAL(&lFunction_TO_TIME, LC_this->LC_VD_VIR_DLYTM_H_L, pEPDB);
      LC_this->LC_VD___114_TO_TIME = lFunction_TO_TIME.LC_VD_TO_TIME;
    }
    {
      LC_this->LC_VD_TON6.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON6.LC_VD_IN = LC_this->LC_VD___109_GT;
      LC_this->LC_VD_TON6.LC_VD_PT = LC_this->LC_VD___114_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON6), pEPDB);
    }
    {
      LC_this->LC_VD_TON5.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON5.LC_VD_IN = LC_this->LC_VD___106_LT;
      LC_this->LC_VD_TON5.LC_VD_PT = LC_this->LC_VD___114_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON5), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_VIX_RESETALL, LC_this->LC_VD_TON5.LC_VD_Q, pEPDB);
      LC_this->LC_VD___107_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_RS3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS3.LC_VD_S = LC_this->LC_VD_TON6.LC_VD_Q;
      LC_this->LC_VD_RS3.LC_VD_R1 = LC_this->LC_VD___107_OR;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS3), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___116_NOT, LC_this->LC_VD_RS3.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_GT_L = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___115_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_RS3.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_LT_L = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___108_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
  /* Network 4 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_VIX_RESETALL, pEPDB);
      LC_this->LC_VD___127_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VAL_LL, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___121_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___121_ADD, pEPDB);
      LC_this->LC_VD___126_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VAL_LL, LC_this->LC_VD_VIR_VAL_HYST, pEPDB);
      LC_this->LC_VD___118_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD___118_SUB, pEPDB);
      LC_this->LC_VD___120_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_TO_TIME lFunction_TO_TIME;
      LC_INIT_Function_TO_TIME(&lFunction_TO_TIME);
      lFunction_TO_TIME.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_TIME__REAL(&lFunction_TO_TIME, LC_this->LC_VD_VIR_DLYTM_HH_LL, pEPDB);
      LC_this->LC_VD___117_TO_TIME = lFunction_TO_TIME.LC_VD_TO_TIME;
    }
    {
      LC_this->LC_VD_TON8.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON8.LC_VD_IN = LC_this->LC_VD___126_GT;
      LC_this->LC_VD_TON8.LC_VD_PT = LC_this->LC_VD___117_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON8), pEPDB);
    }
    {
      LC_this->LC_VD_TON7.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON7.LC_VD_IN = LC_this->LC_VD___120_LT;
      LC_this->LC_VD_TON7.LC_VD_PT = LC_this->LC_VD___117_TO_TIME;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON7), pEPDB);
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD_VIX_RESETALL, LC_this->LC_VD_TON7.LC_VD_Q, pEPDB);
      LC_this->LC_VD___122_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_RS4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS4.LC_VD_S = LC_this->LC_VD_TON8.LC_VD_Q;
      LC_this->LC_VD_RS4.LC_VD_R1 = LC_this->LC_VD___122_OR;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS4), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___127_NOT, LC_this->LC_VD_RS4.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_GT_LL = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___128_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_RS4.LC_VD_Q1, pEPDB);
      LC_this->LC_VD_VOR_LT_LL = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___123_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
}

#endif
