#ifndef LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_ST__C
#define LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_ST__C

#include <lcpu___prg_lc_testactuator1_st.h>

/*                            Programs                         */
void  lcpu___PRG_LC_TESTACTUATOR1_ST(LC_TD_Program_PRG_LC_TESTACTUATOR1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_LI_CYCLECOUNT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNT + (LC_TD_INT)1);
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LX_CYCLEINIT = LC_EL_true;
  if ((LC_TD_BOOL)(LC_this->LC_VD_LX_CYCLEINIT == LC_EL_true))
  {
    LC_this->LC_VD_LI_CYCLECOUNTINIT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNTINIT + (LC_TD_INT)1);
  }
  {
    LC_this->LC_VD_FB_MOTOR.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_QUITERR = &LC_this->LC_VD_LX_ERRQUITMOTOR;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_LEFT = LC_this->LC_VD_LX_STARTMOTORLEFT;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_RIGHT = LC_this->LC_VD_LX_STARTMOTORRIGHT;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_STOP = LC_this->LC_VD_LX_STOPMOTOR;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIT_LEFTFBTIME = LC_this->LC_VD_LT_MOTORLEFTDELAYFB;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIT_RIGHTFBTIME = LC_this->LC_VD_LT_MOTORRIGHTDELAYFB;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_LEFTFB = LC_this->LC_VD_LX_MOTORLEFTFB;
    LC_this->LC_VD_FB_MOTOR.LC_VD_VIX_RIGHTFB = LC_this->LC_VD_LX_MOTORRIGHTFB;
    lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_FB_ST(&(LC_this->LC_VD_FB_MOTOR), pEPDB);
    LC_this->LC_VD_LX_MOTORLEFT = LC_this->LC_VD_FB_MOTOR.LC_VD_VOX_MOTORLEFT;
    LC_this->LC_VD_LX_MOTORRIGHT = LC_this->LC_VD_FB_MOTOR.LC_VD_VOX_MOTORRIGHT;
  }
  LC_this->LC_VD_LX_CYCLEINIT = LC_EL_false;
}

#endif
