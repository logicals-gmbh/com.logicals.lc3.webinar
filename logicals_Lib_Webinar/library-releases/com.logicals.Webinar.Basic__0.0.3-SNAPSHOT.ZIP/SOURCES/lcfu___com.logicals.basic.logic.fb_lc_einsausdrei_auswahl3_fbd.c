#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD__C

#include <lcfu___com.logicals.basic.logic.fb_lc_einsausdrei_auswahl3_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD___7_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___11_OR)); \
  LC_INIT_BOOL(&((p)->LC_VD___16_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___23_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___33_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___34_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___35_AND)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___7_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___11_OR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___16_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___23_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___33_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___34_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___35_AND),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL3_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD_VIX_IN1, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
      LC_this->LC_VD___7_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), LC_this->LC_VD_VIX_IN2, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
      LC_this->LC_VD___16_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), LC_this->LC_VD_VIX_IN3, pEPDB);
      LC_this->LC_VD___23_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD___7_AND, LC_this->LC_VD___16_AND, LC_this->LC_VD___23_AND, pEPDB);
      LC_this->LC_VD_VOX_OUT = lFunction_OR.LC_VD_OR;
      LC_this->LC_VD___11_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___11_OR, LC_this->LC_VD_VIX_IN1, pEPDB);
      LC_this->LC_VD_VOX_OUT1 = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___33_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___11_OR, LC_this->LC_VD_VIX_IN2, pEPDB);
      LC_this->LC_VD_VOX_OUT2 = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___34_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___11_OR, LC_this->LC_VD_VIX_IN3, pEPDB);
      LC_this->LC_VD_VOX_OUT3 = lFunction_AND.LC_VD_AND;
      LC_this->LC_VD___35_AND = lFunction_AND.LC_VD_AND;
    }
  }
}

#endif
