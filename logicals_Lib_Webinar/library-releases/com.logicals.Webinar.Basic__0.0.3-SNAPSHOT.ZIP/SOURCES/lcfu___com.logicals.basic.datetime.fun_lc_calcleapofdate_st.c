#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPOFDATE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPOFDATE_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_calcleapofdate_st.h>
#include <lcfu_iec61131__DIV.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPOFDATE_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPOFDATE_ST* LC_this, LC_TD_DATE LC_VD_VIDATE_IN, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_TO_UDINT lFunction__leftOp_SHL__IN__leftOp__leftOp_TO_UDINT;
    LC_TD_Function_SHL__UDINT lFunction__leftOp_SHL;
    LC_INIT_Function_TO_UDINT(&lFunction__leftOp_SHL__IN__leftOp__leftOp_TO_UDINT);
    LC_INIT_Function_SHL__UDINT(&lFunction__leftOp_SHL);
    lFunction__leftOp_SHL__IN__leftOp__leftOp_TO_UDINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UDINT__DATE(&lFunction__leftOp_SHL__IN__leftOp__leftOp_TO_UDINT, LC_VD_VIDATE_IN, pEPDB);
    lFunction__leftOp_SHL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SHL__UDINT(&lFunction__leftOp_SHL, (lcfu_iec61131__DIV__UDINT__INL((LC_TD_UDINT)(lFunction__leftOp_SHL__IN__leftOp__leftOp_TO_UDINT.LC_VD_TO_UDINT + (LC_TD_UDINT)43200UL),(LC_TD_UDINT)31557600UL)), (LC_TD_INT)30, pEPDB);
    LC_this->LC_VD_FUN_LC_CALCLEAPOFDATE_ST = (LC_TD_BOOL)(lFunction__leftOp_SHL.LC_VD_SHL == (LC_TD_UDINT)2147483648UL);
  }
}

#endif
