#ifndef LC_PROT_LCPU___PRG_LC_TESTCONTROL1_FBD__C
#define LC_PROT_LCPU___PRG_LC_TESTCONTROL1_FBD__C

#include <lcpu___prg_lc_testcontrol1_fbd.h>
#include <LC3Globals.h>

/*                            Programs                         */
void  lcpu___PRG_LC_TESTCONTROL1_FBD(LC_TD_Program_PRG_LC_TESTCONTROL1_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_this->LC_VD_R_TRIG.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_R_TRIG.LC_VD_CLK = LC_this->LC_VD_LOCAL_TRUE;
      lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_R_TRIG), pEPDB);
      LC_this->LC_VD_LX_INITPULSE = LC_this->LC_VD_R_TRIG.LC_VD_Q;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_ADD__INT lFunction_ADD;
      LC_INIT_Function_ADD__INT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LI_CYCLECOUNT, (LC_TD_INT)1, pEPDB);
      LC_this->LC_VD_LI_CYCLECOUNT = lFunction_ADD.LC_VD_ADD;
      LC_this->LC_VD___37_ADD = lFunction_ADD.LC_VD_ADD;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
      LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
      LC_this->LC_VD___38_NOT = lFunction_NOT.LC_VD_NOT;
    }
  }
  /* Network 4 */
  {
    {
      LC_TD_Function_RTSCYCLEINFO lFunction_RTSCYCLEINFO;
      LC_INIT_Function_RTSCYCLEINFO(&lFunction_RTSCYCLEINFO);
      lFunction_RTSCYCLEINFO.LC_VD_ENO = LC_EL_true;
      lcfu_logilibrary__RTSCYCLEINFO(&lFunction_RTSCYCLEINFO, pEPDB);
      LC_this->LC_VD_LX_INIT = lFunction_RTSCYCLEINFO.LC_VD_INIT;
      LC_this->LC_VD___39_INIT = lFunction_RTSCYCLEINFO.LC_VD_INIT;
      LC_this->LC_VD_LX_RUN = lFunction_RTSCYCLEINFO.LC_VD_RUN;
      LC_this->LC_VD___39_RUN = lFunction_RTSCYCLEINFO.LC_VD_RUN;
      LC_this->LC_VD_LX_SHUTDOWN = lFunction_RTSCYCLEINFO.LC_VD_SHUTDOWN;
      LC_this->LC_VD___39_SHUTDOWN = lFunction_RTSCYCLEINFO.LC_VD_SHUTDOWN;
      LC_this->LC_VD_LX_TERM = lFunction_RTSCYCLEINFO.LC_VD_TERM;
      LC_this->LC_VD___39_TERM = lFunction_RTSCYCLEINFO.LC_VD_TERM;
    }
  }
  /* Network 5 */
  {
    {
      LC_TD_Function_SYSTASKCYCLETIME lFunction_SYSTASKCYCLETIME;
      LC_INIT_Function_SYSTASKCYCLETIME(&lFunction_SYSTASKCYCLETIME);
      lFunction_SYSTASKCYCLETIME.LC_VD_ENO = LC_EL_true;
      lcfu_logilibrary__SYSTASKCYCLETIME(&lFunction_SYSTASKCYCLETIME, pEPDB);
      LC_this->LC_VD_LT_SYSTASKCYCLETIME = lFunction_SYSTASKCYCLETIME.LC_VD_SYSTASKCYCLETIME;
      LC_this->LC_VD___40_SYSTASKCYCLETIME = lFunction_SYSTASKCYCLETIME.LC_VD_SYSTASKCYCLETIME;
    }
  }
  /* Network 6 */
  {
    {
      LC_TD_Function_SYSTASKACTUALCYCLETIME lFunction_SYSTASKACTUALCYCLETIME;
      LC_INIT_Function_SYSTASKACTUALCYCLETIME(&lFunction_SYSTASKACTUALCYCLETIME);
      lFunction_SYSTASKACTUALCYCLETIME.LC_VD_ENO = LC_EL_true;
      lcfu_logilibrary__SYSTASKACTUALCYCLETIME(&lFunction_SYSTASKACTUALCYCLETIME, pEPDB);
      LC_this->LC_VD_LT_SYSTASKACTUALCYCLETIME = lFunction_SYSTASKACTUALCYCLETIME.LC_VD_SYSTASKACTUALCYCLETIME;
      LC_this->LC_VD___41_SYSTASKACTUALCYCLETIME = lFunction_SYSTASKACTUALCYCLETIME.LC_VD_SYSTASKACTUALCYCLETIME;
    }
  }
  /* Network 7 */
  {
    {
      LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VIX_SETHAND = LC_this->LC_VD_LX_TEST_HANDBETRIEB;
      LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VIX_SETAUTOMATIK = LC_this->LC_VD_LX_TEST_AUTOMATIKBETRIEB;
      LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VIX_SETTEST = LC_this->LC_VD_LX_TEST_TESTBETRIEB;
      LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VIX_SETSIM = LC_this->LC_VD_LX_TEST_SIMBETRIEB;
      lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_MODESELECT_FBD(&(LC_this->LC_VD_FB_LC_MODESELECT_FBD), pEPDB);
      LC_this->LC_VD_LX_HANDBETRIEB = LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VOX_HANDBETRIEB;
      LC_this->LC_VD_LX_AUTOMATIKBETRIEB = LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VOX_AUTOMATIKBETRIEB;
      LC_this->LC_VD_LX_TESTBETRIEB = LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VOX_TESTBETRIEB;
      LC_this->LC_VD_LX_SIMBETRIEB = LC_this->LC_VD_FB_LC_MODESELECT_FBD.LC_VD_VOX_SIMBETRIEB;
    }
  }
  /* Network 8 */
  {
    {
      LC_this->LC_VD_CTU1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_CTU1.LC_VD_CU = LC_this->LC_VD_LX_HANDBETRIEB;
      LC_this->LC_VD_CTU1.LC_VD_R = LC_this->LC_VD_CTU1.LC_VD_Q;
      LC_this->LC_VD_CTU1.LC_VD_PV = LC_this->LC_VD_LI_COUNTPV;
      lcfu_iec61131__CTU(&(LC_this->LC_VD_CTU1), pEPDB);
      LC_this->LC_VD_LI_COUNTMODEMANPV = LC_this->LC_VD_CTU1.LC_VD_CV;
    }
  }
  /* Network 9 */
  {
    {
      LC_this->LC_VD_CTU2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_CTU2.LC_VD_CU = LC_this->LC_VD_LX_AUTOMATIKBETRIEB;
      LC_this->LC_VD_CTU2.LC_VD_R = LC_this->LC_VD_CTU2.LC_VD_Q;
      LC_this->LC_VD_CTU2.LC_VD_PV = LC_this->LC_VD_LI_COUNTPV;
      lcfu_iec61131__CTU(&(LC_this->LC_VD_CTU2), pEPDB);
      LC_this->LC_VD_LI_COUNTMODEAUTOPV = LC_this->LC_VD_CTU2.LC_VD_CV;
    }
  }
  /* Network 10 */
  {
    {
      LC_this->LC_VD_CTU3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_CTU3.LC_VD_CU = LC_this->LC_VD_LX_TESTBETRIEB;
      LC_this->LC_VD_CTU3.LC_VD_R = LC_this->LC_VD_CTU3.LC_VD_Q;
      LC_this->LC_VD_CTU3.LC_VD_PV = LC_this->LC_VD_LI_COUNTPV;
      lcfu_iec61131__CTU(&(LC_this->LC_VD_CTU3), pEPDB);
      LC_this->LC_VD_LI_COUNTMODETESTPV = LC_this->LC_VD_CTU3.LC_VD_CV;
    }
  }
  /* Network 11 */
  {
    {
      LC_this->LC_VD_CTU4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_CTU4.LC_VD_CU = LC_this->LC_VD_LX_SIMBETRIEB;
      LC_this->LC_VD_CTU4.LC_VD_R = LC_this->LC_VD_CTU4.LC_VD_Q;
      LC_this->LC_VD_CTU4.LC_VD_PV = LC_this->LC_VD_LI_COUNTPV;
      lcfu_iec61131__CTU(&(LC_this->LC_VD_CTU4), pEPDB);
      LC_this->LC_VD_LI_COUNTMODESIMPV = LC_this->LC_VD_CTU4.LC_VD_CV;
    }
  }
  /* Network 12 */
  {
    {
      LC_this->LC_VD_FORCEMRK2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK2.LC_VD_IN = LC_GV_READ_ELEM(pEPDB,LC_VD_GI_AI_ACTIN,LC_TD_INT);
      lcfu_iec61131__FORCEMRK__INT(&(LC_this->LC_VD_FORCEMRK2), pEPDB);
    }
    {
      LC_this->LC_VD_FORCEMRK1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK1.LC_VD_IN = LC_GV_READ_ELEM(pEPDB,LC_VD_GI_AI_SETIN,LC_TD_INT);
      lcfu_iec61131__FORCEMRK__INT(&(LC_this->LC_VD_FORCEMRK1), pEPDB);
    }
    {
      LC_TD_Function_TO_REAL lFunction_TO_REAL;
      LC_INIT_Function_TO_REAL(&lFunction_TO_REAL);
      lFunction_TO_REAL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_REAL__TIME(&lFunction_TO_REAL, LC_this->LC_VD_LT_SYSTASKCYCLETIME, pEPDB);
      LC_this->LC_VD___8_TO_REAL = lFunction_TO_REAL.LC_VD_TO_REAL;
    }
    {
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VII_AUTOSETMAXRNGVAL = LC_GV_READ_ELEM(pEPDB,LC_VD_GI_AUTOSETMAXRNGVAL,LC_TD_INT);
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VII_AUTOSETMINRNGVAL = LC_GV_READ_ELEM(pEPDB,LC_VD_GI_AUTOSETMINRNGVAL,LC_TD_INT);
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VIR_AUTOSETINVAL = LC_GV_READ_ELEM(pEPDB,LC_VD_GR_AUTOSETINVAL,LC_TD_REAL);
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VIX_RELEASECTRL = LC_GV_READ_ELEM(pEPDB,LC_VD_GX_RELEASECTRL,LC_TD_BOOL);
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VII_AI_ACTIN = LC_this->LC_VD_FORCEMRK2.LC_VD_OUT;
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VII_AI_SETIN = LC_this->LC_VD_FORCEMRK1.LC_VD_OUT;
      LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VIR_CYCLETIME_SEC = LC_this->LC_VD___8_TO_REAL;
      lcfu___COMx2ELOGICALSx2EBASICx2ECONTROLx2EFB_LC_TESTCONTROL_FBD(&(LC_this->LC_VD_FB_LC_TESTCONTROL_FBD), pEPDB);
    }
    {
      LC_this->LC_VD_FORCEMRK3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_FORCEMRK3.LC_VD_IN = LC_this->LC_VD_FB_LC_TESTCONTROL_FBD.LC_VD_VOI_AUTOSETOUTVAL;
      lcfu_iec61131__FORCEMRK__INT(&(LC_this->LC_VD_FORCEMRK3), pEPDB);
      LC_GV_WRITE_ELEM(pEPDB,LC_VD_GI_AUTOSETOUTVAL,LC_TD_INT) = LC_this->LC_VD_FORCEMRK3.LC_VD_OUT;
    }
  }
}

#endif
