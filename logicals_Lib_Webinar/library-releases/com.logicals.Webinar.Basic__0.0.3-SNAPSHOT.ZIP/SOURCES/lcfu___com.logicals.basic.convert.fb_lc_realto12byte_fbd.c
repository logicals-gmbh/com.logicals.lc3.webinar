#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD__C

#include <lcfu___com.logicals.basic.convert.fb_lc_realto12byte_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD* p = LC_this; \
  (p)->LC_VD_VIR_IN = (LC_TD_REAL)0.0; \
  (p)->LC_VD_VOB_SIGN = (LC_TD_BYTE)43; \
  (p)->LC_VD_VOB_MILL = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_00THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_0THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_THOUS = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_HUN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_TEN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_SINGLE = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DOT = (LC_TD_BYTE)46; \
  (p)->LC_VD_VOB_DSING = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DTEN = (LC_TD_BYTE)48; \
  (p)->LC_VD_VOB_DHUND = (LC_TD_BYTE)48; \
  LC_INIT_BYTE(&((p)->LC_VD___129_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___132_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___142_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___144_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___149_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___152_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___154_TO_BYTE)); \
  LC_INIT_BYTE(&((p)->LC_VD___156_SEL)); \
  LC_INIT_BYTE(&((p)->LC_VD___159_TO_BYTE)); \
  LC_INIT_DINT(&((p)->LC_VD___101_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___165_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___166_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___167_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___168_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___169_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___170_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___171_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___172_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___108_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___173_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___110_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___174_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___175_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___112_TO_DINT)); \
  LC_INIT_DINT(&((p)->LC_VD___176_MOD)); \
  LC_INIT_REAL(&((p)->LC_VD___177_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___178_ABS)); \
  LC_INIT_DINT(&((p)->LC_VD___114_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___179_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___180_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___116_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___181_DIV)); \
  LC_INIT_DINT(&((p)->LC_VD___182_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___183_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___184_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___185_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___186_MOD)); \
  LC_INIT_DINT(&((p)->LC_VD___187_MOD)); \
  LC_INIT_BOOL(&((p)->LC_VD___188_GE)); \
  LC_INIT_BYTE(&((p)->LC_VD___124_TO_BYTE)); \
  LC_INIT_DINT(&((p)->LC_VD___189_ADD)); \
  LC_INIT_DINT(&((p)->LC_VD___190_MOD)); \
  LC_INIT_BYTE(&((p)->LC_VD___127_TO_BYTE)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD* p = LC_this; \
  if (RF==0) (p)->LC_VD_VIR_IN = (LC_TD_REAL)0.0; \
  if (RF==0) (p)->LC_VD_VOB_SIGN = (LC_TD_BYTE)43; \
  if (RF==0) (p)->LC_VD_VOB_MILL = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_00THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_0THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_THOUS = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_HUN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_TEN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_SINGLE = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DOT = (LC_TD_BYTE)46; \
  if (RF==0) (p)->LC_VD_VOB_DSING = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DTEN = (LC_TD_BYTE)48; \
  if (RF==0) (p)->LC_VD_VOB_DHUND = (LC_TD_BYTE)48; \
  LC_WINIT_BYTE(&((p)->LC_VD___129_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___132_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___142_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___144_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___149_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___152_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___154_TO_BYTE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___156_SEL),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___159_TO_BYTE),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___101_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___165_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___166_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___167_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___168_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___169_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___170_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___171_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___172_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___108_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___173_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___110_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___174_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___175_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___112_TO_DINT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___176_MOD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___177_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___178_ABS),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___114_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___179_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___180_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___116_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___181_DIV),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___182_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___183_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___184_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___185_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___186_MOD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___187_MOD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___188_GE),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___124_TO_BYTE),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___189_ADD),RF); \
  LC_WINIT_DINT(&((p)->LC_VD___190_MOD),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD___127_TO_BYTE),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_REALTO12BYTE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VIR_IN, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___188_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SEL__BYTE lFunction_SEL;
      LC_INIT_Function_SEL__BYTE(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__BYTE(&lFunction_SEL, LC_this->LC_VD___188_GE, (LC_TD_BYTE)45, (LC_TD_BYTE)43, pEPDB);
      LC_this->LC_VD_VOB_SIGN = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___156_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_ABS__REAL lFunction_ABS;
      LC_INIT_Function_ABS__REAL(&lFunction_ABS);
      lFunction_ABS.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ABS__REAL(&lFunction_ABS, LC_this->LC_VD_VIR_IN, pEPDB);
      LC_this->LC_VD___178_ABS = lFunction_ABS.LC_VD_ABS;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___178_ABS, (LC_TD_REAL)1000.0, pEPDB);
      LC_this->LC_VD___177_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_TO_DINT lFunction_TO_DINT;
      LC_INIT_Function_TO_DINT(&lFunction_TO_DINT);
      lFunction_TO_DINT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_DINT__REAL(&lFunction_TO_DINT, LC_this->LC_VD___177_MUL, pEPDB);
      LC_this->LC_VD___112_TO_DINT = lFunction_TO_DINT.LC_VD_TO_DINT;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___112_TO_DINT, (LC_TD_DINT)1000000000L, pEPDB);
      LC_this->LC_VD___101_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___101_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___185_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___185_ADD, pEPDB);
      LC_this->LC_VD_VOB_MILL = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___142_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___112_TO_DINT, (LC_TD_DINT)1000000000L, pEPDB);
      LC_this->LC_VD___172_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___172_MOD, (LC_TD_DINT)100000000L, pEPDB);
      LC_this->LC_VD___110_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___110_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___189_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___189_ADD, pEPDB);
      LC_this->LC_VD_VOB_00THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___124_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___172_MOD, (LC_TD_DINT)100000000L, pEPDB);
      LC_this->LC_VD___183_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___183_MOD, (LC_TD_DINT)10000000L, pEPDB);
      LC_this->LC_VD___169_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___169_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___168_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___168_ADD, pEPDB);
      LC_this->LC_VD_VOB_0THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___129_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___183_MOD, (LC_TD_DINT)10000000L, pEPDB);
      LC_this->LC_VD___174_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___174_MOD, (LC_TD_DINT)1000000L, pEPDB);
      LC_this->LC_VD___173_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___173_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___179_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___179_ADD, pEPDB);
      LC_this->LC_VD_VOB_THOUS = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___152_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___174_MOD, (LC_TD_DINT)1000000L, pEPDB);
      LC_this->LC_VD___176_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___176_MOD, (LC_TD_DINT)100000L, pEPDB);
      LC_this->LC_VD___175_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___175_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___182_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___182_ADD, pEPDB);
      LC_this->LC_VD_VOB_HUN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___154_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___176_MOD, (LC_TD_DINT)100000L, pEPDB);
      LC_this->LC_VD___116_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___116_MOD, (LC_TD_DINT)10000L, pEPDB);
      LC_this->LC_VD___166_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___166_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___170_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___170_ADD, pEPDB);
      LC_this->LC_VD_VOB_TEN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___132_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___116_MOD, (LC_TD_DINT)10000L, pEPDB);
      LC_this->LC_VD___184_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___184_MOD, (LC_TD_DINT)1000L, pEPDB);
      LC_this->LC_VD___181_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___181_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___180_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___180_ADD, pEPDB);
      LC_this->LC_VD_VOB_SINGLE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___159_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___184_MOD, (LC_TD_DINT)1000L, pEPDB);
      LC_this->LC_VD___187_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___187_MOD, (LC_TD_DINT)100L, pEPDB);
      LC_this->LC_VD___171_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___171_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___167_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___167_ADD, pEPDB);
      LC_this->LC_VD_VOB_DSING = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___144_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___187_MOD, (LC_TD_DINT)100L, pEPDB);
      LC_this->LC_VD___186_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_DIV__DINT lFunction_DIV;
      LC_INIT_Function_DIV__DINT(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__DINT(&lFunction_DIV, LC_this->LC_VD___186_MOD, (LC_TD_DINT)10L, pEPDB);
      LC_this->LC_VD___114_DIV = lFunction_DIV.LC_VD_DIV;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___114_DIV, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___108_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___108_ADD, pEPDB);
      LC_this->LC_VD_VOB_DTEN = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___127_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
    {
      LC_TD_Function_MOD__DINT lFunction_MOD;
      LC_INIT_Function_MOD__DINT(&lFunction_MOD);
      lFunction_MOD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MOD__DINT(&lFunction_MOD, LC_this->LC_VD___186_MOD, (LC_TD_DINT)10L, pEPDB);
      LC_this->LC_VD___190_MOD = lFunction_MOD.LC_VD_MOD;
    }
    {
      LC_TD_Function_ADD__DINT lFunction_ADD;
      LC_INIT_Function_ADD__DINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___190_MOD, (LC_TD_DINT)48L, pEPDB);
      LC_this->LC_VD___165_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_TO_BYTE lFunction_TO_BYTE;
      LC_INIT_Function_TO_BYTE(&lFunction_TO_BYTE);
      lFunction_TO_BYTE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__TO_BYTE__DINT(&lFunction_TO_BYTE, LC_this->LC_VD___165_ADD, pEPDB);
      LC_this->LC_VD_VOB_DHUND = lFunction_TO_BYTE.LC_VD_TO_BYTE;
      LC_this->LC_VD___149_TO_BYTE = lFunction_TO_BYTE.LC_VD_TO_BYTE;
    }
  }
  /* Network 2 */
  {
    LC_this->LC_VD_VOB_DOT = (LC_TD_BYTE)46;
  }
}

#endif
