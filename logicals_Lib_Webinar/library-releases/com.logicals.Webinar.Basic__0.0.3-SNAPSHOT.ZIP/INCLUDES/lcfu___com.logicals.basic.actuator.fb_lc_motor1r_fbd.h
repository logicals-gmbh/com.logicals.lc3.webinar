#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__MOVE.h>
#include <lcfu_iec61131__RS.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD
{
  LC_TD_BOOL LC_VD_VIX_START;
  LC_TD_BOOL LC_VD_VIX_STOP;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_MOTOR;
  LC_TD_INT LC_VD_VOI_ERRNO;
  LC_TD_BOOL LC_VD___8_AND;
  LC_TD_BOOL LC_VD___16_ENO;
  LC_TD_INT LC_VD___16_MOVE;
  LC_TD_FunctionBlock_RS LC_VD_RS1;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG1;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS1)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS1),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG1),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
