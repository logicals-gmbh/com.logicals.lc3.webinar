#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST
{
  LC_TD_BOOL LC_VD_VIX_CNT;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_UINT LC_VD_VOUI_CNTVAL;
  LC_TD_UINT LC_VD_VOUI_ERRNO;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_CNT)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_CNTVAL)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_CNT),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_CNTVAL),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_CNTMSG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
