#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__OR.h>
#include <lcfu_iec61131__RS.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD
{
  LC_TD_BOOL LC_VD_VIX_RESET;
  LC_TD_BOOL LC_VD_VIX_SET;
  LC_TD_BOOL LC_VD_VIX_TRG;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_BOOL LC_VD___113_OR;
  LC_TD_BOOL LC_VD___114_OR;
  LC_TD_BOOL LC_VD___116_AND;
  LC_TD_BOOL LC_VD___117_AND;
  LC_TD_FunctionBlock_RS LC_VD_RS;
  LC_TD_FunctionBlock_R_TRIG LC_VD_R_TRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_SET)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_TRG)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RESET)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_SET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_TRG),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RESET),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_R_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_TOGGLESW_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
