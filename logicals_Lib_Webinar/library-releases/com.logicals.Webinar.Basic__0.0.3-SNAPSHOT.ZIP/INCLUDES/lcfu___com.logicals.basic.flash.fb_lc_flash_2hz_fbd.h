#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__ADD_TIME.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__SR.h>
#include <lcfu_iec61131__TOF.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_BOOL LC_VD___109_NOT;
  LC_TD_TIME LC_VD_LT_OFFTIMEVAL;
  LC_TD_TIME LC_VD_LT_ONTIMEVAL;
  LC_TD_TIME LC_VD___108_ADD_TIME;
  LC_TD_FunctionBlock_SR LC_VD_SR;
  LC_TD_FunctionBlock_TOF LC_VD_TOF;
  LC_TD_FunctionBlock_TON LC_VD_TON;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_FunctionBlock_SR(&((p)->LC_VD_SR)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON)); \
  LC_INIT_FunctionBlock_TOF(&((p)->LC_VD_TOF)); \
  (p)->LC_VD_LT_OFFTIMEVAL = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
  (p)->LC_VD_LT_ONTIMEVAL = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_FunctionBlock_SR(&((p)->LC_VD_SR),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON),0); \
  LC_WINIT_FunctionBlock_TOF(&((p)->LC_VD_TOF),0); \
  if (RF==0) (p)->LC_VD_LT_OFFTIMEVAL = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
  if (RF==0) (p)->LC_VD_LT_ONTIMEVAL = LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(500000000)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_2HZ_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
