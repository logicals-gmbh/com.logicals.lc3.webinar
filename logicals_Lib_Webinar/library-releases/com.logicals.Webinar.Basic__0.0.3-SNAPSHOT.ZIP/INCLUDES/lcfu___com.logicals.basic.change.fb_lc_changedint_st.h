#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__NE.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST
{
  LC_TD_DINT LC_VD_VIDI_IN;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_DINT LC_VD_LDI_COUNT;
  LC_TD_DINT LC_VD_LDI_OLDVAL;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(p) \
{ \
  LC_INIT_DINT(&((p)->LC_VD_VIDI_IN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_OLDVAL)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_COUNT)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(p,RF) \
{ \
  LC_WINIT_DINT(&((p)->LC_VD_VIDI_IN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_OLDVAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_COUNT),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
