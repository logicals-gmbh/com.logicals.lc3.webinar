#include <RISMD.h>
#include <lcpu___prg_lc_testc_gettime1_st.h>

extern RISMDSimpleNumType const risMdType_BOOL;
static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_ENO[] RISMD_ATTRIBUTES = "ENO";
static RISMDInterfaceVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_ENO RISMD_ATTRIBUTES =
INIT_RISMDInterfaceVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_ENO, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_ENO), RISMD_VARIABLE_SECTION_OUTPUT);

extern RISMDSimpleNumType const risMdType_UINT;
static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUI_YDAY[] RISMD_ATTRIBUTES = "lui_yday";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUI_YDAY RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUI_YDAY, &risMdType_UINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUI_YDAY));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUI_YEAR[] RISMD_ATTRIBUTES = "lui_year";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUI_YEAR RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUI_YEAR, &risMdType_UINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUI_YEAR));

extern RISMDSimpleNumType const risMdType_USINT;
static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_HOUR[] RISMD_ATTRIBUTES = "lusi_hour";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_HOUR RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_HOUR, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_HOUR));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MDAY[] RISMD_ATTRIBUTES = "lusi_mday";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MDAY RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MDAY, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_MDAY));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MIN[] RISMD_ATTRIBUTES = "lusi_min";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MIN RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MIN, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_MIN));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MON[] RISMD_ATTRIBUTES = "lusi_mon";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MON RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_MON, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_MON));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_SEC[] RISMD_ATTRIBUTES = "lusi_sec";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_SEC RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_SEC, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_SEC));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_WDAY[] RISMD_ATTRIBUTES = "lusi_wday";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_WDAY RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LUSI_WDAY, &risMdType_USINT, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LUSI_WDAY));

static char const lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LX_ISDST[] RISMD_ATTRIBUTES = "lx_isdst";
static RISMDStdVariable const lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LX_ISDST RISMD_ATTRIBUTES =
INIT_RISMDStdVariable(lcmd_var_name_PRG_LC_TESTC_GETTIME1_ST_LX_ISDST, &risMdType_BOOL, offsetof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST,LC_VD_LX_ISDST));

static RISMDReference const lcmd_var_list_PRG_LC_TESTC_GETTIME1_ST[] RISMD_ATTRIBUTES =
{
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_ENO),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUI_YDAY),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUI_YEAR),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_HOUR),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MDAY),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MIN),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_MON),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_SEC),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LUSI_WDAY),
  INIT_RISMDReference(&lcmd_var_PRG_LC_TESTC_GETTIME1_ST_LX_ISDST),
};

static char const lcmd_type_name_PRG_LC_TESTC_GETTIME1_ST[] RISMD_ATTRIBUTES = "PRG_LC_TESTC_GETTIME1_ST";
RISMDPOUType const lcmd_type_PRG_LC_TESTC_GETTIME1_ST RISMD_ATTRIBUTES = INIT_RISMDPOUType(lcmd_type_name_PRG_LC_TESTC_GETTIME1_ST, sizeof(LC_TD_Program_PRG_LC_TESTC_GETTIME1_ST), 10, lcmd_var_list_PRG_LC_TESTC_GETTIME1_ST);
