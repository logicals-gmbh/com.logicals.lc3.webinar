#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST__C

#include <lcfu___com.logicals.basic.scale.fb_lc_analogscaleabssimple_st.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MAXINVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MININVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MAXPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_MINPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_OFFSETPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUTPHYSVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_INVALERROR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_PHYSVALERROR)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DELTAINVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_NOTEQUALDELTAINVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DELTAPHYSVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_STEIGUNG)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_SCALE)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_INITR_TRIG)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MAXINVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MININVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MAXPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_MINPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_OFFSETPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUTPHYSVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_INVALERROR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_PHYSVALERROR),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DELTAINVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_NOTEQUALDELTAINVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DELTAPHYSVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_STEIGUNG),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_SCALE),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_INITR_TRIG),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESCALEx2EFB_LC_ANALOGSCALEABSSIMPLE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_LI_CYCLECOUNT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNT + (LC_TD_INT)1);
  {
    LC_this->LC_VD_INITR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_INITR_TRIG.LC_VD_CLK = LC_EL_true;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_INITR_TRIG), pEPDB);
    LC_this->LC_VD_LX_CYCLEINIT = LC_this->LC_VD_INITR_TRIG.LC_VD_Q;
  }
  {
    LC_TD_Function_GT lFunction_OR__IN1_GT;
    LC_TD_Function_LT lFunction_OR__IN2_LT;
    LC_TD_Function_OR__BOOL lFunction_OR;
    LC_INIT_Function_GT(&lFunction_OR__IN1_GT);
    LC_INIT_Function_LT(&lFunction_OR__IN2_LT);
    LC_INIT_Function_OR__BOOL(&lFunction_OR);
    lFunction_OR__IN1_GT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__GT__ANY__2(&lFunction_OR__IN1_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MAXINVAL, pEPDB);
    lFunction_OR__IN2_LT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LT__ANY__2(&lFunction_OR__IN2_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MININVAL, pEPDB);
    lFunction_OR.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__OR__BOOL__2(&lFunction_OR, lFunction_OR__IN1_GT.LC_VD_GT, lFunction_OR__IN2_LT.LC_VD_LT, pEPDB);
    LC_this->LC_VD_VOX_INVALERROR = lFunction_OR.LC_VD_OR;
  }
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_NOTEQUALDELTAINVAL, pEPDB);
    LC_this->LC_VD_VOX_PHYSVALERROR = lFunction_NOT.LC_VD_NOT;
  }
  LC_this->LC_VD_VOR_OUTPHYSVAL = (LC_TD_REAL)0.0;
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MAXINVAL, pEPDB);
      conditionResult = lFunction_GT.LC_VD_GT;
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_ERR = LC_EL_true;
      LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)1;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_VIR_MININVAL, pEPDB);
      conditionResult = lFunction_LT.LC_VD_LT;
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_ERR = LC_EL_true;
      LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)2;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_SUB__REAL lFunction__leftOp_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction__leftOp_SUB);
      lFunction__leftOp_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction__leftOp_SUB, LC_this->LC_VD_VIR_MAXINVAL, LC_this->LC_VD_VIR_MININVAL, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_SUB.LC_VD_SUB == (LC_TD_REAL)0.0);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_ERR = LC_EL_true;
      LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)3;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_ERR == LC_EL_false))
  {
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_MAXINVAL, LC_this->LC_VD_VIR_MININVAL, pEPDB);
      LC_this->LC_VD_LR_DELTAINVAL = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_NE lFunction_NE;
      LC_INIT_Function_NE(&lFunction_NE);
      lFunction_NE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NE__ANY(&lFunction_NE, LC_this->LC_VD_LR_DELTAINVAL, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD_LX_NOTEQUALDELTAINVAL = lFunction_NE.LC_VD_NE;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_MAXPHYSVAL, LC_this->LC_VD_VIR_MINPHYSVAL, pEPDB);
      LC_this->LC_VD_LR_DELTAPHYSVAL = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      if ((lFunction_DIV.LC_VD_ENO = LC_this->LC_VD_LX_NOTEQUALDELTAINVAL) != LC_EL_false)
      {
        lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD_LR_DELTAPHYSVAL, LC_this->LC_VD_LR_DELTAINVAL, pEPDB);
        LC_this->LC_VD_LR_STEIGUNG = lFunction_DIV.LC_VD_DIV;
      }
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_LR_STEIGUNG, pEPDB);
      LC_this->LC_VD_LR_SCALE = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LR_SCALE, LC_this->LC_VD_VIR_OFFSETPHYSVAL, pEPDB);
      LC_this->LC_VD_VOR_OUTPHYSVAL = lFunction_ADD.LC_VD_ADD;
    }
  }
}

#endif
