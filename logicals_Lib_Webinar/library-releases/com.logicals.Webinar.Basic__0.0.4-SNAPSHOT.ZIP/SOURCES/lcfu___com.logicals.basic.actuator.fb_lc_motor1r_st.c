#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST__C

#include <lcfu___com.logicals.basic.actuator.fb_lc_motor1r_st.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOI_ERRNO = (LC_TD_INT)0;
  {
    LC_this->LC_VD_FB_STARTR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_STARTR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_START;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_FB_STARTR_TRIG), pEPDB);
    LC_this->LC_VD_LX_STARTPULSE = LC_this->LC_VD_FB_STARTR_TRIG.LC_VD_Q;
  }
  {
    LC_this->LC_VD_FB_MOTORRS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MOTORRS.LC_VD_S = LC_this->LC_VD_LX_STARTPULSE;
    LC_this->LC_VD_FB_MOTORRS.LC_VD_R1 = LC_this->LC_VD_VIX_STOP;
    lcfu_iec61131__RS(&(LC_this->LC_VD_FB_MOTORRS), pEPDB);
    LC_this->LC_VD_VOX_MOTOR = LC_this->LC_VD_FB_MOTORRS.LC_VD_Q1;
  }
}

#endif
