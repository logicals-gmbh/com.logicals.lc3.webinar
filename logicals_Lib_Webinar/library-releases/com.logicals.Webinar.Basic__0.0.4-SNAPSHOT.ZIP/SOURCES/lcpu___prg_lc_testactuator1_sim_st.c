#ifndef LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_SIM_ST__C
#define LC_PROT_LCPU___PRG_LC_TESTACTUATOR1_SIM_ST__C

#include <lcpu___prg_lc_testactuator1_sim_st.h>

/*                            Programs                         */
void  lcpu___PRG_LC_TESTACTUATOR1_SIM_ST(LC_TD_Program_PRG_LC_TESTACTUATOR1_SIM_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_LI_CYCLECOUNT = (LC_TD_INT)(LC_this->LC_VD_LI_CYCLECOUNT + (LC_TD_INT)1);
  {
    LC_TD_Function_NOT__BOOL lFunction_NOT;
    LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
    lFunction_NOT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_LX_CYCLEPULSE, pEPDB);
    LC_this->LC_VD_LX_CYCLEPULSE = lFunction_NOT.LC_VD_NOT;
  }
  {
    LC_this->LC_VD_FB_MOTORSIM.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MOTORSIM.LC_VD_VIX_LEFT = LC_this->LC_VD_LX_MOTORLEFT;
    LC_this->LC_VD_FB_MOTORSIM.LC_VD_VIX_RIGHT = LC_this->LC_VD_LX_MOTORRIGHT;
    LC_this->LC_VD_FB_MOTORSIM.LC_VD_VIT_LEFTDELAY = LC_this->LC_VD_LT_MOTORLEFTDELAYFB;
    LC_this->LC_VD_FB_MOTORSIM.LC_VD_VIT_RIGHTDELAY = LC_this->LC_VD_LT_MOTORRIGHTDELAYFB;
    lcfu___COMx2ELOGICALSx2EBASICx2EACTUATOR_SIMx2EFB_LC_MOTOR2R_FB_SIM_ST(&(LC_this->LC_VD_FB_MOTORSIM), pEPDB);
    LC_this->LC_VD_LX_MOTORLEFTFB = LC_this->LC_VD_FB_MOTORSIM.LC_VD_VOX_LEFTFB;
    LC_this->LC_VD_LX_MOTORRIGHTFB = LC_this->LC_VD_FB_MOTORSIM.LC_VD_VOX_RIGHTFB;
  }
}

#endif
