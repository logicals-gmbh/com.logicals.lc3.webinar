#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCUDINT_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCUDINT_FBD__C

#include <lcfu___com.logicals.basic.count.fb_lc_incudint_fbd.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCUDINT_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCUDINT_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_ADD__UDINT lFunction_ADD;
      LC_INIT_Function_ADD__UDINT(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_CNT, (LC_TD_UDINT)1UL, pEPDB);
      LC_this->LC_VD_CNT = lFunction_ADD.LC_VD_ADD;
      LC_this->LC_VD___103_ADD = lFunction_ADD.LC_VD_ADD;
    }
  }
}

#endif
