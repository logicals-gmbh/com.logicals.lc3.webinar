#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_conv8bit2byte_st.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN6)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_IN7)); \
  LC_INIT_BYTE(&((p)->LC_VD_VOB_OUT)); \
  LC_INIT_BYTE(&((p)->LC_VD_LB_TEMPVAR)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN6),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_IN7),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_VOB_OUT),RF); \
  LC_WINIT_BYTE(&((p)->LC_VD_LB_TEMPVAR),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV8BIT2BYTE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_LB_TEMPVAR = (LC_TD_BYTE)0;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN0 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)0, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)0, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN1 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)1, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)1, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN2 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)2, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)2, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN3 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)3, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)3, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN4 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)4, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)4, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN5 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)5, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)5, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN6 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)6, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)6, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIX_IN7 == LC_EL_true))
  {
    {
      LC_TD_Function_BIT_SET__BYTE lFunction_BIT_SET;
      LC_INIT_Function_BIT_SET__BYTE(&lFunction_BIT_SET);
      lFunction_BIT_SET.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_SET__BYTE(&lFunction_BIT_SET, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)7, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_SET.LC_VD_BIT_SET;
    }
  }
  else
  {
    {
      LC_TD_Function_BIT_CLR__BYTE lFunction_BIT_CLR;
      LC_INIT_Function_BIT_CLR__BYTE(&lFunction_BIT_CLR);
      lFunction_BIT_CLR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_CLR__BYTE(&lFunction_BIT_CLR, LC_this->LC_VD_LB_TEMPVAR, (LC_TD_USINT)7, pEPDB);
      LC_this->LC_VD_LB_TEMPVAR = lFunction_BIT_CLR.LC_VD_BIT_CLR;
    }
  }
  LC_this->LC_VD_VOB_OUT = LC_this->LC_VD_LB_TEMPVAR;
}

#endif
