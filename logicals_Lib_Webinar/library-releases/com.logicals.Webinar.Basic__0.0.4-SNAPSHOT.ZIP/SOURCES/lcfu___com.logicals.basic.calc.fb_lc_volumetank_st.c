#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST__C

#include <lcfu___com.logicals.basic.calc.fb_lc_volumetank_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_LC_SURFACE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_LC_SURFACE.LC_VD_VIR_DIAMETER = LC_this->LC_VD_VIR_DIAMETER;
    lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&(LC_this->LC_VD_FB_LC_SURFACE), pEPDB);
    LC_this->LC_VD_LR_SURFACE = LC_this->LC_VD_FB_LC_SURFACE.LC_VD_VOR_SURFACE;
  }
  LC_this->LC_VD_VOR_VOLTANK = (LC_TD_REAL)(LC_this->LC_VD_LR_SURFACE * LC_this->LC_VD_VIR_LEVELHEIGHT);
}

#endif
