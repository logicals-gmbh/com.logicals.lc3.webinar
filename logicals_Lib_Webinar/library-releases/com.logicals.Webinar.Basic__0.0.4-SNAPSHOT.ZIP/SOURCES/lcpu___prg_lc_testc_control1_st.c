#ifndef LC_PROT_LCPU___PRG_LC_TESTC_CONTROL1_ST__C
#define LC_PROT_LCPU___PRG_LC_TESTC_CONTROL1_ST__C

#include <lcpu___prg_lc_testc_control1_st.h>



/*                            Programs                         */
void  lcpu___PRG_LC_TESTC_CONTROL1_ST(LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
}

#endif
