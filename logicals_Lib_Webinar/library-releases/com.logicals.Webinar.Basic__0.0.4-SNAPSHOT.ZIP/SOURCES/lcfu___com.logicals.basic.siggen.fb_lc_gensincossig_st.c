#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST__C

#include <lcfu___com.logicals.basic.siggen.fb_lc_gensincossig_st.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST* p = LC_this; \
  (p)->LC_VD_VIR_STEPVAL = (LC_TD_REAL)0.01; \
  (p)->LC_VD_VIR_ENDVAL = (LC_TD_REAL)10000.0; \
  LC_INIT_REAL(&((p)->LC_VD_VOR_SIN_X)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_COS_X)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_SIN_X_2)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_COS_X_2)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  (p)->LC_VD_LR_VAR_X = (LC_TD_REAL)0.0; \
  LC_INIT_REAL(&((p)->LC_VD_LR_A_SIN_X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_B_COSX)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_C_SIN2X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_D_COS2X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_ADD1)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_SIN_LR_VAR_X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MUL1)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_COS_VAR_X)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MUL2)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MUL3)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DIV1)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_MUL4)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_DIV2)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST* p = LC_this; \
  if (RF==0) (p)->LC_VD_VIR_STEPVAL = (LC_TD_REAL)0.01; \
  if (RF==0) (p)->LC_VD_VIR_ENDVAL = (LC_TD_REAL)10000.0; \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_SIN_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_COS_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_SIN_X_2),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_COS_X_2),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  if (RF==0) (p)->LC_VD_LR_VAR_X = (LC_TD_REAL)0.0; \
  LC_WINIT_REAL(&((p)->LC_VD_LR_A_SIN_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_B_COSX),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_C_SIN2X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_D_COS2X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_ADD1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_SIN_LR_VAR_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MUL1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_COS_VAR_X),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MUL2),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MUL3),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DIV1),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_MUL4),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_DIV2),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_GENSINCOSSIG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)0;
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  if ((LC_TD_BOOL)(LC_this->LC_VD_VIR_ENDVAL == (LC_TD_REAL)0.0))
  {
    LC_this->LC_VD_VOUI_ERRNO = (LC_TD_UINT)1;
    LC_this->LC_VD_VOX_ERR = LC_EL_true;
  }
  if ((LC_TD_BOOL)(LC_this->LC_VD_VOX_ERR == LC_EL_false))
  {
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LR_VAR_X, LC_this->LC_VD_VIR_STEPVAL, pEPDB);
      LC_this->LC_VD_LR_VAR_X = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SIN__REAL lFunction_SIN;
      LC_INIT_Function_SIN__REAL(&lFunction_SIN);
      lFunction_SIN.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SIN__REAL(&lFunction_SIN, LC_this->LC_VD_LR_VAR_X, pEPDB);
      LC_this->LC_VD_LR_SIN_LR_VAR_X = lFunction_SIN.LC_VD_SIN;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_LR_SIN_LR_VAR_X, LC_this->LC_VD_VIR_ENDVAL, pEPDB);
      LC_this->LC_VD_LR_MUL1 = lFunction_MUL.LC_VD_MUL;
    }
    LC_this->LC_VD_VOR_SIN_X = LC_this->LC_VD_LR_MUL1;
    LC_this->LC_VD_LR_A_SIN_X = LC_this->LC_VD_LR_MUL1;
    {
      LC_TD_Function_COS__REAL lFunction_COS;
      LC_INIT_Function_COS__REAL(&lFunction_COS);
      lFunction_COS.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__COS__REAL(&lFunction_COS, LC_this->LC_VD_LR_VAR_X, pEPDB);
      LC_this->LC_VD_LR_COS_VAR_X = lFunction_COS.LC_VD_COS;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_LR_COS_VAR_X, LC_this->LC_VD_VIR_ENDVAL, pEPDB);
      LC_this->LC_VD_LR_MUL2 = lFunction_MUL.LC_VD_MUL;
    }
    LC_this->LC_VD_VOR_COS_X = LC_this->LC_VD_LR_MUL2;
    LC_this->LC_VD_LR_B_COSX = LC_this->LC_VD_LR_MUL2;
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_LR_A_SIN_X, LC_this->LC_VD_LR_A_SIN_X, pEPDB);
      LC_this->LC_VD_LR_MUL3 = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD_LR_MUL3, LC_this->LC_VD_VIR_ENDVAL, pEPDB);
      LC_this->LC_VD_LR_DIV1 = lFunction_DIV.LC_VD_DIV;
    }
    LC_this->LC_VD_VOR_SIN_X_2 = LC_this->LC_VD_LR_DIV1;
    LC_this->LC_VD_LR_C_SIN2X = LC_this->LC_VD_LR_DIV1;
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_LR_B_COSX, LC_this->LC_VD_LR_B_COSX, pEPDB);
      LC_this->LC_VD_LR_MUL4 = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_DIV__REAL lFunction_DIV;
      LC_INIT_Function_DIV__REAL(&lFunction_DIV);
      lFunction_DIV.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__DIV__REAL(&lFunction_DIV, LC_this->LC_VD_LR_MUL4, LC_this->LC_VD_VIR_ENDVAL, pEPDB);
      LC_this->LC_VD_LR_DIV2 = lFunction_DIV.LC_VD_DIV;
    }
    LC_this->LC_VD_VOR_COS_X_2 = LC_this->LC_VD_LR_DIV2;
    LC_this->LC_VD_LR_D_COS2X = LC_this->LC_VD_LR_DIV2;
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_LR_C_SIN2X, LC_this->LC_VD_LR_D_COS2X, pEPDB);
      LC_this->LC_VD_LR_ADD1 = lFunction_ADD.LC_VD_ADD;
    }
  }
}

#endif
