#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST__C

#include <lcfu___com.logicals.basic.convert.fb_lc_conv1byte2bit_st.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST* p = LC_this; \
  LC_INIT_BYTE(&((p)->LC_VD_VIB_IN)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT1)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT2)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT3)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT4)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT5)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT6)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT7)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST* p = LC_this; \
  LC_WINIT_BYTE(&((p)->LC_VD_VIB_IN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT0),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT1),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT2),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT3),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT4),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT5),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT6),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT7),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONV1BYTE2BIT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)0, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT0 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT0 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)1, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT1 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT1 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)2, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT2 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT2 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)3, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT3 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT3 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)4, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT4 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT4 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)5, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT5 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT5 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)6, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT6 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT6 = LC_EL_false;
    }
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    {
      LC_TD_Function_BIT_TST lFunction__leftOp_BIT_TST;
      LC_INIT_Function_BIT_TST(&lFunction__leftOp_BIT_TST);
      lFunction__leftOp_BIT_TST.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__BIT_TST__BYTE(&lFunction__leftOp_BIT_TST, LC_this->LC_VD_VIB_IN, (LC_TD_USINT)7, pEPDB);
      conditionResult = (LC_TD_BOOL)(lFunction__leftOp_BIT_TST.LC_VD_BIT_TST == LC_EL_true);
    }
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT7 = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT7 = LC_EL_false;
    }
  }
}

#endif
