#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTINT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTINT_ST__C

#include <lcfu___com.logicals.basic.hyst.fb_lc_hystint_st.h>
#include <lcfu_iec61131__AND.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTINT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTINT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_LI_CMPVAL1 = (LC_TD_INT)(LC_this->LC_VD_VII_IN + LC_this->LC_VD_VII_HYST);
  LC_this->LC_VD_LI_CMPVAL2 = (LC_TD_INT)(LC_this->LC_VD_VII_IN - LC_this->LC_VD_VII_HYST);
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_VII_IN <= LC_this->LC_VD_LI_CMPVAL1),(LC_TD_BOOL)(LC_this->LC_VD_VII_IN >= LC_this->LC_VD_LI_CMPVAL2)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOX_OUT = LC_EL_true;
    }
    else
    {
      LC_this->LC_VD_VOX_OUT = LC_EL_true;
    }
  }
}

#endif
