#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST__C

#include <lcfu___com.logicals.basic.actuator.fb_lc_motor2r_stop_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST* p = LC_this; \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_LEFT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RIGHT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTORLEFT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTORRIGHT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTORSTART)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_STARTR_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_LEFTR_TRIG)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RIGHTR_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_MOTORRS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_MOTORLEFTRS)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_MOTORRIGHTRS)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_STARTPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_LEFTPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_RIGHTPULSE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MOTORSTART)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST* p = LC_this; \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_LEFT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RIGHT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTORLEFT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTORRIGHT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTORSTART),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_STARTR_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_LEFTR_TRIG),0); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_RIGHTR_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_MOTORRS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_MOTORLEFTRS),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_MOTORRIGHTRS),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_STARTPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_LEFTPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_RIGHTPULSE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MOTORSTART),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR2R_STOP_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOX_ERR = LC_EL_false;
  LC_this->LC_VD_VOI_ERRNO = (LC_TD_INT)0;
  {
    LC_this->LC_VD_STARTR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_STARTR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_START;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_STARTR_TRIG), pEPDB);
    LC_this->LC_VD_LX_STARTPULSE = LC_this->LC_VD_STARTR_TRIG.LC_VD_Q;
  }
  {
    LC_this->LC_VD_LEFTR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_LEFTR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_LEFT;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_LEFTR_TRIG), pEPDB);
    LC_this->LC_VD_LX_LEFTPULSE = LC_this->LC_VD_LEFTR_TRIG.LC_VD_Q;
  }
  {
    LC_this->LC_VD_RIGHTR_TRIG.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_RIGHTR_TRIG.LC_VD_CLK = LC_this->LC_VD_VIX_RIGHT;
    lcfu_iec61131__R_TRIG(&(LC_this->LC_VD_RIGHTR_TRIG), pEPDB);
    LC_this->LC_VD_LX_RIGHTPULSE = LC_this->LC_VD_RIGHTR_TRIG.LC_VD_Q;
  }
  {
    LC_this->LC_VD_MOTORRS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_MOTORRS.LC_VD_S = LC_this->LC_VD_LX_STARTPULSE;
    LC_this->LC_VD_MOTORRS.LC_VD_R1 = LC_this->LC_VD_VIX_STOP;
    lcfu_iec61131__RS(&(LC_this->LC_VD_MOTORRS), pEPDB);
    LC_this->LC_VD_LX_MOTORSTART = LC_this->LC_VD_MOTORRS.LC_VD_Q1;
  }
  LC_this->LC_VD_VOX_MOTORSTART = LC_this->LC_VD_LX_MOTORSTART;
  {
    LC_this->LC_VD_MOTORLEFTRS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_MOTORLEFTRS.LC_VD_S = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MOTORSTART,(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_LEFTPULSE,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VOX_MOTORRIGHT))))));
    LC_this->LC_VD_MOTORLEFTRS.LC_VD_R1 = LC_this->LC_VD_VIX_STOP;
    lcfu_iec61131__RS(&(LC_this->LC_VD_MOTORLEFTRS), pEPDB);
    LC_this->LC_VD_VOX_MOTORLEFT = LC_this->LC_VD_MOTORLEFTRS.LC_VD_Q1;
  }
  {
    LC_this->LC_VD_MOTORRIGHTRS.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_MOTORRIGHTRS.LC_VD_S = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_MOTORSTART,(lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_RIGHTPULSE,(lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VOX_MOTORLEFT))))));
    LC_this->LC_VD_MOTORRIGHTRS.LC_VD_R1 = LC_this->LC_VD_VIX_STOP;
    lcfu_iec61131__RS(&(LC_this->LC_VD_MOTORRIGHTRS), pEPDB);
    LC_this->LC_VD_VOX_MOTORRIGHT = LC_this->LC_VD_MOTORRIGHTRS.LC_VD_Q1;
  }
}

#endif
