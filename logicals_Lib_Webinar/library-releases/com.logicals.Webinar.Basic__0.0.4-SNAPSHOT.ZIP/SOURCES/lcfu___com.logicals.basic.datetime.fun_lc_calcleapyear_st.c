#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST__C

#include <lcfu___com.logicals.basic.datetime.fun_lc_calcleapyear_st.h>

/*                            Functions                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST* LC_this, LC_TD_UINT LC_VD_VIUI_YEARVAL, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_TD_Function_SHL__UINT lFunction__leftOp_SHL;
    LC_INIT_Function_SHL__UINT(&lFunction__leftOp_SHL);
    lFunction__leftOp_SHL.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__SHL__UINT(&lFunction__leftOp_SHL, LC_VD_VIUI_YEARVAL, (LC_TD_INT)14, pEPDB);
    LC_this->LC_VD_FUN_LC_CALCLEAPYEAR_ST = (LC_TD_BOOL)(lFunction__leftOp_SHL.LC_VD_SHL == (LC_TD_UINT)0);
  }
}

#endif
