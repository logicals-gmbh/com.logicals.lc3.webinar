#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD__C

#include <lcfu___com.logicals.basic.measure.fb_lc_measure_fbd.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_SCALEHLM)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_SCALELLM)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_ERRREP)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELHHH)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALHHH)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYHHH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELHH)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALHH)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYHH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELH)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALH)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALL)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELLL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALLL)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYLL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_RELLLL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_VALLLL)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_DELAYLLL)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_HYSTVAL)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUTSCALED)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITHHH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITHH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITH)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITLL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_LIMITLLL)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON0)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS0)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON2)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS1)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON3)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS2)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS3)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS4)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON4)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON5)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON6)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_RS5)); \
  LC_INIT_BOOL(&((p)->LC_VD___192_GE)); \
  LC_INIT_BOOL(&((p)->LC_VD___193_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___195_GE)); \
  LC_INIT_BOOL(&((p)->LC_VD___196_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___197_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___198_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___199_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___200_GE)); \
  LC_INIT_BOOL(&((p)->LC_VD___202_LE)); \
  LC_INIT_BOOL(&((p)->LC_VD___203_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___204_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___205_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___206_AND)); \
  LC_INIT_REAL(&((p)->LC_VD___207_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___208_OR)); \
  LC_INIT_REAL(&((p)->LC_VD___209_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___210_MUL)); \
  LC_INIT_BOOL(&((p)->LC_VD___211_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___212_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___213_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___214_ADD)); \
  LC_INIT_REAL(&((p)->LC_VD___215_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___216_AND)); \
  LC_INIT_REAL(&((p)->LC_VD___217_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___219_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___220_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___222_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___223_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___171_LIMIT)); \
  LC_INIT_BOOL(&((p)->LC_VD___184_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___185_LE)); \
  LC_INIT_BOOL(&((p)->LC_VD___187_LE)); \
  LC_INIT_BOOL(&((p)->LC_VD___188_GT)); \
  LC_INIT_REAL(&((p)->LC_VD___189_MUL)); \
  LC_INIT_BOOL(&((p)->LC_VD___190_AND)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_SCALEHLM),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_SCALELLM),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_ERRREP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELHHH),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALHHH),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYHHH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELHH),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALHH),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYHH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELH),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALH),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALL),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELLL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALLL),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYLL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_RELLLL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_VALLLL),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_DELAYLLL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_HYSTVAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUTSCALED),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITHHH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITHH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITH),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITLL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_LIMITLLL),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON0),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS0),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON2),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS1),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON3),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS2),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS3),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS4),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON4),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON5),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON6),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_RS5),0); \
  LC_WINIT_BOOL(&((p)->LC_VD___192_GE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___193_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___195_GE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___196_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___197_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___198_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___199_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___200_GE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___202_LE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___203_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___204_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___205_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___206_AND),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___207_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___208_OR),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___209_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___210_MUL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___211_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___212_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___213_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___214_ADD),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___215_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___216_AND),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___217_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___219_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___220_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___222_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___223_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___171_LIMIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___184_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___185_LE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___187_LE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___188_GT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___189_MUL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___190_AND),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EMEASUREx2EFB_LC_MEASURE_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_IN, (LC_TD_REAL)28500.0, pEPDB);
      LC_this->LC_VD___205_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VIR_IN, (LC_TD_REAL)-552.0, pEPDB);
      LC_this->LC_VD___220_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__2(&lFunction_OR, LC_this->LC_VD___205_GT, LC_this->LC_VD___220_LT, pEPDB);
      LC_this->LC_VD___208_OR = lFunction_OR.LC_VD_OR;
    }
    {
      LC_this->LC_VD_TON0.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON0.LC_VD_IN = LC_this->LC_VD___208_OR;
      LC_this->LC_VD_TON0.LC_VD_PT = LC_TIME_VALUE(RT_CC_CONST_LL(3),RT_CC_CONST_LL(0));
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON0), pEPDB);
      LC_this->LC_VD_VOX_ERR = LC_this->LC_VD_TON0.LC_VD_Q;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_IN, (LC_TD_REAL)0.00003617, pEPDB);
      LC_this->LC_VD___189_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___189_MUL, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___209_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_SCALEHLM, LC_this->LC_VD_VIR_SCALELLM, pEPDB);
      LC_this->LC_VD___222_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___222_SUB, (LC_TD_REAL)1.0, pEPDB);
      LC_this->LC_VD___210_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___209_ADD, LC_this->LC_VD___210_MUL, pEPDB);
      LC_this->LC_VD___198_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD___198_MUL, LC_this->LC_VD_VIR_SCALELLM, pEPDB);
      LC_this->LC_VD___197_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD_TON0.LC_VD_Q, LC_this->LC_VD___197_ADD, LC_this->LC_VD_VIR_ERRREP, pEPDB);
      LC_this->LC_VD___223_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_LIMIT__REAL lFunction_LIMIT;
      LC_INIT_Function_LIMIT__REAL(&lFunction_LIMIT);
      lFunction_LIMIT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LIMIT__ANY(&lFunction_LIMIT, LC_this->LC_VD_VIR_SCALELLM, LC_this->LC_VD___223_SEL, LC_this->LC_VD_VIR_SCALEHLM, pEPDB);
      LC_this->LC_VD_VOR_OUTSCALED = lFunction_LIMIT.LC_VD_LIMIT;
      LC_this->LC_VD___171_LIMIT = lFunction_LIMIT.LC_VD_LIMIT;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALHHH, pEPDB);
      LC_this->LC_VD___192_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VALHHH, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___215_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___215_SUB, pEPDB);
      LC_this->LC_VD___193_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_this->LC_VD_RS0.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS0.LC_VD_S = LC_this->LC_VD___192_GE;
      LC_this->LC_VD_RS0.LC_VD_R1 = LC_this->LC_VD___193_LT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS0), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS0.LC_VD_Q1, LC_this->LC_VD_VIX_RELHHH, pEPDB);
      LC_this->LC_VD___206_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON1.LC_VD_IN = LC_this->LC_VD___206_AND;
      LC_this->LC_VD_TON1.LC_VD_PT = LC_this->LC_VD_VIT_DELAYHHH;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON1), pEPDB);
      LC_this->LC_VD_VOX_LIMITHHH = LC_this->LC_VD_TON1.LC_VD_Q;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALHH, pEPDB);
      LC_this->LC_VD___200_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VALHH, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___213_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___213_SUB, pEPDB);
      LC_this->LC_VD___212_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_this->LC_VD_RS1.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS1.LC_VD_S = LC_this->LC_VD___200_GE;
      LC_this->LC_VD_RS1.LC_VD_R1 = LC_this->LC_VD___212_LT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS1), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS1.LC_VD_Q1, LC_this->LC_VD_VIX_RELHH, pEPDB);
      LC_this->LC_VD___190_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON2.LC_VD_IN = LC_this->LC_VD___190_AND;
      LC_this->LC_VD_TON2.LC_VD_PT = LC_this->LC_VD_VIT_DELAYHH;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON2), pEPDB);
      LC_this->LC_VD_VOX_LIMITHH = LC_this->LC_VD_TON2.LC_VD_Q;
    }
    {
      LC_TD_Function_GE lFunction_GE;
      LC_INIT_Function_GE(&lFunction_GE);
      lFunction_GE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GE__ANY__2(&lFunction_GE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALH, pEPDB);
      LC_this->LC_VD___195_GE = lFunction_GE.LC_VD_GE;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_VALH, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___217_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___217_SUB, pEPDB);
      LC_this->LC_VD___196_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_this->LC_VD_RS2.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS2.LC_VD_S = LC_this->LC_VD___195_GE;
      LC_this->LC_VD_RS2.LC_VD_R1 = LC_this->LC_VD___196_LT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS2), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS2.LC_VD_Q1, LC_this->LC_VD_VIX_RELH, pEPDB);
      LC_this->LC_VD___204_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON3.LC_VD_IN = LC_this->LC_VD___204_AND;
      LC_this->LC_VD_TON3.LC_VD_PT = LC_this->LC_VD_VIT_DELAYH;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON3), pEPDB);
      LC_this->LC_VD_VOX_LIMITH = LC_this->LC_VD_TON3.LC_VD_Q;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_LE lFunction_LE;
      LC_INIT_Function_LE(&lFunction_LE);
      lFunction_LE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LE__ANY__2(&lFunction_LE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALLLL, pEPDB);
      LC_this->LC_VD___185_LE = lFunction_LE.LC_VD_LE;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VALLLL, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___207_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___207_ADD, pEPDB);
      LC_this->LC_VD___219_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_this->LC_VD_RS5.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS5.LC_VD_S = LC_this->LC_VD___185_LE;
      LC_this->LC_VD_RS5.LC_VD_R1 = LC_this->LC_VD___219_GT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS5), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS5.LC_VD_Q1, LC_this->LC_VD_VIX_RELLLL, pEPDB);
      LC_this->LC_VD___216_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON6.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON6.LC_VD_IN = LC_this->LC_VD___216_AND;
      LC_this->LC_VD_TON6.LC_VD_PT = LC_this->LC_VD_VIT_DELAYLLL;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON6), pEPDB);
      LC_this->LC_VD_VOX_LIMITLLL = LC_this->LC_VD_TON6.LC_VD_Q;
    }
    {
      LC_TD_Function_LE lFunction_LE;
      LC_INIT_Function_LE(&lFunction_LE);
      lFunction_LE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LE__ANY__2(&lFunction_LE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALLL, pEPDB);
      LC_this->LC_VD___202_LE = lFunction_LE.LC_VD_LE;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VALLL, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___214_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___214_ADD, pEPDB);
      LC_this->LC_VD___203_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_this->LC_VD_RS3.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS3.LC_VD_S = LC_this->LC_VD___202_LE;
      LC_this->LC_VD_RS3.LC_VD_R1 = LC_this->LC_VD___203_GT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS3), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS3.LC_VD_Q1, LC_this->LC_VD_VIX_RELLL, pEPDB);
      LC_this->LC_VD___211_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON4.LC_VD_IN = LC_this->LC_VD___211_AND;
      LC_this->LC_VD_TON4.LC_VD_PT = LC_this->LC_VD_VIT_DELAYLL;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON4), pEPDB);
      LC_this->LC_VD_VOX_LIMITLL = LC_this->LC_VD_TON4.LC_VD_Q;
    }
    {
      LC_TD_Function_LE lFunction_LE;
      LC_INIT_Function_LE(&lFunction_LE);
      lFunction_LE.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LE__ANY__2(&lFunction_LE, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD_VIR_VALL, pEPDB);
      LC_this->LC_VD___187_LE = lFunction_LE.LC_VD_LE;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_VIR_VALL, LC_this->LC_VD_VIR_HYSTVAL, pEPDB);
      LC_this->LC_VD___199_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VOR_OUTSCALED, LC_this->LC_VD___199_ADD, pEPDB);
      LC_this->LC_VD___188_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_this->LC_VD_RS4.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_RS4.LC_VD_S = LC_this->LC_VD___187_LE;
      LC_this->LC_VD_RS4.LC_VD_R1 = LC_this->LC_VD___188_GT;
      lcfu_iec61131__RS(&(LC_this->LC_VD_RS4), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD_RS4.LC_VD_Q1, LC_this->LC_VD_VIX_RELL, pEPDB);
      LC_this->LC_VD___184_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_this->LC_VD_TON5.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON5.LC_VD_IN = LC_this->LC_VD___184_AND;
      LC_this->LC_VD_TON5.LC_VD_PT = LC_this->LC_VD_VIT_DELAYL;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON5), pEPDB);
      LC_this->LC_VD_VOX_LIMITL = LC_this->LC_VD_TON5.LC_VD_Q;
    }
  }
}

#endif
