#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD__C

#include <lcfu___com.logicals.basic.logic.fb_lc_einsausdrei_auswahl2_fbd.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ELOGICx2EFB_LC_EINSAUSDREI_AUSWAHL2_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD_VIX_IN1, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
      LC_this->LC_VD___13_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), LC_this->LC_VD_VIX_IN2, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN3)), pEPDB);
      LC_this->LC_VD___14_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN1)), (lcfu_iec61131__NOT__BOOL__INL(LC_this->LC_VD_VIX_IN2)), LC_this->LC_VD_VIX_IN3, pEPDB);
      LC_this->LC_VD___16_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_OR__BOOL lFunction_OR;
      LC_INIT_Function_OR__BOOL(&lFunction_OR);
      lFunction_OR.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__OR__BOOL__3(&lFunction_OR, LC_this->LC_VD___13_AND, LC_this->LC_VD___14_AND, LC_this->LC_VD___16_AND, pEPDB);
      LC_this->LC_VD_VOX_OUT = lFunction_OR.LC_VD_OR;
      LC_this->LC_VD___15_OR = lFunction_OR.LC_VD_OR;
    }
  }
}

#endif
