#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCVAL_INT_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCVAL_INT_ST__C

#include <lcfu___com.logicals.basic.count.fb_lc_incval_int_st.h>

/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCVAL_INT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECOUNTx2EFB_LC_INCVAL_INT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_this->LC_VD_VOI_OUT = (LC_TD_INT)(LC_this->LC_VD_VII_IN + (LC_TD_INT)1);
}

#endif
