#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDCHARINSTRING_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDCHARINSTRING_ST__C

#include <lcfu___com.logicals.basic.stringfind.fb_lc_findcharinstring_st.h>
#include <LC3CGStmtFor.h>



/*                            FunctionBlocks                   */
void  lcfu___COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDCHARINSTRING_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESTRINGFINDx2EFB_LC_FINDCHARINSTRING_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  LC_STRING_STACK_OFFSET offset = LC_STRING_STATEMENT_BUFFER(pEPDB);
  {
    LC_TD_Function_LEN__UINT lFunction_LEN;
    LC_INIT_Function_LEN__UINT(&lFunction_LEN);
    lFunction_LEN.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__LEN__UINT(&lFunction_LEN, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), pEPDB);
    LC_this->LC_VD_LUI_LEN = lFunction_LEN.LC_VD_LEN;
    LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
  }
  {
    LC3_MST_FOR(LC_this->LC_VD_LUI_CHARIDX, (LC_TD_USINT)1, LC_this->LC_VD_LUI_LEN, (LC_TD_USINT)1,UINT, UINT);
    {
      {
        LC_TD_BOOL conditionResult = LC_EL_false;
        {
          LC_TD_Function_MID lFunction__leftOp_MID;
          LC_INIT_Function_MID(&lFunction__leftOp_MID);
          lFunction__leftOp_MID.LC_VD_ENO = LC_EL_true;
          lcfu_iec61131__MID__UINT(&lFunction__leftOp_MID, LCCG_CreateStringStruct(LC_this->LC_VD_VISTR_IN,1023), (LC_TD_UINT)1, LC_this->LC_VD_LUI_CHARIDX, pEPDB);
          conditionResult = (LC_STRING_EQ(LC_GET_STRING_PTR(lFunction__leftOp_MID.LC_VD_MID),LC_this->LC_VD_VISTR_FINDCHAR,LC_STR_CMP_MODE_STRING));
        }
        LC_RESET_STRING_STATEMENT_BUFFER(pEPDB,offset);
        if (conditionResult)
        {
          LC_this->LC_VD_VOUI_NOELEM = (LC_TD_UINT)(LC_this->LC_VD_VOUI_NOELEM + (LC_TD_UINT)1);
        }
      }
    }
    LC3_MST_FOR_END(LC_this->LC_VD_LUI_CHARIDX, (LC_TD_USINT)1,LC_this->LC_VD_LUI_LEN, (LC_TD_USINT)1, UINT, UINT);
  }
}

#endif
