#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD__C

#include <lcfu___com.logicals.basic.siggen.fb_lc_rampupdn_fbd.h>

/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* p = LC_this; \
  LC_INIT_REAL(&((p)->LC_VD_VIR_IN)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DXUPMAX)); \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DXDNMAX)); \
  LC_INIT_TIME(&((p)->LC_VD_VIT_TIMEBASE)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_OUT)); \
  LC_INIT_REAL(&((p)->LC_VD_DELTAXABS)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_TON0)); \
  LC_INIT_REAL(&((p)->LC_VD_XDAMPEDINTERNAL)); \
  LC_INIT_REAL(&((p)->LC_VD___192_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___193_SUB)); \
  LC_INIT_BOOL(&((p)->LC_VD___195_NOT)); \
  LC_INIT_REAL(&((p)->LC_VD___196_SQRT)); \
  LC_INIT_BOOL(&((p)->LC_VD___197_AND)); \
  LC_INIT_REAL(&((p)->LC_VD___163_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___165_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___166_SQRT)); \
  LC_INIT_REAL(&((p)->LC_VD___167_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___168_SEL)); \
  LC_INIT_REAL(&((p)->LC_VD___172_SEL)); \
  LC_INIT_BOOL(&((p)->LC_VD___174_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___175_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___176_LT)); \
  LC_INIT_REAL(&((p)->LC_VD___177_ADD)); \
  LC_INIT_BOOL(&((p)->LC_VD___178_AND)); \
  LC_INIT_REAL(&((p)->LC_VD___179_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___180_MUL)); \
  LC_INIT_REAL(&((p)->LC_VD___181_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___182_SUB)); \
  LC_INIT_REAL(&((p)->LC_VD___183_SQRT)); \
  LC_INIT_BOOL(&((p)->LC_VD___184_AND)); \
  LC_INIT_REAL(&((p)->LC_VD___185_MUL)); \
  LC_INIT_BOOL(&((p)->LC_VD___186_AND)); \
  LC_INIT_BOOL(&((p)->LC_VD___187_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___188_LT)); \
  LC_INIT_BOOL(&((p)->LC_VD___189_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___190_GT)); \
  LC_INIT_BOOL(&((p)->LC_VD___191_GT)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* p = LC_this; \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_IN),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DXUPMAX),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DXDNMAX),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VIT_TIMEBASE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_OUT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_DELTAXABS),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_TON0),0); \
  LC_WINIT_REAL(&((p)->LC_VD_XDAMPEDINTERNAL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___192_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___193_SUB),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___195_NOT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___196_SQRT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___197_AND),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___163_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___165_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___166_SQRT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___167_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___168_SEL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___172_SEL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___174_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___175_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___176_LT),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___177_ADD),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___178_AND),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___179_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___180_MUL),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___181_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___182_SUB),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___183_SQRT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___184_AND),RF); \
  LC_WINIT_REAL(&((p)->LC_VD___185_MUL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___186_AND),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___187_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___188_LT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___189_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___190_GT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD___191_GT),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ESIGGENx2EFB_LC_RAMPUPDN_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  /* Network 1 */
  {
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_XDAMPEDINTERNAL, pEPDB);
      LC_this->LC_VD___181_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD___181_SUB, LC_this->LC_VD___181_SUB, pEPDB);
      LC_this->LC_VD___180_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SQRT__REAL lFunction_SQRT;
      LC_INIT_Function_SQRT__REAL(&lFunction_SQRT);
      lFunction_SQRT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SQRT__REAL(&lFunction_SQRT, LC_this->LC_VD___180_MUL, pEPDB);
      LC_this->LC_VD_DELTAXABS = lFunction_SQRT.LC_VD_SQRT;
      LC_this->LC_VD___166_SQRT = lFunction_SQRT.LC_VD_SQRT;
    }
  }
  /* Network 2 */
  {
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_DXDNMAX, LC_this->LC_VD_VIR_DXDNMAX, pEPDB);
      LC_this->LC_VD___192_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SQRT__REAL lFunction_SQRT;
      LC_INIT_Function_SQRT__REAL(&lFunction_SQRT);
      lFunction_SQRT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SQRT__REAL(&lFunction_SQRT, LC_this->LC_VD___192_MUL, pEPDB);
      LC_this->LC_VD___183_SQRT = lFunction_SQRT.LC_VD_SQRT;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_DELTAXABS, LC_this->LC_VD___183_SQRT, pEPDB);
      LC_this->LC_VD___188_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_MUL__REAL lFunction_MUL;
      LC_INIT_Function_MUL__REAL(&lFunction_MUL);
      lFunction_MUL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__MUL__ANY__2(&lFunction_MUL, LC_this->LC_VD_VIR_DXUPMAX, LC_this->LC_VD_VIR_DXUPMAX, pEPDB);
      LC_this->LC_VD___185_MUL = lFunction_MUL.LC_VD_MUL;
    }
    {
      LC_TD_Function_SQRT__REAL lFunction_SQRT;
      LC_INIT_Function_SQRT__REAL(&lFunction_SQRT);
      lFunction_SQRT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SQRT__REAL(&lFunction_SQRT, LC_this->LC_VD___185_MUL, pEPDB);
      LC_this->LC_VD___196_SQRT = lFunction_SQRT.LC_VD_SQRT;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD_DELTAXABS, LC_this->LC_VD___196_SQRT, pEPDB);
      LC_this->LC_VD___176_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_XDAMPEDINTERNAL, pEPDB);
      LC_this->LC_VD___179_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_LT lFunction_LT;
      LC_INIT_Function_LT(&lFunction_LT);
      lFunction_LT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__LT__ANY__2(&lFunction_LT, LC_this->LC_VD___179_SUB, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___187_LT = lFunction_LT.LC_VD_LT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___187_LT, LC_this->LC_VD___188_LT, pEPDB);
      LC_this->LC_VD___186_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD___183_SQRT, pEPDB);
      LC_this->LC_VD___182_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___186_AND, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD_VIR_IN, pEPDB);
      LC_this->LC_VD_XDAMPEDINTERNAL = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___165_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_SUB__REAL lFunction_SUB;
      LC_INIT_Function_SUB__REAL(&lFunction_SUB);
      lFunction_SUB.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SUB__ANY(&lFunction_SUB, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_XDAMPEDINTERNAL, pEPDB);
      LC_this->LC_VD___193_SUB = lFunction_SUB.LC_VD_SUB;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD___193_SUB, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___175_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___175_GT, LC_this->LC_VD___176_LT, pEPDB);
      LC_this->LC_VD___174_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_ADD__REAL lFunction_ADD;
      LC_INIT_Function_ADD__REAL(&lFunction_ADD);
      lFunction_ADD.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__ADD__ANY__2(&lFunction_ADD, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD_VIR_DXUPMAX, pEPDB);
      LC_this->LC_VD___177_ADD = lFunction_ADD.LC_VD_ADD;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___174_AND, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD_VIR_IN, pEPDB);
      LC_this->LC_VD_XDAMPEDINTERNAL = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___167_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_NOT__BOOL lFunction_NOT;
      LC_INIT_Function_NOT__BOOL(&lFunction_NOT);
      lFunction_NOT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__NOT__BOOL(&lFunction_NOT, LC_this->LC_VD_TON0.LC_VD_Q, pEPDB);
      LC_this->LC_VD___195_NOT = lFunction_NOT.LC_VD_NOT;
    }
    {
      LC_this->LC_VD_TON0.LC_VD_ENO = LC_EL_true;
      LC_this->LC_VD_TON0.LC_VD_IN = LC_this->LC_VD___195_NOT;
      LC_this->LC_VD_TON0.LC_VD_PT = LC_this->LC_VD_VIT_TIMEBASE;
      lcfu_iec61131__TON(&(LC_this->LC_VD_TON0), pEPDB);
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___187_LT, LC_this->LC_VD_TON0.LC_VD_Q, pEPDB);
      LC_this->LC_VD___197_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___197_AND, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD___182_SUB, pEPDB);
      LC_this->LC_VD_XDAMPEDINTERNAL = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___172_SEL = lFunction_SEL.LC_VD_SEL;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__2(&lFunction_AND, LC_this->LC_VD___175_GT, LC_this->LC_VD_TON0.LC_VD_Q, pEPDB);
      LC_this->LC_VD___178_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___178_AND, LC_this->LC_VD_XDAMPEDINTERNAL, LC_this->LC_VD___177_ADD, pEPDB);
      LC_this->LC_VD_XDAMPEDINTERNAL = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___168_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
  /* Network 3 */
  {
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_DXDNMAX, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___189_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIR_DXUPMAX, (LC_TD_REAL)0.0, pEPDB);
      LC_this->LC_VD___190_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_GT lFunction_GT;
      LC_INIT_Function_GT(&lFunction_GT);
      lFunction_GT.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__GT__ANY__2(&lFunction_GT, LC_this->LC_VD_VIT_TIMEBASE, LC_TIME_VALUE(RT_CC_CONST_LL(0),RT_CC_CONST_LL(0)), pEPDB);
      LC_this->LC_VD___191_GT = lFunction_GT.LC_VD_GT;
    }
    {
      LC_TD_Function_AND__BOOL lFunction_AND;
      LC_INIT_Function_AND__BOOL(&lFunction_AND);
      lFunction_AND.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__AND__BOOL__3(&lFunction_AND, LC_this->LC_VD___189_GT, LC_this->LC_VD___190_GT, LC_this->LC_VD___191_GT, pEPDB);
      LC_this->LC_VD___184_AND = lFunction_AND.LC_VD_AND;
    }
    {
      LC_TD_Function_SEL__REAL lFunction_SEL;
      LC_INIT_Function_SEL__REAL(&lFunction_SEL);
      lFunction_SEL.LC_VD_ENO = LC_EL_true;
      lcfu_iec61131__SEL__REAL(&lFunction_SEL, LC_this->LC_VD___184_AND, LC_this->LC_VD_VIR_IN, LC_this->LC_VD_XDAMPEDINTERNAL, pEPDB);
      LC_this->LC_VD_VOR_OUT = lFunction_SEL.LC_VD_SEL;
      LC_this->LC_VD___163_SEL = lFunction_SEL.LC_VD_SEL;
    }
  }
}

#endif
