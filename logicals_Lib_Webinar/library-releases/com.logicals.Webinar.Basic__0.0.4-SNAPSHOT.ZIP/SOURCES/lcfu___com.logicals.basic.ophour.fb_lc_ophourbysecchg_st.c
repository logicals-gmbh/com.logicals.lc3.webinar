#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST__C
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST__C

#include <lcfu___com.logicals.basic.ophour.fb_lc_ophourbysecchg_st.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__OR.h>



/*                            FunctionBlocks                   */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST* p = LC_this; \
  LC_INIT_DataType_COMx2ELOGICALSx2EBASICx2EOPHOURx2EDT_LC_OPHOURGETTIME(&((p)->LC_VD_VISTRUC_OPHOURGETTIME)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_LOADSTARTVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_OPHOURCOUNT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOX_ERRNO)); \
  LC_INIT_UDINT(&((p)->LC_VD_VOUDI_ACTALLSEC)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ACTSEC)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ACTMIN)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ACTHOUR)); \
  LC_INIT_UINT(&((p)->LC_VD_VOUI_ACTDAY)); \
  LC_INIT_TIME(&((p)->LC_VD_VOT_ACTTIME)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(&((p)->LC_VD_FB_SECCHANGE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_SECCHANGE)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_FB_SECCTU)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_FB_MINCTU)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_FB_HOURCTU)); \
  LC_INIT_FunctionBlock_CTU(&((p)->LC_VD_FB_DAYCTU)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_DAY)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_HOUR)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_MIN)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_SEC)); \
  (p)->LC_VD_LUDI_DIVDAY = (LC_TD_UDINT)86400UL; \
  (p)->LC_VD_LUDI_DIVHOUR = (LC_TD_UDINT)3600UL; \
  (p)->LC_VD_LUDI_DIVMIN = (LC_TD_UDINT)60UL; \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTDAY)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTHOUR)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTMIN)); \
  LC_INIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTSEC)); \
}

void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB)
{ \
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST* p = LC_this; \
  LC_WINIT_DataType_COMx2ELOGICALSx2EBASICx2EOPHOURx2EDT_LC_OPHOURGETTIME(&((p)->LC_VD_VISTRUC_OPHOURGETTIME),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_LOADSTARTVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_OPHOURCOUNT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOX_ERRNO),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_VOUDI_ACTALLSEC),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ACTSEC),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ACTMIN),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ACTHOUR),RF); \
  LC_WINIT_UINT(&((p)->LC_VD_VOUI_ACTDAY),RF); \
  LC_WINIT_TIME(&((p)->LC_VD_VOT_ACTTIME),RF); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(&((p)->LC_VD_FB_SECCHANGE),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_SECCHANGE),RF); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_FB_SECCTU),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_FB_MINCTU),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_FB_HOURCTU),0); \
  LC_WINIT_FunctionBlock_CTU(&((p)->LC_VD_FB_DAYCTU),0); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_DAY),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_HOUR),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_MIN),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_SEC),RF); \
  if (RF==0) (p)->LC_VD_LUDI_DIVDAY = (LC_TD_UDINT)86400UL; \
  if (RF==0) (p)->LC_VD_LUDI_DIVHOUR = (LC_TD_UDINT)3600UL; \
  if (RF==0) (p)->LC_VD_LUDI_DIVMIN = (LC_TD_UDINT)60UL; \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTDAY),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTHOUR),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTMIN),RF); \
  LC_WINIT_UDINT(&((p)->LC_VD_LUDI_DIVRESTSEC),RF); \
}

void  lcfu___COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFB_LC_OPHOURBYSECCHG_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_SECCHANGE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SECCHANGE.LC_VD_VIDI_IN = LC_this->LC_VD_VISTRUC_OPHOURGETTIME.LC_VD_DI_SEC;
    lcfu___COMx2ELOGICALSx2EBASICx2ECHANGEx2EFB_LC_CHANGEDINT_ST(&(LC_this->LC_VD_FB_SECCHANGE), pEPDB);
    LC_this->LC_VD_LX_SECCHANGE = LC_this->LC_VD_FB_SECCHANGE.LC_VD_VOX_OUT;
  }
  {
    LC_TD_BOOL conditionResult = LC_EL_false;
    conditionResult = (lcfu_iec61131__AND__BOOL__2__INL((LC_TD_BOOL)(LC_this->LC_VD_LX_SECCHANGE == LC_EL_true),(LC_TD_BOOL)(LC_this->LC_VD_VIX_OPHOURCOUNT == LC_EL_true)));
    if (conditionResult)
    {
      LC_this->LC_VD_VOUDI_ACTALLSEC = (LC_TD_UDINT)(LC_this->LC_VD_VOUDI_ACTALLSEC + (LC_TD_UDINT)1UL);
    }
  }
  {
    LC_this->LC_VD_FB_SECCTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SECCTU.LC_VD_CU = (lcfu_iec61131__AND__BOOL__2__INL(LC_this->LC_VD_LX_SECCHANGE,(LC_TD_BOOL)(LC_this->LC_VD_VIX_OPHOURCOUNT == LC_EL_true)));
    LC_this->LC_VD_FB_SECCTU.LC_VD_R = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_FB_SECCTU.LC_VD_Q,LC_this->LC_VD_VIX_LOADSTARTVAL));
    LC_this->LC_VD_FB_SECCTU.LC_VD_PV = (LC_TD_INT)59;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_FB_SECCTU), pEPDB);
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_FB_SECCTU.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOUI_ACTSEC = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_this->LC_VD_FB_MINCTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_MINCTU.LC_VD_CU = LC_this->LC_VD_FB_SECCTU.LC_VD_Q;
    LC_this->LC_VD_FB_MINCTU.LC_VD_R = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_FB_MINCTU.LC_VD_Q,LC_this->LC_VD_VIX_LOADSTARTVAL));
    LC_this->LC_VD_FB_MINCTU.LC_VD_PV = (LC_TD_INT)59;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_FB_MINCTU), pEPDB);
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_FB_MINCTU.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOUI_ACTMIN = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_this->LC_VD_FB_HOURCTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_HOURCTU.LC_VD_CU = LC_this->LC_VD_FB_MINCTU.LC_VD_Q;
    LC_this->LC_VD_FB_HOURCTU.LC_VD_R = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_FB_HOURCTU.LC_VD_Q,LC_this->LC_VD_VIX_LOADSTARTVAL));
    LC_this->LC_VD_FB_HOURCTU.LC_VD_PV = (LC_TD_INT)23;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_FB_HOURCTU), pEPDB);
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_FB_HOURCTU.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOUI_ACTHOUR = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_this->LC_VD_FB_DAYCTU.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_DAYCTU.LC_VD_CU = LC_this->LC_VD_FB_HOURCTU.LC_VD_Q;
    LC_this->LC_VD_FB_DAYCTU.LC_VD_R = (lcfu_iec61131__OR__BOOL__2__INL(LC_this->LC_VD_FB_DAYCTU.LC_VD_Q,LC_this->LC_VD_VIX_LOADSTARTVAL));
    LC_this->LC_VD_FB_DAYCTU.LC_VD_PV = (LC_TD_INT)LC_IEC_INT_MAX;
    lcfu_iec61131__CTU(&(LC_this->LC_VD_FB_DAYCTU), pEPDB);
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__INT(&lFunction_TO_UINT, LC_this->LC_VD_FB_DAYCTU.LC_VD_CV, pEPDB);
    LC_this->LC_VD_VOUI_ACTDAY = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_DIV__UDINT lFunction_DIV;
    LC_INIT_Function_DIV__UDINT(&lFunction_DIV);
    lFunction_DIV.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__DIV__UDINT(&lFunction_DIV, LC_this->LC_VD_VOUDI_ACTALLSEC, LC_this->LC_VD_LUDI_DIVDAY, pEPDB);
    LC_this->LC_VD_LUDI_DAY = lFunction_DIV.LC_VD_DIV;
  }
  {
    LC_TD_Function_TO_UINT lFunction_MOD__IN1_TO_UINT;
    LC_TD_Function_MOD__UDINT lFunction_MOD;
    LC_INIT_Function_TO_UINT(&lFunction_MOD__IN1_TO_UINT);
    LC_INIT_Function_MOD__UDINT(&lFunction_MOD);
    lFunction_MOD__IN1_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_MOD__IN1_TO_UINT, LC_this->LC_VD_VOUDI_ACTALLSEC, pEPDB);
    lFunction_MOD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__MOD__UDINT(&lFunction_MOD, lFunction_MOD__IN1_TO_UINT.LC_VD_TO_UINT, LC_this->LC_VD_LUDI_DIVDAY, pEPDB);
    LC_this->LC_VD_LUDI_DIVRESTDAY = lFunction_MOD.LC_VD_MOD;
  }
  {
    LC_TD_Function_DIV__UDINT lFunction_DIV;
    LC_INIT_Function_DIV__UDINT(&lFunction_DIV);
    lFunction_DIV.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__DIV__UDINT(&lFunction_DIV, LC_this->LC_VD_VOUDI_ACTALLSEC, LC_this->LC_VD_LUDI_DIVHOUR, pEPDB);
    LC_this->LC_VD_LUDI_HOUR = lFunction_DIV.LC_VD_DIV;
  }
  {
    LC_TD_Function_TO_UINT lFunction_MOD__IN1_TO_UINT;
    LC_TD_Function_MOD__UDINT lFunction_MOD;
    LC_INIT_Function_TO_UINT(&lFunction_MOD__IN1_TO_UINT);
    LC_INIT_Function_MOD__UDINT(&lFunction_MOD);
    lFunction_MOD__IN1_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_MOD__IN1_TO_UINT, LC_this->LC_VD_VOUDI_ACTALLSEC, pEPDB);
    lFunction_MOD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__MOD__UDINT(&lFunction_MOD, lFunction_MOD__IN1_TO_UINT.LC_VD_TO_UINT, LC_this->LC_VD_LUDI_DIVHOUR, pEPDB);
    LC_this->LC_VD_LUDI_DIVRESTHOUR = lFunction_MOD.LC_VD_MOD;
  }
  {
    LC_TD_Function_DIV__UDINT lFunction_DIV;
    LC_INIT_Function_DIV__UDINT(&lFunction_DIV);
    lFunction_DIV.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__DIV__UDINT(&lFunction_DIV, LC_this->LC_VD_LUDI_DIVRESTHOUR, LC_this->LC_VD_LUDI_DIVMIN, pEPDB);
    LC_this->LC_VD_LUDI_MIN = lFunction_DIV.LC_VD_DIV;
  }
  {
    LC_TD_Function_MOD__UDINT lFunction_MOD;
    LC_INIT_Function_MOD__UDINT(&lFunction_MOD);
    lFunction_MOD.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__MOD__UDINT(&lFunction_MOD, LC_this->LC_VD_LUDI_DIVRESTHOUR, LC_this->LC_VD_LUDI_DIVMIN, pEPDB);
    LC_this->LC_VD_LUDI_DIVRESTMIN = lFunction_MOD.LC_VD_MOD;
  }
  LC_this->LC_VD_LUDI_SEC = LC_this->LC_VD_LUDI_DIVRESTMIN;
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_TO_UINT, LC_this->LC_VD_LUDI_DAY, pEPDB);
    LC_this->LC_VD_VOUI_ACTDAY = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_TO_UINT, LC_this->LC_VD_LUDI_HOUR, pEPDB);
    LC_this->LC_VD_VOUI_ACTHOUR = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_TO_UINT, LC_this->LC_VD_LUDI_MIN, pEPDB);
    LC_this->LC_VD_VOUI_ACTMIN = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_TO_UINT lFunction_TO_UINT;
    LC_INIT_Function_TO_UINT(&lFunction_TO_UINT);
    lFunction_TO_UINT.LC_VD_ENO = LC_EL_true;
    lcfu_iec61131__TO_UINT__UDINT(&lFunction_TO_UINT, LC_this->LC_VD_LUDI_SEC, pEPDB);
    LC_this->LC_VD_VOUI_ACTSEC = lFunction_TO_UINT.LC_VD_TO_UINT;
  }
  {
    LC_TD_Function_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST lFunction_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST;
    LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST(&lFunction_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST);
    lFunction_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST.LC_VD_ENO = LC_EL_true;
    lcfu___COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST(&lFunction_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST, LC_this->LC_VD_VOUDI_ACTALLSEC, pEPDB);
    LC_this->LC_VD_VOT_ACTTIME = lFunction_COMx2ELOGICALSx2EBASICx2EOPHOURx2EFUN_LC_OPHOURSECOND_TO_TIME_ST.LC_VD_FUN_LC_OPHOURSECOND_TO_TIME_ST;
  }
}

#endif
