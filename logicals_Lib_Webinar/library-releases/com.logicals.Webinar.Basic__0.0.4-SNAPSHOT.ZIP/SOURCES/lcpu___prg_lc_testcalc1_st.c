#ifndef LC_PROT_LCPU___PRG_LC_TESTCALC1_ST__C
#define LC_PROT_LCPU___PRG_LC_TESTCALC1_ST__C

#include <lcpu___prg_lc_testcalc1_st.h>

/*                            Programs                         */
void  lcpu___PRG_LC_TESTCALC1_ST(LC_TD_Program_PRG_LC_TESTCALC1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB)
{
  {
    LC_this->LC_VD_FB_SURFACE.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_SURFACE.LC_VD_VIR_DIAMETER = LC_this->LC_VD_LR_DIAMETER;
    lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&(LC_this->LC_VD_FB_SURFACE), pEPDB);
    LC_this->LC_VD_LR_SURFACE = LC_this->LC_VD_FB_SURFACE.LC_VD_VOR_SURFACE;
  }
  {
    LC_this->LC_VD_FB_VOLUMETANK.LC_VD_ENO = LC_EL_true;
    LC_this->LC_VD_FB_VOLUMETANK.LC_VD_VIR_DIAMETER = LC_this->LC_VD_LR_DIAMETER;
    lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(&(LC_this->LC_VD_FB_VOLUMETANK), pEPDB);
    LC_this->LC_VD_LR_VOLTANK = LC_this->LC_VD_FB_VOLUMETANK.LC_VD_VOR_VOLTANK;
  }
}

#endif
