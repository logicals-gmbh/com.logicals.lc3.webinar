#ifndef LC_PROT_LCPU___PRG_LC_TESTC_BYTEARRFROMSTR1_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTC_BYTEARRFROMSTR1_ST__H

#include <LC3CGBase.h>
#include <lcfu___COM.LOGICALS.BASIC.CONVERT.FUN_LC_BYTEARRFROMSTR_C.h>
#include <lcfu_iec61131__LEN.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>
#include <lcpu___prg_lc_testc_bytearrfromstr1_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LX_CYCLEINIT;
  LC_TD_BOOL LC_VD_LX_CYCLEPULSE;
  LC_TD_INT LC_VD_LI_CYCLECOUNT;
  LC_TD_DINT LC_VD_LDI_LEN;
  LcCgChar LC_VD_LSTR_ARR[1025];
  LC_TD_FunctionBlock_R_TRIG LC_VD_FB_INITR_TRIG;
  LC_TD_BYTE LC_VD_LB_ARR[1024];
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p) \
  LC_INIT_ARRAY(&((p)->LC_VD_LB_ARR),BYTE,1024); \
  LC_INIT_SIZED_STRING_VAL((p)->LC_VD_LSTR_ARR,1024,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!()[]/&%\x3f""\x5c""*+#-_:.;,"); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_LEN)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITR_TRIG)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \

#define LC_INIT_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p,RF) \
  LC_WINIT_ARRAY(&((p)->LC_VD_LB_ARR),BYTE,1024,RF); \
  if (RF==0) LC_INIT_SIZED_STRING_VAL((p)->LC_VD_LSTR_ARR,1024,"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!()[]/&%\x3f""\x5c""*+#-_:.;,"); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_LEN),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITR_TRIG),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \

#define LC_WINIT_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTC_BYTEARRFROMSTR1_ST(LC_TD_Program_PRG_LC_TESTC_BYTEARRFROMSTR1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
