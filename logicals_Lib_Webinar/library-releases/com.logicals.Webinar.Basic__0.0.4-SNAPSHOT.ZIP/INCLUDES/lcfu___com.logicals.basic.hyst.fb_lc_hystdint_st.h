#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST
{
  LC_TD_DINT LC_VD_VIDI_HYST;
  LC_TD_DINT LC_VD_VIDI_IN;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_INT LC_VD_VOI_ERRNO;
  LC_TD_DINT LC_VD_LI_CMPVAL1;
  LC_TD_DINT LC_VD_LI_CMPVAL2;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST(p) \
{ \
  LC_INIT_DINT(&((p)->LC_VD_VIDI_IN)); \
  LC_INIT_DINT(&((p)->LC_VD_VIDI_HYST)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_DINT(&((p)->LC_VD_LI_CMPVAL1)); \
  LC_INIT_DINT(&((p)->LC_VD_LI_CMPVAL2)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST(p,RF) \
{ \
  LC_WINIT_DINT(&((p)->LC_VD_VIDI_IN),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_VIDI_HYST),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LI_CMPVAL1),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LI_CMPVAL2),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EHYSTx2EFB_LC_HYSTDINT_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
