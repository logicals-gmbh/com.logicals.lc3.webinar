#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__CONVERT.h>
#include <lcfu_iec61131__TO_TOD.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_TOD LC_VD_FUN_LC_CONVHOUR2TOD_ST;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST(p) \
{ \
  LC_INIT_TOD(&((p)->LC_VD_FUN_LC_CONVHOUR2TOD_ST)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CONVHOUR2TOD_ST* LC_this, LC_TD_REAL LC_VD_VIR_HOURVAL, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
