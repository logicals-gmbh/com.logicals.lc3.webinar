#ifndef LC_PROT_LCPU___PRG_LC_TESTC_CONTROL1_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTC_CONTROL1_ST__H

#include <LC3CGBase.h>
#include <lcpu___prg_lc_testc_control1_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST
{
  LC_TD_BOOL LC_VD_ENO;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTC_CONTROL1_ST(p) \

#define LC_INIT_Program_PRG_LC_TESTC_CONTROL1_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTC_CONTROL1_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTC_CONTROL1_ST(p,RF) \

#define LC_WINIT_Program_PRG_LC_TESTC_CONTROL1_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTC_CONTROL1_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTC_CONTROL1_ST(LC_TD_Program_PRG_LC_TESTC_CONTROL1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
