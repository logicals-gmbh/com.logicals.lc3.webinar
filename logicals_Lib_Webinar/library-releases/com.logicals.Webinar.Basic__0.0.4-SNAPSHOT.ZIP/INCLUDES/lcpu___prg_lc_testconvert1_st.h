#ifndef LC_PROT_LCPU___PRG_LC_TESTCONVERT1_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTCONVERT1_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.convert.fb_lc_convrealto2int_st.h>
#include <lcpu___prg_lc_testconvert1_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTCONVERT1_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_LX_0THOUS;
  LC_TD_BOOL LC_VD_LX_00THOUS;
  LC_TD_BOOL LC_VD_LX_DHUN;
  LC_TD_BOOL LC_VD_LX_DSING;
  LC_TD_BOOL LC_VD_LX_DSINGLE;
  LC_TD_BOOL LC_VD_LX_DTEN;
  LC_TD_BOOL LC_VD_LX_HUN;
  LC_TD_BOOL LC_VD_LX_MILL;
  LC_TD_BOOL LC_VD_LX_SIGN;
  LC_TD_BOOL LC_VD_LX_TEN;
  LC_TD_BOOL LC_VD_LX_THOUS;
  LC_TD_DINT LC_VD_LDI_HVAL;
  LC_TD_DINT LC_VD_LDI_LVAL;
  LC_TD_REAL LC_VD_LR_VAL;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST LC_VD_FB_CONVREALTO2INT;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTCONVERT1_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTCONVERT1_ST(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST(&((p)->LC_VD_FB_CONVREALTO2INT)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_VAL)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_HVAL)); \
  LC_INIT_DINT(&((p)->LC_VD_LDI_LVAL)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_SIGN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_MILL)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_00THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_0THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_THOUS)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_HUN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_TEN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_DSINGLE)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_DSING)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_DTEN)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_DHUN)); \

#define LC_INIT_Program_PRG_LC_TESTCONVERT1_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTCONVERT1_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTCONVERT1_ST(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECONVERTx2EFB_LC_CONVREALTO2INT_ST(&((p)->LC_VD_FB_CONVREALTO2INT),0); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_VAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_HVAL),RF); \
  LC_WINIT_DINT(&((p)->LC_VD_LDI_LVAL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_SIGN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_MILL),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_00THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_0THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_THOUS),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_HUN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_TEN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_DSINGLE),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_DSING),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_DTEN),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_DHUN),RF); \

#define LC_WINIT_Program_PRG_LC_TESTCONVERT1_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTCONVERT1_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTCONVERT1_ST(LC_TD_Program_PRG_LC_TESTCONVERT1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
