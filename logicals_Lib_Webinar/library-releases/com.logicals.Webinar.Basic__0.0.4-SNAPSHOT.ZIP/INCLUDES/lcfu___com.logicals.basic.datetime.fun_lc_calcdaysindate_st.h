#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.datetime.fun_lc_calcleapofdate_st.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_UINT LC_VD_FUN_LC_CALCDAYSINDATE_ST;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST(p) \
{ \
  LC_INIT_UINT(&((p)->LC_VD_FUN_LC_CALCDAYSINDATE_ST)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCDAYSINDATE_ST* LC_this, LC_TD_DATE LC_VD_VIDATE_IN, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
