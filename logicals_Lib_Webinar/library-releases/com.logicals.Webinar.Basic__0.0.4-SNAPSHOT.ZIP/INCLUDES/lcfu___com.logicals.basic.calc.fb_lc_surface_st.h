#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__EXPT.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST
{
  LC_TD_REAL LC_VD_VIR_DIAMETER;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_VOR_SURFACE;
  LC_TD_BOOL LC_VD_LX_CYCLEINIT;
  LC_TD_BOOL LC_VD_LX_CYCLEPULSE;
  LC_TD_INT LC_VD_LI_CYCLECOUNT;
  LC_TD_INT LC_VD_LI_CYCLECOUNTINITVAL;
  LC_TD_REAL LC_VD_LR_PI;
  LC_TD_FunctionBlock_R_TRIG LC_VD_FB_INITR_TRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(p) \
{ \
  LC_INIT_REAL(&((p)->LC_VD_VIR_DIAMETER)); \
  LC_INIT_REAL(&((p)->LC_VD_VOR_SURFACE)); \
  LC_INIT_REAL(&((p)->LC_VD_LR_PI)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNT)); \
  LC_INIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINITVAL)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITR_TRIG)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(p,RF) \
{ \
  LC_WINIT_REAL(&((p)->LC_VD_VIR_DIAMETER),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_VOR_SURFACE),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_LR_PI),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEINIT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_CYCLEPULSE),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNT),RF); \
  LC_WINIT_INT(&((p)->LC_VD_LI_CYCLECOUNTINITVAL),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_INITR_TRIG),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
