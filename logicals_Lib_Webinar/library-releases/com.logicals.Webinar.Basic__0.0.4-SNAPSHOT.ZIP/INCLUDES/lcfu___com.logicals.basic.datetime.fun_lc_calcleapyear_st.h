#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__SHL.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_FUN_LC_CALCLEAPYEAR_ST;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_FUN_LC_CALCLEAPYEAR_ST)); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST(LC_TD_Function_COMx2ELOGICALSx2EBASICx2EDATETIMEx2EFUN_LC_CALCLEAPYEAR_ST* LC_this, LC_TD_UINT LC_VD_VIUI_YEARVAL, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
