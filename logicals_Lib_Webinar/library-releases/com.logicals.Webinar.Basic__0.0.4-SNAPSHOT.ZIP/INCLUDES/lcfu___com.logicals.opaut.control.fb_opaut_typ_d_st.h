#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST
{
  LC_TD_REAL LC_VD_E;
  LC_TD_REAL LC_VD_TV_T0;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_Y_D;
  LC_TD_REAL LC_VD_E_ALT;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(p) \
{ \
  LC_INIT_REAL(&((p)->LC_VD_E)); \
  LC_INIT_REAL(&((p)->LC_VD_TV_T0)); \
  LC_INIT_REAL(&((p)->LC_VD_Y_D)); \
  LC_INIT_REAL(&((p)->LC_VD_E_ALT)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(p,RF) \
{ \
  LC_WINIT_REAL(&((p)->LC_VD_E),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_TV_T0),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_Y_D),RF); \
  LC_WINIT_REAL(&((p)->LC_VD_E_ALT),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
