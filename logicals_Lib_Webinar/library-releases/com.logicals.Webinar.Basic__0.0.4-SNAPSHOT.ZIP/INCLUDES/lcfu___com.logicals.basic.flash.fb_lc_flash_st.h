#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__TON.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST
{
  LC_TD_BOOL LC_VD_VIX_START;
  LC_TD_TIME LC_VD_VIT_OFFTIME;
  LC_TD_TIME LC_VD_VIT_ONTIME;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_OUT;
  LC_TD_INT LC_VD_VOUI_ERRNO;
  LC_TD_FunctionBlock_TON LC_VD_FB_TON;
  LC_TD_FunctionBlock_TON LC_VD_FB_TON1;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  (p)->LC_VD_VIT_ONTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  (p)->LC_VD_VIT_OFFTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_OUT)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOUI_ERRNO)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_TON)); \
  LC_INIT_FunctionBlock_TON(&((p)->LC_VD_FB_TON1)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  if (RF==0) (p)->LC_VD_VIT_ONTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  if (RF==0) (p)->LC_VD_VIT_OFFTIME = LC_TIME_VALUE(RT_CC_CONST_LL(1),RT_CC_CONST_LL(0)); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_OUT),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOUI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_TON),0); \
  LC_WINIT_FunctionBlock_TON(&((p)->LC_VD_FB_TON1),0); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EFLASHx2EFB_LC_FLASH_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
