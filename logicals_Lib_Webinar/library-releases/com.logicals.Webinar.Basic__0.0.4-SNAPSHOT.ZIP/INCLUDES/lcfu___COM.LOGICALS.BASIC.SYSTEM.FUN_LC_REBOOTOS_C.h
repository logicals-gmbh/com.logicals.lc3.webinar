#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C__H

#include <LC3CGBase.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Function_COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C
{
  LC_TD_BOOL LC_VD_ENO;
} LCCG_StructAttrib LC_TD_Function_COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_Function_COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C(p) \
{ \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C(LC_TD_Function_COMx2ELOGICALSx2EBASICx2ESYSTEMx2EFUN_LC_REBOOTOS_C* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
