#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.opaut.control.fb_opaut_typ_d_st.h>
#include <lcfu___com.logicals.opaut.control.fb_opaut_typ_i_st.h>
#include <lcfu_iec61131__ADD.h>
#include <lcfu_iec61131__AND.h>
#include <lcfu_iec61131__GE.h>
#include <lcfu_iec61131__LE.h>
#include <lcfu_iec61131__MUL.h>
#include <lcfu_iec61131__NOT.h>
#include <lcfu_iec61131__SEL_ANY.h>
#include <lcfu_iec61131__SUB.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD
{
  LC_TD_BOOL LC_VD_AUT;
  LC_TD_BOOL LC_VD_EXT;
  LC_TD_REAL LC_VD_KP;
  LC_TD_REAL LC_VD_MV_HIGH;
  LC_TD_REAL LC_VD_MV_LOW;
  LC_TD_REAL LC_VD_MV_MAN;
  LC_TD_REAL LC_VD_PV;
  LC_TD_REAL LC_VD_SP;
  LC_TD_REAL LC_VD_TN_T0;
  LC_TD_REAL LC_VD_TV_T0;
  LC_TD_BOOL LC_VD_AH;
  LC_TD_BOOL LC_VD_AL;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_MV;
  LC_TD_BOOL LC_VD___16_AND;
  LC_TD_BOOL LC_VD___18_NOT;
  LC_TD_BOOL LC_VD___23_NOT;
  LC_TD_BOOL LC_VD___32_NOT;
  LC_TD_BOOL LC_VD___50_LE;
  LC_TD_BOOL LC_VD___57_GE;
  LC_TD_REAL LC_VD_E;
  LC_TD_REAL LC_VD_REFVAL;
  LC_TD_REAL LC_VD_W;
  LC_TD_REAL LC_VD___1_SEL;
  LC_TD_REAL LC_VD___8_SUB;
  LC_TD_REAL LC_VD___12_ADD;
  LC_TD_REAL LC_VD___40_MUL;
  LC_TD_REAL LC_VD___44_SEL;
  LC_TD_REAL LC_VD___66_SEL;
  LC_TD_REAL LC_VD___68_SEL;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST LC_VD_D;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_D_ST LC_VD_FB_TYP_D1;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST LC_VD_FB_TYP_I1;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_I_ST LC_VD_I;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD;

/*                   ColdBoot Initialization Macro             */
void LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(p) LC_INIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD((p),pEPDB)

/*                   WarmBoot Initialization Macro             */
void LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, int RF, struct _lcoplck_epdb_1_impl* pEPDB);
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(p,RF) LC_WINIT_FUN_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD((p),(RF),pEPDB)

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD(LC_TD_FunctionBlock_COMx2ELOGICALSx2EOPAUTx2ECONTROLx2EFB_OPAUT_TYP_PID_FBD* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);


#endif
