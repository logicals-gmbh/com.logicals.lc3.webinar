#ifndef LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST__H
#define LC_PROT_LCFU___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST__H

#include <LC3CGBase.h>
#include <lcfu_iec61131__RS.h>
#include <lcfu_iec61131__R_TRIG.h>

/*                            Typedefs                         */
typedef struct _LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST
{
  LC_TD_BOOL LC_VD_VIX_START;
  LC_TD_BOOL LC_VD_VIX_STOP;
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_BOOL LC_VD_VOX_ERR;
  LC_TD_BOOL LC_VD_VOX_MOTOR;
  LC_TD_INT LC_VD_VOI_ERRNO;
  LC_TD_BOOL LC_VD_LX_STARTPULSE;
  LC_TD_FunctionBlock_RS LC_VD_FB_MOTORRS;
  LC_TD_FunctionBlock_R_TRIG LC_VD_FB_STARTR_TRIG;
} LCCG_StructAttrib LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST(p) \
{ \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_START)); \
  LC_INIT_BOOL(&((p)->LC_VD_VIX_STOP)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_MOTOR)); \
  LC_INIT_BOOL(&((p)->LC_VD_VOX_ERR)); \
  LC_INIT_INT(&((p)->LC_VD_VOI_ERRNO)); \
  LC_INIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_STARTR_TRIG)); \
  LC_INIT_FunctionBlock_RS(&((p)->LC_VD_FB_MOTORRS)); \
  LC_INIT_BOOL(&((p)->LC_VD_LX_STARTPULSE)); \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST(p,RF) \
{ \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_START),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VIX_STOP),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_MOTOR),RF); \
  LC_WINIT_BOOL(&((p)->LC_VD_VOX_ERR),RF); \
  LC_WINIT_INT(&((p)->LC_VD_VOI_ERRNO),RF); \
  LC_WINIT_FunctionBlock_R_TRIG(&((p)->LC_VD_FB_STARTR_TRIG),0); \
  LC_WINIT_FunctionBlock_RS(&((p)->LC_VD_FB_MOTORRS),0); \
  LC_WINIT_BOOL(&((p)->LC_VD_LX_STARTPULSE),RF); \
}

/*                            Prototype                        */
void  lcfu___COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST(LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2EACTUATORx2EFB_LC_MOTOR1R_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
