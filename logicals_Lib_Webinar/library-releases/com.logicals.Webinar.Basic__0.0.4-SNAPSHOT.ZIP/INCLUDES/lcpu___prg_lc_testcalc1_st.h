#ifndef LC_PROT_LCPU___PRG_LC_TESTCALC1_ST__H
#define LC_PROT_LCPU___PRG_LC_TESTCALC1_ST__H

#include <LC3CGBase.h>
#include <lcfu___com.logicals.basic.calc.fb_lc_surface_st.h>
#include <lcfu___com.logicals.basic.calc.fb_lc_volumetank_st.h>
#include <lcpu___prg_lc_testcalc1_st.gv.h>

/*                            Typedefs                         */
typedef struct _LC_TD_Program_PRG_LC_TESTCALC1_ST
{
  LC_TD_BOOL LC_VD_ENO;
  LC_TD_REAL LC_VD_LR_DIAMETER;
  LC_TD_REAL LC_VD_LR_HEIGHT;
  LC_TD_REAL LC_VD_LR_SURFACE;
  LC_TD_REAL LC_VD_LR_VOLTANK;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST LC_VD_FB_SURFACE;
  LC_TD_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST LC_VD_FB_VOLUMETANK;
} LCCG_StructAttrib LC_TD_Program_PRG_LC_TESTCALC1_ST;

/*                   ColdBoot Initialization Macro             */
#define LC_INIT_NONDMA_Program_PRG_LC_TESTCALC1_ST(p) \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&((p)->LC_VD_FB_SURFACE)); \
  LC_INIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(&((p)->LC_VD_FB_VOLUMETANK)); \
  (p)->LC_VD_LR_HEIGHT = (LC_TD_REAL)1.0; \
  (p)->LC_VD_LR_DIAMETER = (LC_TD_REAL)1.0; \
  LC_INIT_REAL(&((p)->LC_VD_LR_SURFACE)); \
  (p)->LC_VD_LR_VOLTANK = (LC_TD_REAL)1.0; \

#define LC_INIT_Program_PRG_LC_TESTCALC1_ST(p) \
{ \
  LC_INIT_NONDMA_Program_PRG_LC_TESTCALC1_ST(p) \
}

/*                   WarmBoot Initialization Macro             */
#define LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC1_ST(p,RF) \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_SURFACE_ST(&((p)->LC_VD_FB_SURFACE),0); \
  LC_WINIT_FunctionBlock_COMx2ELOGICALSx2EBASICx2ECALCx2EFB_LC_VOLUMETANK_ST(&((p)->LC_VD_FB_VOLUMETANK),0); \
  if (RF==0) (p)->LC_VD_LR_HEIGHT = (LC_TD_REAL)1.0; \
  if (RF==0) (p)->LC_VD_LR_DIAMETER = (LC_TD_REAL)1.0; \
  LC_WINIT_REAL(&((p)->LC_VD_LR_SURFACE),RF); \
  if (RF==0) (p)->LC_VD_LR_VOLTANK = (LC_TD_REAL)1.0; \

#define LC_WINIT_Program_PRG_LC_TESTCALC1_ST(p,RF) \
{ \
  LC_WINIT_NONDMA_Program_PRG_LC_TESTCALC1_ST(p,RF) \
}

/*                            Prototype                        */
void  lcpu___PRG_LC_TESTCALC1_ST(LC_TD_Program_PRG_LC_TESTCALC1_ST* LC_this, struct _lcoplck_epdb_1_impl* pEPDB);

#endif
